##########################################################
# Supplementary Material to Schomaker M, Heumann C.      #
# When and when not to use optimal model averaging.      #
# Statistical Papers. 2020;in press.                     #
#                                                        #
# Simulation 3                                           #
##########################################################


# Set working directory
setwd("//home//mschomaker//Code_Reproduce//When_to_do_OMA")
directory=getwd()

# Load necessary files
library(MAMI)
library(SuperLearner)
library(MASS)
library(ltmle)
library(simcausal)
library(ggplot2)

set.seed(666)

###########################
# Data generating process #
###########################


# definition: left-truncated normal distribution
rnorm_trunc <- function(n, mean, sd, minval = 0, maxval = 10000,
                        min.low = 0, max.low = 50, min.high = 5000, max.high = 10000)
{
  out <- rnorm(n = n, mean = mean, sd = sd)
  minval <- minval[1]; min1 <- min.low[1]; max1 <- max.low[1]
  maxval <- maxval[1]; min2 <- min.high[1]; max2 <- max.high[1]
  leq.zero <- length(out[out <= minval])
  geq.max <- length(out[out >= maxval])
  out[out <= minval] <- runif(n = leq.zero, min = min1, max = max1)
  out[out >= maxval] <- runif(n = geq.max, min = min2, max = max2)
  out
}

#define the number of time points
t.end <- 12

#initialize the dag
D <- DAG.empty()

#everything at baseline (t = 0)
D.base <- D +
  node("V1",                                      #region -> 0 = west, 1 = southern
       t = 0,
       distr = "rbern",
       prob = 4392/5826) +
  node("V2",                                      #sex -> 0 = female, 1 = male
       t = 0,
       distr = "rbern",
       prob = ifelse(V1[0] == 1, 2222/4392, 758/1434)) +
  node("V3",                                      #age
       t = 0,
       distr = "runif",
       min = 1,
       max = 5) +
  node("L1",                                      #cd4-count
       t = 0,
       distr = "rnorm_trunc",
       mean = ifelse(V1[0] == 1, 650, 720),
       sd = ifelse(V1[0] == 1, 350, 400),
       minval = 0, maxval = 10000,
       min.low = 0, max.low = 50, min.high = 5000, max.high = 10000) +
  node("L1scaled",                                #auxilliary-variable
       t = 0,
       distr = "rnorm",
       mean = (L1[0]-671.7468)/(10*352.2788)+1,
       sd = 0) +
  node("L2",                                      #cd4%
       t = 0,
       distr = "rnorm_trunc",
       mean = .16 + .05 * (L1[0] - 650)/650,
       sd = .07,
       minval = .06, maxval = .8,
       min.low = .03, max.low = .09, min.high = .7, max.high = .8) +
  node("L2scaled",                                #auxilliary-variable
       t = 0,
       distr = "rnorm",
       mean = (L2[0]-0.1648594)/(10*0.06980332)+1,
       sd = 0) +
  node("L3",                                      #waz
       t = 0,
       distr = "rnorm_trunc",
       mean = ifelse(V1[0] == 1, - 1.65 + .1 * V3[0] + .05 * (L1[0] - 650)/650 + .05 * (L2[0] - 16)/16,
                     - 2.05 + .1 * V3[0] + .05 * (L1[0] - 650)/650 + .05 * (L2[0] - 16)/16),
       sd = 1,
       minval = -5, maxval = 5,
       min.low = -10, max.low = -3, min.high = 3, max.high = 10) +
  node("A",                                       # ART
       t = 0,
       distr = "rbern",
       prob = 0) +
  node("C",                                      # censoring (death?)
       t = 0,
       distr = "rbern",
       prob = 0,
       EFU = T) +
  node("Y",                                      # HAZ
       t = 0,
       distr = "rnorm_trunc",
       mean = -2.6 + .1 * I(V3[0] > 2) + .3 * I(V1[0] == 0) + (L3[0] + 1.45),
       sd = 1.1,
       minval = -5, maxval = 5,
       min.low = -10, max.low = -3, min.high = 3, max.high = 10)

#time-dependent variables at later time-points
D <- D.base +
  node("L1",                                      #cd4-count
       t = 1:4,
       distr = "rnorm_trunc",
       mean = 13*log(t * (1034-662)/8) + L1[t-1] + 2 * L2[t-1] + 2 * L3[t-1] + 2.5 * A[t-1],
       sd = 50,
       minval = 0, maxval = 10000,
       min.low = 0, max.low = 50, min.high = 5000, max.high = 10000) +
  node("L1",                                      #cd4-count
       t = 5:8,
       distr = "rnorm_trunc",
       mean = 4*log(t * (1034-662)/8) + L1[t-1] + 2 * L2[t-1] + 2 * L3[t-1] + 2.5 * A[t-1],
       sd = 50,
       minval = 0, maxval = 10000,
       min.low = 0, max.low = 50, min.high = 5000, max.high = 10000) +
  node("L1",                                      #cd4-count
       t = 9:t.end,
       distr = "rnorm_trunc",
       mean = L1[t-1] + 2 * L2[t-1] + 2 * L3[t-1] + 2.5 * A[t-1],
       sd = 50,
       minval = 0, maxval = 10000,
       min.low = 0, max.low = 50, min.high = 5000, max.high = 10000) +
  node("L2",                                      #cd4%
       t = 1:t.end,
       distr = "rnorm_trunc",
       mean = L2[t-1] + .0003 * (L1[t]-L1[t-1]) + .0005 * (L3[t-1]) + .0005 * A[t-1] * L1scaled[0],
       sd = .02,
       minval = .06, maxval = .8,
       min.low = .03, max.low = .09, min.high = .7, max.high = .8) +
  node("L3",                                      #waz
       t = 1:t.end,
       distr = "rnorm_trunc",
       mean = L3[t-1] + .0017 * (L1[t] - L1[t-1]) + .2 * (L2[t] - L2[t-1]) + .005 * A[t-1] * L2scaled[0],
       sd = .5,
       minval = -5, maxval = 5,
       min.low = -10, max.low = -3, min.high = 3, max.high = 10) +
  node("A",                                       #art
       t = 1:t.end,
       distr = "rbern",
       prob = ifelse(A[t-1] == 1, 1, plogis(-2.4 + .015 * (750 - L1[t]) + 5 * (.2 - L2[t]) - .8 * L3[t] + .8 * t))) +
  node("C",                                      # censoring
       t = 1:t.end,
       distr = "rbern",
       prob = plogis(-6 + .01 * (750 - L1[t]) + 1 * (.2 - L2[t]) - .65 * L3[t] - A[t]),
       EFU = T)

D <- D +
  node("Y",                                      #haz
       t = 1:t.end,
       distr = "rnorm_trunc",
       mean = Y[t-1] +
         .00005 * (L1[t] - L1[t-1]) - 0.000001 * ((L1[t] - L1[t-1])*sqrt(L1scaled[0]))^2 +
         .01 * (L2[t] - L2[t-1]) - .0001 * ((L2[t] - L2[t-1])*sqrt(L2scaled[0]))^2 +
         .07 * ((L3[t]-L3[t-1])*(L3[0]+1.5135)) - .001 * ((L3[t]-L3[t-1])*(L3[0]+1.5135))^2 +
         .005 * A[t] + .075 * A[t-1] + .05 * A[t]*A[t-1] ,
       sd = .01,
       minval = -5, maxval = 5,
       min.low = -10, max.low = -3, min.high = 3, max.high = 10)

#specify (dynamic) interventions
Dset <- set.DAG(D)
int.a <- c(node("A", t = 1:t.end, distr = "rbern",
              prob = ifelse(A[t-1] == 1, 1, ifelse(L1[t] < theta1 | L2[t] < theta2 | L3[t] < theta3, 1, 0))),
           node("C", t = 1:t.end, distr = "rbern", prob = 0))

D.dyn1 <- Dset + action("A_th1", nodes = int.a, theta1 = 10000, theta2 = .99, theta3 = 10) # treat all (A=1)
D.dyn2 <- Dset + action("A_th2", nodes = int.a, theta1 = 750, theta2 = .25, theta3 = -2) # treat 750/25/-2
D.dyn3 <- Dset + action("A_th3", nodes = int.a, theta1 = 350, theta2 = .15, theta3 = -2) # treat 350/15/-2
D.dyn4 <- Dset + action("A_th4", nodes = int.a, theta1 = -1, theta2 = -.1, theta3 = -11) # treat never (A=0)

# Intervention on the DAG given the specified interventions
dat1 <- simcausal::sim(DAG = D.dyn1, actions = "A_th1", n = 1000000, rndseed = 7693)
dat2 <- simcausal::sim(DAG = D.dyn2, actions = "A_th2", n = 1000000, rndseed = 7693)
dat3 <- simcausal::sim(DAG = D.dyn3, actions = "A_th3", n = 1000000, rndseed = 7693)
dat4 <- simcausal::sim(DAG = D.dyn4, actions = "A_th4", n = 1000000, rndseed = 7693)


true <- matrix(NA,ncol=4,nrow=13)
rownames(true) <- 0:12
colnames(true) <- c("immediate ART", "<750; <25%; < -2", "<350; <15%; < -2", "no ART")

true[1,1] <- mean(((dat1[["A_th1"]])$Y_0))
true[2,1] <- mean(((dat1[["A_th1"]])$Y_1))
true[3,1] <- mean(((dat1[["A_th1"]])$Y_2))
true[4,1] <- mean(((dat1[["A_th1"]])$Y_3))
true[5,1] <- mean(((dat1[["A_th1"]])$Y_4))
true[6,1] <- mean(((dat1[["A_th1"]])$Y_5))
true[7,1] <- mean(((dat1[["A_th1"]])$Y_6))
true[8,1] <- mean(((dat1[["A_th1"]])$Y_7))
true[9,1] <- mean(((dat1[["A_th1"]])$Y_8))
true[10,1] <- mean(((dat1[["A_th1"]])$Y_9))
true[11,1] <- mean(((dat1[["A_th1"]])$Y_10))
true[12,1] <- mean(((dat1[["A_th1"]])$Y_11))
true[13,1] <- mean(((dat1[["A_th1"]])$Y_12))

true[1,2] <- mean(((dat2[["A_th2"]])$Y_0))
true[2,2] <- mean(((dat2[["A_th2"]])$Y_1))
true[3,2] <- mean(((dat2[["A_th2"]])$Y_2))
true[4,2] <- mean(((dat2[["A_th2"]])$Y_3))
true[5,2] <- mean(((dat2[["A_th2"]])$Y_4))
true[6,2] <- mean(((dat2[["A_th2"]])$Y_5))
true[7,2] <- mean(((dat2[["A_th2"]])$Y_6))
true[8,2] <- mean(((dat2[["A_th2"]])$Y_7))
true[9,2] <- mean(((dat2[["A_th2"]])$Y_8))
true[10,2] <- mean(((dat2[["A_th2"]])$Y_9))
true[11,2] <- mean(((dat2[["A_th2"]])$Y_10))
true[12,2] <- mean(((dat2[["A_th2"]])$Y_11))
true[13,2] <- mean(((dat2[["A_th2"]])$Y_12))

true[1,3] <- mean(((dat3[["A_th3"]])$Y_0))
true[2,3] <- mean(((dat3[["A_th3"]])$Y_1))
true[3,3] <- mean(((dat3[["A_th3"]])$Y_2))
true[4,3] <- mean(((dat3[["A_th3"]])$Y_3))
true[5,3] <- mean(((dat3[["A_th3"]])$Y_4))
true[6,3] <- mean(((dat3[["A_th3"]])$Y_5))
true[7,3] <- mean(((dat3[["A_th3"]])$Y_6))
true[8,3] <- mean(((dat3[["A_th3"]])$Y_7))
true[9,3] <- mean(((dat3[["A_th3"]])$Y_8))
true[10,3] <- mean(((dat3[["A_th3"]])$Y_9))
true[11,3] <- mean(((dat3[["A_th3"]])$Y_10))
true[12,3] <- mean(((dat3[["A_th3"]])$Y_11))
true[13,3] <- mean(((dat3[["A_th3"]])$Y_12))

true[1,4] <- mean(((dat4[["A_th4"]])$Y_0))
true[2,4] <- mean(((dat4[["A_th4"]])$Y_1))
true[3,4] <- mean(((dat4[["A_th4"]])$Y_2))
true[4,4] <- mean(((dat4[["A_th4"]])$Y_3))
true[5,4] <- mean(((dat4[["A_th4"]])$Y_4))
true[6,4] <- mean(((dat4[["A_th4"]])$Y_5))
true[7,4] <- mean(((dat4[["A_th4"]])$Y_6))
true[8,4] <- mean(((dat4[["A_th4"]])$Y_7))
true[9,4] <- mean(((dat4[["A_th4"]])$Y_8))
true[10,4] <- mean(((dat4[["A_th4"]])$Y_9))
true[11,4] <- mean(((dat4[["A_th4"]])$Y_10))
true[12,4] <- mean(((dat4[["A_th4"]])$Y_11))
true[13,4] <- mean(((dat4[["A_th4"]])$Y_12))

#########
# SETUP #
#########

#################################################################
R <- 1000    # NUMBER OF SIMULATION RUNS

N <- c(1000)

gbounds <- c(0.01)

learner1 <- list(Q=c("SL.glm","SL.mean", "SL.stepAIC", "SL.glm.interaction", "SL.gam", "SL.bayesglm"),
                  g=NULL)
learner2 <- list(Q=c("SL.glm","SL.mean", "SL.stepAIC", "SL.glm.interaction", "SL.gam", "SL.bayesglm",
                    "SL.mma","SL.mma.int","SL.mma2","SL.jma","SL.jma.int","SL.jma2","SL.lae","SL.lae.int","SL.lae2"),
                  g=NULL)

mylibrary <- list(learner1 , learner2)
mylibrary_names <- c("learner1", "learner2")

#################################################################
ptm <- proc.time()
allcombinations <- apply(expand.grid(N, gbounds, mylibrary_names),1,paste, collapse=" ")

results_always_6  <- matrix(NA,ncol=length(allcombinations), nrow=R, dimnames=list(NULL,allcombinations))
results_350_6  <- matrix(NA,ncol=length(allcombinations), nrow=R, dimnames=list(NULL,allcombinations))
results_CP_always_6  <- matrix(NA,ncol=length(allcombinations), nrow=R, dimnames=list(NULL,allcombinations))
results_CP_350_6  <- matrix(NA,ncol=length(allcombinations), nrow=R, dimnames=list(NULL,allcombinations))
results_SL_Q_always_6  <- matrix(NA,ncol=length(mylibrary[length(mylibrary)][[1]][[1]]), nrow=R, dimnames=list(NULL,mylibrary[length(mylibrary)][[1]][[1]]))
results_SL_Q_350_6     <- matrix(NA,ncol=length(mylibrary[length(mylibrary)][[1]][[1]]), nrow=R, dimnames=list(NULL,mylibrary[length(mylibrary)][[1]][[1]]))

# extract SL weights
ew  <- function(myfit){return(myfit[,2])}
ewg <- function(myfit){
if(is.character(myfit[[1]])){return(NULL)}else{
return(myfit[,2])}
}

#
mymean <- function(myvec){
if(any(is.na(myvec))){
cat(paste("Number of failed models:",sum(is.na(myvec)), "\n"))
myvec[is.na(myvec)] <- 0
}
return(mean(myvec))
}

###############################
myQform <- c(Y_1  = "Q.kplus1 ~ b1 + b2 + b3 + b4 + b5 + b6 + b7 + L1_1  + L2_1  + L3_1  + A_1 ",
             Y_2  = "Q.kplus1 ~ b1 + b2 + b3 + b4 + b5 + b6 + b7 + L1_1  + L2_1  + L3_1  + A_1  + Y_1  + L1_1  + L2_1  + L3_1  + A_1",
             Y_3  = "Q.kplus1 ~ b1 + b2 + b3 + b4 + b5 + b6 + b7 + L1_2  + L2_2  + L3_2  + A_2  + Y_2  + L1_2  + L2_2  + L3_2  + A_2",
             Y_4  = "Q.kplus1 ~ b1 + b2 + b3 + b4 + b5 + b6 + b7 + L1_3  + L2_3  + L3_3  + A_3  + Y_3  + L1_3  + L2_3  + L3_3  + A_3",
             Y_5  = "Q.kplus1 ~ b1 + b2 + b3 + b4 + b5 + b6 + b7 + L1_4  + L2_4  + L3_4  + A_4  + Y_4  + L1_4  + L2_4  + L3_4  + A_4",
             Y_6  = "Q.kplus1 ~ b1 + b2 + b3 + b4 + b5 + b6 + b7 + L1_5  + L2_5  + L3_5  + A_5  + Y_5  + L1_5  + L2_5  + L3_5  + A_5",
             Y_7  = "Q.kplus1 ~ b1 + b2 + b3 + b4 + b5 + b6 + b7 + L1_6  + L2_6  + L3_6  + A_6  + Y_6  + L1_6  + L2_6  + L3_6  + A_6",
             Y_8  = "Q.kplus1 ~ b1 + b2 + b3 + b4 + b5 + b6 + b7 + L1_7  + L2_7  + L3_7  + A_7  + Y_7  + L1_7  + L2_7  + L3_7  + A_7",
             Y_9  = "Q.kplus1 ~ b1 + b2 + b3 + b4 + b5 + b6 + b7 + L1_8  + L2_8  + L3_8  + A_8  + Y_8  + L1_8  + L2_8  + L3_8  + A_8",
             Y_10 = "Q.kplus1 ~ b1 + b2 + b3 + b4 + b5 + b6 + b7 + L1_9  + L2_9  + L3_9  + A_9  + Y_9  + L1_9  + L2_9  + L3_9  + A_9",
             Y_11 = "Q.kplus1 ~ b1 + b2 + b3 + b4 + b5 + b6 + b7 + L1_10 + L2_10 + L3_10 + A_10 + Y_10 + L1_10 + L2_10 + L3_10 + A_10",
             Y_12 = "Q.kplus1 ~ b1 + b2 + b3 + b4 + b5 + b6 + b7 + L1_11 + L2_11 + L3_11 + A_11 + Y_11 + L1_11 + L2_11 + L3_11 + A_11"
    )

mygform <- c("A_1  ~ b1 + b2 + b3 + b4 + b5 + b6 + b7 + L1_1  + L2_1   + L3_1",
             "C_1  ~ b1 + b2 + b3 + b4 + b5 + b6 + b7 + L1_1  + L2_1   + L3_1   + A_1",
             "A_2  ~ b1 + b2 + b3 + b4 + b5 + b6 + b7 + L1_1  + L2_1   + L3_1   + A_1   + Y_1   + L1_2  + L2_2  + L3_2",
             "C_2  ~ b1 + b2 + b3 + b4 + b5 + b6 + b7 + L1_1  + L2_1   + L3_1   + A_1   + Y_1   + L1_2  + L2_2  + L3_2  + A_2",
             "A_3  ~ b1 + b2 + b3 + b4 + b5 + b6 + b7 + L1_2  + L2_2   + L3_2   + A_2   + Y_2   + L1_3  + L2_3  + L3_3",
             "C_3  ~ b1 + b2 + b3 + b4 + b5 + b6 + b7 + L1_2  + L2_2   + L3_2   + A_2   + Y_2   + L1_3  + L2_3  + L3_3  + A_3",
             "A_4  ~ b1 + b2 + b3 + b4 + b5 + b6 + b7 + L1_3  + L2_3   + L3_3   + A_3   + Y_3   + L1_4  + L2_4  + L3_4",
             "C_4  ~ b1 + b2 + b3 + b4 + b5 + b6 + b7 + L1_3  + L2_3   + L3_3   + A_3   + Y_3   + L1_4  + L2_4  + L3_4  + A_4",
             "A_5  ~ b1 + b2 + b3 + b4 + b5 + b6 + b7 + L1_4  + L2_4   + L3_4   + A_4   + Y_4   + L1_5  + L2_5  + L3_5",
             "C_5  ~ b1 + b2 + b3 + b4 + b5 + b6 + b7 + L1_4  + L2_4   + L3_4   + A_4   + Y_4   + L1_5  + L2_5  + L3_5  + A_5",
             "A_6  ~ b1 + b2 + b3 + b4 + b5 + b6 + b7 + L1_5  + L2_5   + L3_5   + A_5   + Y_5   + L1_6  + L2_6  + L3_6",
             "C_6  ~ b1 + b2 + b3 + b4 + b5 + b6 + b7 + L1_5  + L2_5   + L3_5   + A_5   + Y_5   + L1_6  + L2_6  + L3_6  + A_6",
             "A_7  ~ b1 + b2 + b3 + b4 + b5 + b6 + b7 + L1_6  + L2_6   + L3_6   + A_6   + Y_6   + L1_7  + L2_7  + L3_7",
             "C_7  ~ b1 + b2 + b3 + b4 + b5 + b6 + b7 + L1_6  + L2_6   + L3_6   + A_6   + Y_6   + L1_7  + L2_7  + L3_7  + A_7",
             "A_8  ~ b1 + b2 + b3 + b4 + b5 + b6 + b7 + L1_7  + L2_7   + L3_7   + A_7   + Y_7   + L1_8  + L2_8  + L3_8",
             "C_8  ~ b1 + b2 + b3 + b4 + b5 + b6 + b7 + L1_7  + L2_7   + L3_7   + A_7   + Y_7   + L1_8  + L2_8  + L3_8  + A_8",
             "A_9  ~ b1 + b2 + b3 + b4 + b5 + b6 + b7 + L1_8  + L2_8   + L3_8   + A_8   + Y_8   + L1_9  + L2_9  + L3_9",
             "C_9  ~ b1 + b2 + b3 + b4 + b5 + b6 + b7 + L1_8  + L2_8   + L3_8   + A_8   + Y_8   + L1_9  + L2_9  + L3_9  + A_9",
             "A_10 ~ b1 + b2 + b3 + b4 + b5 + b6 + b7 + L1_9  + L2_9   + L3_9   + A_9   + Y_9   + L1_10 + L2_10 + L3_10",
             "C_10 ~ b1 + b2 + b3 + b4 + b5 + b6 + b7 + L1_9  + L2_9   + L3_9   + A_9   + Y_9   + L1_10 + L2_10 + L3_10 + A_10",
             "A_11 ~ b1 + b2 + b3 + b4 + b5 + b6 + b7 + L1_10 + L2_10  + L3_10  + A_10  + Y_10  + L1_11 + L2_11 + L3_11",
             "C_11 ~ b1 + b2 + b3 + b4 + b5 + b6 + b7 + L1_10 + L2_10  + L3_10  + A_10  + Y_10  + L1_11 + L2_11 + L3_11 + A_11 ",
             "A_12 ~ b1 + b2 + b3 + b4 + b5 + b6 + b7 + L1_11 + L2_11  + L3_11  + A_11  + Y_11  + L1_12 + L2_12 + L3_12",
             "C_12 ~ b1 + b2 + b3 + b4 + b5 + b6 + b7 + L1_11 + L2_11  + L3_11  + A_11  + Y_11  + L1_12 + L2_12 + L3_12 + A_12"
             )

###############################

####################
# start simulation #
####################

for(r in 1:R)suppressWarnings(try({
#
ptm.ib <- proc.time()
#
cat(paste("This is simulation run number",r, "\n"))
#
for(n in N){
cat(paste("use n=",n,"; \n"))
simdat <- simcausal::sim(DAG = Dset, n = n)
simdat <-  simdat[,-c(1,6,8,10,11)]
colnames(simdat)[1:7] <- c("b1","b2","b3","b4","b5","b6","b7")
simdat[, c(grep("C",colnames(simdat)))][simdat[, c(grep("C",colnames(simdat)))]==1] <- 2
simdat[, c(grep("C",colnames(simdat)))][simdat[, c(grep("C",colnames(simdat)))]==0] <- 1
simdat[, c(grep("C",colnames(simdat)))][simdat[, c(grep("C",colnames(simdat)))]==2] <- 0
for(j in c(grep("C",colnames(simdat)))){simdat[, j] <- BinaryToCensoring(is.uncensored=simdat[, j])}
#
cd4s_350.1  <- (simdat$L1_1  < 350  | simdat$L2_1  < 0.15 | simdat$L3_1  < -2)
cd4s_350.2  <- (simdat$L1_2  < 350  | simdat$L2_2  < 0.15 | simdat$L3_2  < -2)   | cd4s_350.1
cd4s_350.3  <- (simdat$L1_3  < 350  | simdat$L2_3  < 0.15 | simdat$L3_3  < -2)   | cd4s_350.2
cd4s_350.4  <- (simdat$L1_4  < 350  | simdat$L2_4  < 0.15 | simdat$L3_4  < -2)   | cd4s_350.3
cd4s_350.5  <- (simdat$L1_5  < 350  | simdat$L2_5  < 0.15 | simdat$L3_5  < -2)   | cd4s_350.4
cd4s_350.6  <- (simdat$L1_6  < 350  | simdat$L2_6  < 0.15 | simdat$L3_6  < -2)   | cd4s_350.5
cd4s_350.7  <- (simdat$L1_7  < 350  | simdat$L2_7  < 0.15 | simdat$L3_7  < -2)   | cd4s_350.6
cd4s_350.8  <- (simdat$L1_8  < 350  | simdat$L2_8  < 0.15 | simdat$L3_8  < -2)   | cd4s_350.7
cd4s_350.9  <- (simdat$L1_9  < 350  | simdat$L2_9  < 0.15 | simdat$L3_9  < -2)   | cd4s_350.8
cd4s_350.10 <- (simdat$L1_10 < 350  | simdat$L2_10 < 0.15 | simdat$L3_10 < -2)   | cd4s_350.9
cd4s_350.11 <- (simdat$L1_11 < 350  | simdat$L2_11 < 0.15 | simdat$L3_11 < -2)   | cd4s_350.10
cd4s_350.12 <- (simdat$L1_12 < 350  | simdat$L2_12 < 0.15 | simdat$L3_12 < -2)   | cd4s_350.11
abar350s <- as.matrix(cbind(cd4s_350.1,cd4s_350.2,cd4s_350.3,cd4s_350.4,cd4s_350.5,cd4s_350.6,cd4s_350.7,cd4s_350.8,cd4s_350.9,cd4s_350.10,cd4s_350.11,cd4s_350.12))
abar350s[is.na(abar350s)] <- 0
#
for(g in gbounds){
  lc <- 0
  for(l in mylibrary){
#
lc <- lc+1
cat(paste("g=",g,"; l=",mylibrary_names[lc],"; "))
myindex <- c(seq(1:length(allcombinations)))[apply(rbind(grepl(paste(g),allcombinations),grepl(mylibrary_names[lc],allcombinations),grepl(paste(n),allcombinations)),2,all)]
#
cat("t=6; always; ")
tmle_6_always  <- suppressMessages(suppressWarnings(ltmle(simdat[,1:43],
                  Anodes=c(grep("A_",colnames(simdat[,1:43]))),
                  Cnodes=c(grep("C",colnames(simdat[,1:43]))),
                  Lnodes=sort(c(grep("L1_",colnames(simdat[,1:43])),grep("L2_",colnames(simdat[,1:43])),grep("L3_",colnames(simdat[,1:43])))),
                  Ynodes=c(grep("Y_",colnames(simdat[,1:43]))), Yrange=c(-10,10),
                  Qform=myQform[1:6], gform=mygform[1:12], abar=rep(1,6), stratify=FALSE, variance.method="ic",
                  SL.library=l, estimate.time=F, gbounds=c(g,1),gcomp=T)))

cat("350/15; \n")
tmle_6_350  <-  suppressMessages(suppressWarnings(ltmle(simdat[,1:43],
                  Anodes=c(grep("A_",colnames(simdat[,1:43]))),
                  Cnodes=c(grep("C",colnames(simdat[,1:43]))),
                  Lnodes=sort(c(grep("L1_",colnames(simdat[,1:43])),grep("L2_",colnames(simdat[,1:43])),grep("L3_",colnames(simdat[,1:43])))),
                  Ynodes=c(grep("Y_",colnames(simdat[,1:43]))), Yrange=c(-10,10),
                  Qform=myQform[1:6], gform=mygform[1:12], abar=abar350s[,1:6], stratify=FALSE, variance.method="ic",
                  SL.library=l, estimate.time=F, gbounds=c(g,1),gcomp=T)))
#
results_always_6[r,myindex] <-  tmle_6_always$est[1]
results_CP_always_6[r,myindex] <-  as.numeric((summary(tmle_6_always)$treatment$CI[1] < true[7,1]) & (summary(tmle_6_always)$treatment$CI[2] > true[7,1]))

results_350_6[r,myindex] <-  tmle_6_350$est[1]
results_CP_350_6[r,myindex] <-  as.numeric((summary(tmle_6_350)$treatment$CI[1] < true[7,3]) & (summary(tmle_6_350)$treatment$CI[2] > true[7,3]))

if(lc==length(mylibrary) & g == gbounds[1] & n==N[length(N)])try({
results_SL_Q_always_6[r,]     <-  apply(t(matrix(unlist(lapply(tmle_6_always$fit$Q, ew)),nrow=length(l$Q),dimnames=list(l[[1]],NULL))),2,mymean)
results_SL_Q_350_6[r,]        <-  apply(t(matrix(unlist(lapply(tmle_6_350$fit$Q, ew)),nrow=length(l$Q),dimnames=list(l[[1]],NULL))),2,mymean)
})

#
}}

#
tempresults <- list(results_always_6,results_350_6,
                    results_CP_always_6,results_CP_350_6,
                    results_SL_Q_always_6,results_SL_Q_350_6
                    )
save(tempresults, file=paste(directory,"/tempresults_sim3.Rdata",sep=""))
#
}
#
ptm.ib2 <- proc.time()
ibt <- round(((ptm.ib2-ptm.ib)/60)[1],digits=2)
if(r==1){cat(paste("The simulation will run for about another", R*ibt-ibt, "minutes \n"))}
timetogo <-  (paste("The simulation will run for about another", R*ibt-ibt, "minutes \n"))
write.csv(timetogo, file=paste(directory,"/timetogo_sim3.csv",sep=""))
#
}))

BIAS6     <- matrix(NA,nrow=2,ncol=length(allcombinations),dimnames=list(c("always","350"),allcombinations))
COVERAGE6 <- matrix(NA,nrow=2,ncol=length(allcombinations),dimnames=list(c("always","350"),allcombinations))

BIAS6[1,] <- apply(results_always_6,2,mean)-true[7,1]
BIAS6[2,] <- apply(results_350_6,2,mean)-true[7,3]
BIAS6 <- abs(BIAS6)

COVERAGE6[1,] <- apply(results_CP_always_6,2,mean)
COVERAGE6[2,] <- apply(results_CP_350_6,2,mean)

RESULTS6 <-  data.frame(cbind(rbind(expand.grid(N, gbounds, mylibrary_names),expand.grid(N, gbounds, mylibrary_names)),
                   c(rep("(1) always",length(allcombinations)),rep("(2) 350/15%/-2",length(allcombinations))),
                   c(t(BIAS6)), c(t(COVERAGE6)), rep(6,length(allcombinations)*2)
                   ))
colnames(RESULTS6) <- c("n","g","Learner","Intervention","Bias","Coverage","t")

SLweights <- c(apply(results_SL_Q_always_6,2,mean),
      apply(results_SL_Q_350_6,2,mean))
lw <-  length(mylibrary[length(mylibrary)][[1]]$Q)
SLW <- data.frame(SLweights, names(SLweights), c(rep("Q-model",length(SLweights))),rep(6,length(SLweights)),
                  rep(c(rep("always",lw),rep("350/15/-2",lw))))
colnames(SLW) <- c("weight","learner","model","time", "Intervention")

SLW$learner <- as.character(SLW$learner)
SLW$learner[SLW$learner=="SL.mean"] <- "L 01: mean"
SLW$learner[SLW$learner=="SL.glm"] <- "L 02: GLM"
SLW$learner[SLW$learner=="SL.stepAIC"] <- "L 04: GLM (+AIC)"
SLW$learner[SLW$learner=="SL.glm.interaction"] <- "L 05: GLM (+interactions)"
SLW$learner[SLW$learner=="SL.gam"] <- "L 06: GAM"
SLW$learner[SLW$learner=="SL.bayesglm"] <- "L 03: GLM (Bayes)"
SLW$learner[SLW$learner=="SL.mma"] <- "L 07: MMA"
SLW$learner[SLW$learner=="SL.mma.int"] <- "L 08: MMA (+interactions)"
SLW$learner[SLW$learner=="SL.mma2"] <- "L 09: MMA (+ squared trans.)"
SLW$learner[SLW$learner=="SL.jma"] <- "L10: JMA"
SLW$learner[SLW$learner=="SL.jma.int"] <- "L11: JMA (+interactions)"
SLW$learner[SLW$learner=="SL.jma2"] <- "L12: JMA (+ squared trans.)"
SLW$learner[SLW$learner=="SL.lae"] <- "L13: LAE"
SLW$learner[SLW$learner=="SL.lae.int"] <- "L14: LAE (+interactions)"
SLW$learner[SLW$learner=="SL.lae2"] <- "L15: LAE (+ squared trans.)"

pdf(file=paste(directory,"/Figure1_sim3.pdf",sep=""),width=11)
slp1 <- ggplot(SLW, aes(x=model, y=weight))
slp2 <- slp1  + geom_col(aes(fill = learner)) + facet_grid(. ~ Intervention) + theme_bw()  + scale_x_discrete("") + scale_y_continuous("SL weight")
slp3 <- slp2 + theme(axis.title.x = element_text(size=16), axis.text.x = element_text(size=16),axis.title.y = element_text(size=16, angle = 90), axis.text.y = element_text(size=16), legend.text =  element_text(size=14), legend.title =  element_text(size=16, face = "bold", hjust = 0),legend.position =   "right")
slp4 <- slp3 + guides(fill = guide_legend(keywidth = 2, keyheight = 2, title="Learner")) 
plot(slp4)
dev.off()

#
results <- list(results_always_6,results_350_6,
                    results_CP_always_6,results_CP_350_6,
                    results_SL_Q_always_6,results_SL_Q_350_6
                    )
save(results, file=paste(directory,"/sim3.Rdata",sep=""))
#

# How long did it take?
ptm2 <-  proc.time()
simulationsdauer <- ptm2-ptm
simulationsdauer <- (simulationsdauer/60)
simulationsdauer <- round(simulationsdauer[1]/60, digits=2)
cat(paste("The simulation time was", simulationsdauer, "hours \n"))

######################
# Table 3 from Paper #
######################

RESULTS6 

#######################
# Figure 1 from Paper #
###################### #
plot(slp4)