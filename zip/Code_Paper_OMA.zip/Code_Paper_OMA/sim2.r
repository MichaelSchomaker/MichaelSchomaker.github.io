##########################################################
# Supplementary Material to Schomaker M, Heumann C.      #
# When and when not to use optimal model averaging.      #
# Statistical Papers. 2020;in press.                     #
#                                                        #
# Simulation 2                                           #
##########################################################

# Set working directory
setwd("//home//mschomaker//Code_Reproduce//When_to_do_OMA")
directory=getwd()

# Load necessary packages
library(xtable)
library(MAMI)           # http://mami.r-forge.r-project.org/ ; 
                        # install.packages("MAMI", repos=c("http://R-Forge.R-project.org","http://cran.at.r-project.org"), dependencies=TRUE)
library(SuperLearner)
library(copula)

### NOTE: for the below learners to work, you need the following packages to be installed (though not necessarily loaded):
#         arm, gam, glmnet, randomForest


set.seed(666)

################
## Simulation ##
################
mysimulation <- function(runs=1000,directory = "C:/temp/"){

ptm <- proc.time()

M1_PE <- matrix(NA,nrow=1,ncol=runs)
M2_PE <- matrix(NA,nrow=1,ncol=runs)
M3_PE <- matrix(NA,nrow=1,ncol=runs)
M4_PE <- matrix(NA,nrow=1,ncol=runs)
M5_PE <- matrix(NA,nrow=1,ncol=runs)
M6_PE <- matrix(NA,nrow=1,ncol=runs)
M7_PE <- matrix(NA,nrow=1,ncol=runs)
SL.library <- c("SL.glm","SL.stepAIC", "SL.glmnet", "SL.mean", "SL.bayesglm", "SL.gam", "SL.randomForest","SL.glm.interaction","SL.step.interaction")
SL.library2 <- c(SL.library,"SL.mma", "SL.mma.int", "SL.mma2", "SL.jma", "SL.jma.int", "SL.jma2", "SL.lae", "SL.lae.int","SL.lae2")
SL <- matrix(NA,nrow=length(SL.library2),ncol=runs)


# Simulation loop
for(r in 1:runs)try({
cat("This is simulation run",r,"\n" )
ptm.ib <- proc.time()

ntrain <- 1000
mycopula <-  mvdc(claytonCopula(1, dim=10),c("norm","norm","norm","norm","lnorm","lnorm","lnorm","exp","exp","exp"),list(list(mean=0, sd=1),list(mean=0, sd=1),list(mean=0, sd=1),list(mean=0, sd=1),list(meanlog=0, sdlog=0.5),list(meanlog=0, sdlog=0.5),list(meanlog=0, sdlog=0.5),list(rate=1),list(rate=1),list(rate=1)))
mycovdata <- rMvdc(ntrain,mycopula)
colnames(mycovdata)<- c("p1","p2","p3","p4","p5","p6","p7","p8","p9","p10")
mycovdata <- as.data.frame(mycovdata)
mu    <-  -5 + 0.5*mycovdata$p2 + 1.5*mycovdata$p6  + 1.5*mycovdata$p9 + mycovdata$p9*mycovdata$p6 +  mycovdata$p2^2
mysigma <-  exp(1.5)
y <- rnorm(ntrain, mu, mysigma)

original_f <- as.data.frame(cbind(y,mycovdata$p1,mycovdata$p2,mycovdata$p3,mycovdata$p4,mycovdata$p5,mycovdata$p6,mycovdata$p7,mycovdata$p8,mycovdata$p9,mycovdata$p10))
colnames(original_f)<-c("y","p1","p2","p3","p4","p5","p6","p7","p8","p9","pzehn")

original <- original_f[1:500,]
test     <- original_f[501:1000,]

# Method 1: ML
m1      <- glm(y~p1+p2+p3+p4+p5+p6+p7+p8+p9+pzehn+p9:p6,data=original)
M1_PE[,r]        <- sum(((test$y-predict(m1, newdata=test))^2))/500

# Method 2: stepwise regression
m2 <- mami(original, method="MS.criterion", missing.data="none", print.warnings=F, add.interaction=list(c("p6","p9")))$coefficients.s
M2_PE[,r]        <- sum(((test$y-  as.matrix(cbind(1,test[,-1],test$p6*test$p9))%*%matrix(m2[,1],ncol=1)  )^2))/500

# Method 3: Frequentist model averaging
m3 <- mami(original, method="MA.criterion", missing.data="none", print.warnings=F, add.interaction=list(c("p6","p9")))$coefficients.ma
M3_PE[,r]        <- sum(((test$y-  as.matrix(cbind(1,test[,-1],test$p6*test$p9))%*%matrix(m3[,1],ncol=1)  )^2))/500

# Method 4: Bayesian model averaging 
m4 <- mami(original, method="MA.criterion", criterion="BIC+", missing.data="none", print.warnings=F, add.interaction=list(c("p6","p9")))$coefficients.ma
M4_PE[,r]        <- sum(((test$y-  as.matrix(cbind(1,test[,-1],test$p6*test$p9))%*%matrix(m4[,1],ncol=1)  )^2))/500

# Method 5: MMA
m5 <- mami(original, method="MMA", missing.data="none", print.warnings=F, add.interaction=list(c("p6","p9")))$coefficients.ma
M5_PE[,r]        <- sum(((test$y-  as.matrix(cbind(1,test[,-1],test$p6*test$p9))%*%matrix(m5[,1],ncol=1)  )^2))/500

# Method 6: Super Learner
m6SL <- SuperLearner(Y=original[,1], X=original[,-1], newX= test[,-1], SL.library = SL.library)
m6 <- predict(m6SL)
M6_PE[,r] <- sum(((test$y- m6[[1]] )^2))/500

# Method 7: Super Learner + optimal model averaging
m7SL <- SuperLearner(Y=original[,1], X=original[,-1], newX=test[,-1], SL.library = SL.library2)
m7 <- predict(m7SL)
M7_PE[,r]  <- sum(((test$y- m7[[1]] )^2))/500
SL[,r]     <- m7SL$coef
})


# Prediction Error
M1_pred <- mean(M1_PE[is.na(M1_PE)==F])
M2_pred <- mean(M2_PE[is.na(M2_PE)==F])
M3_pred <- mean(M3_PE[is.na(M3_PE)==F])
M4_pred <- mean(M4_PE[is.na(M4_PE)==F])
M5_pred <- mean(M5_PE[is.na(M5_PE)==F])
M6_pred <- mean(M6_PE[is.na(M6_PE)==F])
M7_pred <- mean(M7_PE[is.na(M7_PE)==F])
M1_predse <- sd(M1_PE[is.na(M1_PE)==F])
M2_predse <- sd(M2_PE[is.na(M2_PE)==F])
M3_predse <- sd(M3_PE[is.na(M3_PE)==F])
M4_predse <- sd(M4_PE[is.na(M4_PE)==F])
M5_predse <- sd(M5_PE[is.na(M5_PE)==F])
M6_predse <- sd(M6_PE[is.na(M6_PE)==F])
M7_predse <- sd(M7_PE[is.na(M7_PE)==F])
PE <- matrix(c(M1_pred,M1_predse,M2_pred,M2_predse,M3_pred,M3_predse,M4_pred,M4_predse,M5_pred,M5_predse,M6_pred,M6_predse,M7_pred,M7_predse), nrow=2, ncol=7)
colnames(PE)<-c("OLS","MS","FMA","BMA","MMA","SL","SL+")

mytable4 <- xtable(PE, caption='Average Prediction Error')
print(mytable4,file=paste(directory,"/Results_sim2.tex",sep=""),table.placement="H")

# Prediction Error
mymean<-function(vec){mean(na.omit(vec))}
SL_final <- as.matrix(apply(matrix(SL,ncol=runs,dimnames=list(names(m7SL$coef),NULL)),1,mymean))
mytable5 <- xtable(SL_final, caption='Average super learner weights')
print(mytable5,file=paste(directory,"/Results_sim2.tex",sep=""),append=T,table.placement="H")

collect <-list(M1_PE,M2_PE,M3_PE,M4_PE,M5_PE,M6_PE,M7_PE,SL)

# How long did it take?
ptm2 <-  proc.time()
simulationsdauer <- ptm2-ptm
simulationsdauer <- (simulationsdauer/60)
simulationsdauer <- round(simulationsdauer[1], digits=2)
cat(paste("The simulation time was", simulationsdauer, "minutes \n"))
finaltime <-  paste("The simulation time was", simulationsdauer, "minutes")

# Results
results <- list(PE,SL_final,collect)
save(results, file=paste(directory,"/sim2.Rdata",sep=""))
return(results)

}

simulation2 <- mysimulation(runs=5000,directory = getwd())

# Table 2a
simulation2[[1]]

# Table 2b
simulation2[[2]]

