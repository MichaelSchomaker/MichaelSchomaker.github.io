##########################################################
# Supplementary Material to Schomaker M, Heumann C.      #
# When and when not to use optimal model averaging.      #
# Statistical Papers. 2020;in press.                     #
#                                                        #
# Simulation 1                                           #
##########################################################


# Set working directory
setwd("//home//mschomaker//Code_Reproduce//When_to_do_OMA")
directory=getwd()

# Load necessary packages
library(xtable)
library(MAMI)           # http://mami.r-forge.r-project.org/ ; 
                        # install.packages("MAMI", repos=c("http://R-Forge.R-project.org","http://cran.at.r-project.org"), dependencies=TRUE)
library(copula)


set.seed(666)

################
## Simulation ##
################
mysimulation <- function(runs=1000,directory = "C:/temp/"){

ptm <- proc.time()
param <- 11

M1_est <- matrix(NA,nrow=param,ncol=runs)
M1_se <- matrix(NA,nrow=param,ncol=runs)
M1_CI <- matrix(NA,nrow=param,ncol=runs)
M1_PE <- matrix(NA,nrow=1,ncol=runs)
M2_est <- matrix(NA,nrow=param,ncol=runs)
M2_se <- matrix(NA,nrow=param,ncol=runs)
M2_CI <- matrix(NA,nrow=param,ncol=runs)
M2_PE <- matrix(NA,nrow=1,ncol=runs)
M3_est <- matrix(NA,nrow=param,ncol=runs)
M3_se <- matrix(NA,nrow=param,ncol=runs)
M3_CI <- matrix(NA,nrow=param,ncol=runs)
M3_PE <- matrix(NA,nrow=1,ncol=runs)
M4_est <- matrix(NA,nrow=param,ncol=runs)
M4_se <- matrix(NA,nrow=param,ncol=runs)
M4_CI <- matrix(NA,nrow=param,ncol=runs)
M4_PE <- matrix(NA,nrow=1,ncol=runs)
M5_est <- matrix(NA,nrow=param,ncol=runs)
M5_se <- matrix(NA,nrow=param,ncol=runs)
M5_CI <- matrix(NA,nrow=param,ncol=runs)
M5_PE <- matrix(NA,nrow=1,ncol=runs)
M1_PE2 <- matrix(NA,nrow=1,ncol=runs)
M2_PE2 <- matrix(NA,nrow=1,ncol=runs)
M3_PE2 <- matrix(NA,nrow=1,ncol=runs)
M4_PE2 <- matrix(NA,nrow=1,ncol=runs)
M5_PE2 <- matrix(NA,nrow=1,ncol=runs)


# Simulation loop
for(r in 1:runs)try({
cat("This is simulation run",r,"\n" )
ptm.ib <- proc.time()

ntrain <- 1000
mycopula <-  mvdc(claytonCopula(1, dim=10),c("norm","norm","norm","norm","lnorm","lnorm","lnorm","exp","exp","exp"),list(list(mean=0, sd=1),list(mean=0, sd=1),list(mean=0, sd=1),list(mean=0, sd=1),list(meanlog=0, sdlog=0.5),list(meanlog=0, sdlog=0.5),list(meanlog=0, sdlog=0.5),list(rate=1),list(rate=1),list(rate=1)))
mycovdata <- rMvdc(ntrain,mycopula)
colnames(mycovdata)<- c("p1","p2","p3","p4","p5","p6","p7","p8","p9","p10")
mycovdata <- as.data.frame(mycovdata)
mu    <-  0*mycovdata$p1 + 0*mycovdata$p2 + 1*mycovdata$p3 + 2*mycovdata$p4 + 3*mycovdata$p5 + 3*mycovdata$p6 + 2*mycovdata$p7 + 1*mycovdata$p8  +  0.5*mycovdata$p9 +  0*mycovdata$p10
mysigma <-  exp(2)
y <- rnorm(ntrain, mu, mysigma)
true <- c(0,0,0,1,2,3,3,2,1,0.5,0)

original_f <- as.data.frame(cbind(y,mycovdata$p1,mycovdata$p2,mycovdata$p3,mycovdata$p4,mycovdata$p5,mycovdata$p6,mycovdata$p7,mycovdata$p8,mycovdata$p9,mycovdata$p10))
colnames(original_f)<-c("y","p1","p2","p3","p4","p5","p6","p7","p8","p9","pzehn")

original <- original_f[1:500,]
test     <- original_f[501:1000,]

# Method 1: OLS
m1      <- glm(y~.,data=original)

Summary1.1      <- list(est=coef(m1),lower=coef(m1)-qt(0.975,df=ntrain-param)*summary(m1)[[12]][,2],upper=coef(m1)+qt(0.975,df=ntrain-param)*summary(m1)[[12]][,2])
include_true_M1 <- as.numeric((Summary1.1$lower <= true) & (Summary1.1$upper>= true))

M1_CI[,r]        <- include_true_M1
M1_se[,r]        <- summary(m1)[[12]][,2]
M1_est[,r]       <- coef(m1)
M1_PE[,r]        <- sum(((test$y-predict(m1, newdata=test))^2))/500
M1_PE2[,r]        <- sum(((mu[1:500] -predict(m1))^2))/500

# Method 2: stepwise regression with AIC
m2 <- mami(original, method="MS.criterion", missing.data="none", print.warnings=F)$coefficients.s

Summary2.1      <- list(est=m2[,1],lower=m2[,3],upper=m2[,4])
include_true_m2 <- as.numeric((Summary2.1$lower <= true) & (Summary2.1$upper>= true))

M2_CI[,r]        <- include_true_m2
M2_se[,r]        <- m2[,2]
M2_est[,r]       <- m2[,1]
M2_PE[,r]        <- sum(((test$y-  as.matrix(cbind(1,test[,-1]))%*%matrix(m2[,1],ncol=1)  )^2))/500
M2_PE2[,r]        <- sum(((mu[1:500] -  as.matrix(cbind(1,original[,-1]))%*%matrix(m2[,1],ncol=1)  )^2))/500

# Method 3: Frequentist model averaging
m3 <- mami(original, method="MA.criterion", missing.data="none", print.warnings=F)$coefficients.ma

Summary3.1      <- list(est=m3[,1],lower=m3[,3],upper=m3[,4])
include_true_m3 <- as.numeric((Summary3.1$lower <= true) & (Summary3.1$upper>= true))

M3_CI[,r]        <- include_true_m3
M3_se[,r]        <- m3[,2]
M3_est[,r]       <- m3[,1]
M3_PE[,r]        <- sum(((test$y-  as.matrix(cbind(1,test[,-1]))%*%matrix(m3[,1],ncol=1)  )^2))/500
M3_PE2[,r]        <- sum(((mu[1:500] -  as.matrix(cbind(1,original[,-1]))%*%matrix(m3[,1],ncol=1)  )^2))/500

# Method 4: Bayesian model averaging 
m4 <- mami(original, method="MA.criterion", criterion="BIC+", missing.data="none", print.warnings=F)$coefficients.ma

Summary4.1      <- list(est=m4[,1],lower=m4[,3],upper=m4[,4])
include_true_m4 <- as.numeric((Summary4.1$lower <= true) & (Summary4.1$upper>= true))

M4_CI[,r]        <- include_true_m4
M4_se[,r]        <- m4[,2]
M4_est[,r]       <- m4[,1]
M4_PE[,r]        <- sum(((test$y-  as.matrix(cbind(1,test[,-1]))%*%matrix(m4[,1],ncol=1)  )^2))/500
M4_PE2[,r]        <- sum(((mu[1:500] -  as.matrix(cbind(1,original[,-1]))%*%matrix(m4[,1],ncol=1)  )^2))/500

# Method 5: MMA
m5 <- mami(original, method="MMA", missing.data="none", print.warnings=F, calc.var="boot")$coefficients.ma

Summary5.1      <- list(est=m5[,1],lower=m5[,3],upper=m5[,4])
include_true_m5 <- as.numeric((Summary5.1$lower <= true) & (Summary5.1$upper>= true))

M5_CI[,r]        <- include_true_m5
M5_se[,r]        <- m5[,2]
M5_est[,r]       <- m5[,1]
M5_PE[,r]        <- sum(((test$y-  as.matrix(cbind(1,test[,-1]))%*%matrix(m5[,1],ncol=1)  )^2))/500
M5_PE2[,r]        <- sum(((mu[1:500] -  as.matrix(cbind(1,original[,-1]))%*%matrix(m5[,1],ncol=1)  )^2))/500

})


# Unbiasedness
M1_ub <- apply(M1_est[,!apply(M1_est,2,is.na)[1,]],1,mean)
M2_ub <- apply(M2_est[,!apply(M2_est,2,is.na)[1,]],1,mean)
M3_ub <- apply(M3_est[,!apply(M3_est,2,is.na)[1,]],1,mean)
M4_ub <- apply(M4_est[,!apply(M4_est,2,is.na)[1,]],1,mean)
M5_ub <- apply(M5_est[,!apply(M5_est,2,is.na)[1,]],1,mean)

ub <- rbind(M1_ub,M2_ub,M3_ub,M4_ub,M5_ub)
rownames(ub)<-c("OLS","MS","FMA","BMA","MMA")
colnames(ub)<-c("b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","b10")

mytable1 <- xtable(ub, caption='Point Estimates')
print(mytable1,file=paste(directory,"/Results_sim1.tex",sep=""),table.placement="H")

# Standard Error
M1_SE  <- apply(M1_se[,!apply(M1_se,2,is.na)[1,]],1,mean)
M1_SE2 <- apply(M1_est[,!apply(M1_est,2,is.na)[1,]],1,sd)
M2_SE  <- apply(M2_se[,!apply(M2_se,2,is.na)[1,]],1,mean)
M2_SE2 <- apply(M2_est[,!apply(M2_est,2,is.na)[1,]],1,sd)
M3_SE  <- apply(M3_se[,!apply(M3_se,2,is.na)[1,]],1,mean)
M3_SE2 <- apply(M3_est[,!apply(M3_est,2,is.na)[1,]],1,sd)
M4_SE  <- apply(M4_se[,!apply(M4_se,2,is.na)[1,]],1,mean)
M4_SE2 <- apply(M4_est[,!apply(M4_est,2,is.na)[1,]],1,sd)
M5_SE  <- apply(M5_se[,!apply(M5_se,2,is.na)[1,]],1,mean)
M5_SE2 <- apply(M5_est[,!apply(M5_est,2,is.na)[1,]],1,sd)

ses <- cbind(M1_SE,M1_SE2,M2_SE,M2_SE2,M3_SE,M3_SE2,M4_SE,M4_SE2,M5_SE,M5_SE2)
rownames(ses)<-c("b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","b10")
colnames(ses)<-c("OLS","","MS","","FMA","","BMA","","MMA","")

mytable2 <- xtable(ses, caption='Standard Errors')
print(mytable2,file=paste(directory,"/Results_sim1.tex",sep=""),append=T,table.placement="H")

#  Coverage
M1_cov <- apply(M1_CI[,!apply(M1_CI,2,is.na)[1,]],1,mean)
M2_cov <- apply(M2_CI[,!apply(M2_CI,2,is.na)[1,]],1,mean)
M3_cov <- apply(M3_CI[,!apply(M3_CI,2,is.na)[1,]],1,mean)
M4_cov <- apply(M4_CI[,!apply(M4_CI,2,is.na)[1,]],1,mean)
M5_cov <- apply(M5_CI[,!apply(M5_CI,2,is.na)[1,]],1,mean)
coverage <- rbind(M1_cov,M2_cov,M3_cov,M4_cov,M5_cov)
rownames(coverage)<-c("OLS","MS","FMA","BMA","MMA")
colnames(coverage)<-c("b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","b10")

mytable3 <- xtable(coverage, caption='Coverage')
print(mytable3,file=paste(directory,"/Results_sim1.tex",sep=""),append=T,table.placement="H")

# Prediction Error
M1_pred <- mean(M1_PE[is.na(M1_PE)==F])
M2_pred <- mean(M2_PE[is.na(M2_PE)==F])
M3_pred <- mean(M3_PE[is.na(M3_PE)==F])
M4_pred <- mean(M4_PE[is.na(M4_PE)==F])
M5_pred <- mean(M5_PE[is.na(M5_PE)==F])

M1_predse <- sd(M1_PE[is.na(M1_PE)==F])
M2_predse <- sd(M2_PE[is.na(M2_PE)==F])
M3_predse <- sd(M3_PE[is.na(M3_PE)==F])
M4_predse <- sd(M4_PE[is.na(M4_PE)==F])
M5_predse <- sd(M5_PE[is.na(M5_PE)==F])

M1_pred2 <- mean(M1_PE2[is.na(M1_PE2)==F])
M2_pred2 <- mean(M2_PE2[is.na(M2_PE2)==F])
M3_pred2 <- mean(M3_PE2[is.na(M3_PE2)==F])
M4_pred2 <- mean(M4_PE2[is.na(M4_PE2)==F])
M5_pred2 <- mean(M5_PE2[is.na(M5_PE2)==F])

M1_predse2 <- sd(M1_PE2[is.na(M1_PE2)==F])
M2_predse2 <- sd(M2_PE2[is.na(M2_PE2)==F])
M3_predse2 <- sd(M3_PE2[is.na(M3_PE2)==F])
M4_predse2 <- sd(M4_PE2[is.na(M4_PE2)==F])
M5_predse2 <- sd(M5_PE2[is.na(M5_PE2)==F])

PE <- matrix(c(M1_pred,M1_predse,M2_pred,M2_predse,M3_pred,M3_predse,M4_pred,M4_predse,M5_pred,M5_predse), nrow=2, ncol=5)
PE2 <- matrix(c(M1_pred2,M1_predse2,M2_pred2,M2_predse2,M3_pred2,M3_predse2,M4_pred2,M4_predse2,M5_pred2,M5_predse2), nrow=2, ncol=5)
PE3 <- rbind(PE,PE2)
colnames(PE3)<-c("OLS","MS","FMA","BMA","MMA")
rownames(PE3)<-c("MSPE","sd","MSE of mu","s.d.")

mytable4 <- xtable(PE3, caption='Average Prediction Error')
print(mytable4,file=paste(directory,"/Results_sim1.tex",sep=""),append=T,table.placement="H")


collect <-list(M1_est,M2_est,M3_est,M4_est,M5_est,M1_se,M2_se,M3_se,M4_se,M5_se,M1_CI,M2_CI,M3_CI,M4_CI,M5_CI,M1_PE,M2_PE,M3_PE,M4_PE,M5_PE,M1_PE2,M2_PE2,M3_PE2,M4_PE2,M5_PE2)

# How long did it take?
ptm2 <-  proc.time()
simulationsdauer <- ptm2-ptm
simulationsdauer <- (simulationsdauer/60)
simulationsdauer <- round(simulationsdauer[1], digits=2)
cat(paste("The simulation time was", simulationsdauer, "minutes \n"))
finaltime <-  paste("The simulation time was", simulationsdauer, "minutes")

# Results
results <- list(ub,ses,coverage,PE3,collect)
save(results, file=paste(directory,"/sim1.Rdata",sep=""))
return(results)

}

# Runs simulation 1 from Paper, all results are saved as Latex table
simulation1 <- mysimulation(runs=5000,directory = getwd())

# Table 1a 
simulation1[[1]]

# Table 1b  - note: MMA SE based on bootstrap SE (slightly different from paper where SE was calculated differently, contact me for details)
t(simulation1[[2]])

# Table 1c
simulation1[[3]]

# Table 1d
simulation1[[4]][3,]


