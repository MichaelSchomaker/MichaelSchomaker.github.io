###################################################################################################################################################
# Supplementary Material to Schomaker and Heuman, Bootstrap Inference when Using Multiple Imputation                                              #
# Statistics in Medicine; 37:2252-2266                                                                                                            #
#                                                                                                                                                 #
# Simulation 2                                                                                                                                    #
#                                                                                                                                                 #
# The results can be obtained by simply pasting this file to R                                                                                    #
# Just 1) change your working directory                                                                                                           #
#      2) paste the mi.inference2.r file in the same folder as this file                                                                          #
#      3) Create subfolders as per instruction at the bottom of this file                                                                         #
# Figures and tables are produced automatically                                                                                                   #
# Settings can be varied by changing the function's options further below in the document or by changing the setup below, e.g. n, beta etc.       #
###################################################################################################################################################


# Set working directory
setwd("//home//mschomaker//Code_Reproduce//Bootstrap")

# Load necessary files
source('mi.inference2.r')   # from library "norm" with tiny change 
library(Amelia)
library(copula)
library(xtable)

set.seed(666)

################
## Simulation ##
################
mysimulation <- function(runs=1000,B=200,M=10,aa,bb,directory = "C:/temp"){

ptm <- proc.time()
param <- 7
missingstat_total <- c(rep(0,param+1))
M_est <- matrix(NA,nrow=param,ncol=runs)
M1_CI <- matrix(NA,nrow=param,ncol=runs)
M1_CI2 <- matrix(NA,nrow=param,ncol=runs)
M1_CI3 <- matrix(NA,nrow=param,ncol=runs)
M2_CI <- matrix(NA,nrow=param,ncol=runs)
M2_CI2 <- matrix(NA,nrow=param,ncol=runs)
M2_CI3 <- matrix(NA,nrow=param,ncol=runs)
M3_est <- matrix(NA,nrow=param,ncol=runs)
M3_CI <- matrix(NA,nrow=param,ncol=runs)
M3_CI2 <- matrix(NA,nrow=param,ncol=runs)
M3_CI3 <- matrix(NA,nrow=param,ncol=runs)
M4_CI <- matrix(NA,nrow=param,ncol=runs)
M4_CI2 <- matrix(NA,nrow=param,ncol=runs)
M4_CI3 <- matrix(NA,nrow=param,ncol=runs)
M5_CI <- matrix(NA,nrow=param,ncol=runs)
M5_CI2 <- matrix(NA,nrow=param,ncol=runs)
M5_CI3 <- matrix(NA,nrow=param,ncol=runs)
M6_CI <- matrix(NA,nrow=param,ncol=runs)
M6_CI2 <- matrix(NA,nrow=param,ncol=runs)
M6_CI3 <- matrix(NA,nrow=param,ncol=runs)
M1_width <- matrix(NA,nrow=param,ncol=runs)
M2_width <- matrix(NA,nrow=param,ncol=runs)
M3_width <- matrix(NA,nrow=param,ncol=runs)
M4_width <- matrix(NA,nrow=param,ncol=runs)
M5_width <- matrix(NA,nrow=param,ncol=runs)
M6_width <- matrix(NA,nrow=param,ncol=runs)
M2_se <- matrix(NA,nrow=param,ncol=runs)
M5_se <- matrix(NA,nrow=param,ncol=runs)
M6_se <- matrix(NA,nrow=param,ncol=runs)
M5_est <- matrix(NA,nrow=param,ncol=runs)
M6_est <- matrix(NA,nrow=param,ncol=runs)
Summary1 <- rep(list(rep(list(matrix(NA,ncol=7,nrow=1,dimnames=NULL) ),B)),M)
Summary2 <- rep(list(rep(list(matrix(NA,ncol=7,nrow=1,dimnames=NULL) ),M)),B)
Summary1_save <- rep(list(NA),runs)
Summary2_save <- rep(list(NA),runs)
Summary3_save <- rep(list(NA),runs)
Summary1_save2 <- rep(list(NA),runs)
Summary2_save2 <- rep(list(NA),runs)


# Simulation loop
for (r in 1:runs)try({
cat("This is simulation run",r,"\n" )
ptm.ib <- proc.time()

ntrain <- 1000        
mycopula <-  mvdc(claytonCopula(1, dim=6),c("norm","norm","norm","binom","binom","binom"),list(list(mean=0, sd=1),list(mean=0, sd=1),list(mean=0, sd=1),list(size=1, prob=0.5),list(size=1, prob=0.7),list(size=1, prob=0.3)))
mycovdata <- rMvdc(ntrain,mycopula)
colnames(mycovdata)<- c("p1","p2","p3","p4","p5","p6")
mycovdata <- as.data.frame(mycovdata)
mu    <- 3 - 2*mycovdata$p1 + 3*mycovdata$p3 -  4*mycovdata$p5 
mysigma <- 2
y <- rnorm(ntrain, mu, mysigma)

true <- c(3,-2,0,3,0,-4,0)
mynull <- c(rep(0,param))
mygood <- c(0,0,1,0,1,0,1)

probab   <-  1-(1/((aa*y)^2+1))
probab2  <-  1-(1/(1+(bb*(mycovdata$p4^3)+0.05)))
probab3  <-  rep(0,length(probab))#1-(1/(1+(exp(mycovdata$p2)/16)))

p1mis <- mycovdata$p1
p3mis <- mycovdata$p3
p6mis <- mycovdata$p6

for(k in 1:ntrain){p1mis[k] <- sample(c(mycovdata$p1[k],NA),1,prob=c(1-probab[k],probab[k]))}
for(k in 1:ntrain){p3mis[k] <- sample(c(mycovdata$p3[k],NA),1,prob=c(1-probab2[k],probab2[k]))}
for(k in 1:ntrain){p6mis[k] <- sample(c(mycovdata$p6[k],NA),1,prob=c(1-probab3[k],probab3[k]))}

dataex <- as.data.frame(cbind(y,p1mis,mycovdata$p2,p3mis,mycovdata$p4,mycovdata$p5,p6mis))
colnames(dataex)<-c("y","p1","p2","p3","p4","p5","p6")
original <- as.data.frame(cbind(y,mycovdata$p1,mycovdata$p2,mycovdata$p3,mycovdata$p4,mycovdata$p5,mycovdata$p6))
colnames(original)<-c("y","p1","p2","p3","p4","p5","p6")

# Check missingness properties  
avmis <- function(myvector){
return(mean(is.na(myvector)))
}
avmistot <- function(myvector){
return(any(is.na(myvector)))
}
missingstat <- apply(dataex,c(2),avmis)
missingstat2 <- mean(apply(dataex,c(1),avmistot))
missingstat <- round(c(missingstat,missingstat2),digits=4)
names(missingstat)<-c("y","p1","p2","p3","p4","p5","p6","total")
missingstat_total <- missingstat_total+missingstat


# Imputations 
M=M                             

dataex_imp <- amelia(dataex,p2s=0,m=M,noms=c(5,6,7))
for(m in 1:M){
impname <- (paste("c",m,sep=""))
assign(impname, dataex_imp$imputations[[m]])
}

###########################
## Parameter estimation ###
###########################


###################################
# Loop: Imputation
for(m in 1:M)try({
mydata <- get(paste("c",m,sep=""))

# Loop: Bootstrap
for(b in 1:B)try({
if(b==1){mydata<-get(paste("c",m,sep=""))} # in the first run we take the original data, afterwards bootstrap samples
if(b>1){mydata<-get(paste("c",m,sep=""))[sample(dim(get(paste("c",m,sep="")))[1],replace=TRUE),]}

m1 <- lm(y~., data=mydata)

Summary1[[m]][[b]] <- coefficients(m1)


}) # End: loop Bootstrap

}) # End: loop imputation

#############
# Method 1  #
#############

sPool       <- lapply(lapply(Summary1,unlist),matrix,ncol=B)
Summary1.1_CI <- do.call(cbind, lapply(sPool, unlist))
Summary1.1    <-  matrix(Summary1.1_CI[,c(seq(1,(B*M)-(B-1),B))],ncol=M)
Summary1_save[[r]]  <- sPool
Summary1_save2[[r]] <- Summary1.1_CI
upper95<-function(myvector){quantile(myvector, probs=0.975, na.rm=T)}
lower95<-function(myvector){quantile(myvector, probs=0.025, na.rm=T)}

M1data <- as.data.frame(cbind(apply(Summary1.1 ,1,mean),apply(Summary1.1_CI,1,lower95),apply(Summary1.1_CI,1,upper95)))
colnames(M1data) <- c("est","l95","u95")

include_true_M1 <- as.numeric((M1data$l95 <= true) & (M1data$u95>= true))
include_null_M1 <- as.numeric((M1data$l95 <= mynull) & (M1data$u95 >= mynull))
include_good_M1 <- as.numeric((mygood==include_null_M1) & (M1data$l95 <= true) & (M1data$u95>= true))

width_M1 <- M1data$u95-M1data$l95

M_est[,r]       <- M1data$est
M1_CI[,r]       <- include_true_M1
M1_CI2[,r]      <- include_null_M1
M1_CI3[,r]      <- include_good_M1
M1_width[,r]    <- width_M1

#############
# Method 2  #
#############

myse <- function(mymatrix){apply(mymatrix,1,sd)}
Summary1.2.all.est <- rep(list(NULL),M)
for(m in 1:M){Summary1.2.all.est[[m]] <- Summary1.1[,m]}
Summary1.2.all.se <- lapply(sPool,myse)
if(M>1){Summary1.2 <- mi.inference2(Summary1.2.all.est, Summary1.2.all.se, confidence=0.95)}
if(M==1){Summary1.2 <- list(lower=unlist(Summary1.2.all.est)-qt(0.975,df=ntrain-param)*unlist(Summary1.2.all.se),upper=unlist(Summary1.2.all.est)+qt(0.975,df=ntrain-param)*unlist(Summary1.2.all.se),std.err=unlist(Summary1.2.all.se))}

include_true_M2 <- as.numeric((Summary1.2$lower <= true) & (Summary1.2$upper>= true))
include_null_M2 <- as.numeric((Summary1.2$lower <= mynull) & (Summary1.2$upper >= mynull))
include_good_M2 <- as.numeric((mygood==include_null_M2) & (Summary1.2$lower <= true) & (Summary1.2$upper>= true))

width_M2 <- Summary1.2$upper-Summary1.2$lower


M2_CI[,r]  <- include_true_M2
M2_CI2[,r]  <- include_null_M2
M2_CI3[,r]  <- include_good_M2
M2_width[,r]   <- width_M2
M2_se[,r] <- Summary1.2$std.err


#############
# Method 3  #
#############

M3a_est <- matrix(NA,nrow=param,ncol=B)

# Loop: Bootstrap
for(b in 1:B)try({
if(b==1){mydata<-dataex} 
if(b>1){mydata<-dataex[sample(dim(dataex)[1],replace=TRUE),]}

dataex_imp2 <- amelia(mydata,p2s=0,m=M,noms=c("p4","p5","p6"))

for(m in 1:M){
impname <- (paste("m2.",m,sep=""))
assign(impname, lm(y~., data=as.data.frame(dataex_imp2$imputations[[m]])))
}

m3coef<-eval(parse(text=paste("list(",paste(paste("summary(m2.",seq(1:M),")[[4]][,1]",sep=""),sep=",", collapse=","),")")))
m3se <- eval(parse(text=paste("list(",paste(paste("summary(m2.",seq(1:M),")[[4]][,2]",sep=""),sep=",", collapse=","),")")))
if(M>1){Summary1.3a <- mi.inference2(m3coef, m3se, confidence=0.95)}
if(M==1){Summary1.3a <- list(est=unlist(m3coef),lower=unlist(m3coef)-qt(0.975,df=ntrain-param)*unlist(m3se),upper=unlist(m3coef)+qt(0.975,df=ntrain-param)*unlist(m3se))}
if(b==1){M3_est[,r]<-Summary1.3a$est}
M3a_est[,b] <- Summary1.3a$est
for(m in 1:M){Summary2[[b]][[m]] <- m3coef[[m]]}
}) # End: loop Bootstrap

include_true_M3 <- as.numeric((apply(M3a_est,1,lower95) <= true)   & (apply(M3a_est,1,upper95)>= true))
include_null_M3 <- as.numeric((apply(M3a_est,1,lower95) <= mynull) & (apply(M3a_est,1,upper95)>= mynull))
include_good_M3 <- as.numeric((mygood==include_null_M3) & (apply(M3a_est,1,lower95) <= true)   & (apply(M3a_est,1,upper95)>= true))
width_M3 <- apply(M3a_est,1,upper95)-(apply(M3a_est,1,lower95))

M3_CI[,r]       <- include_true_M3
M3_CI2[,r]      <- include_null_M3
M3_CI3[,r]      <- include_good_M3
M3_width[,r]    <- width_M3
Summary3_save[[r]]  <- M3a_est

#############
# Method 4  #
#############


sPool4       <- lapply(lapply(Summary2,unlist),matrix,ncol=M)
Summary2.1_CI <- do.call(cbind, lapply(sPool4, unlist))
Summary2_save[[r]]  <- sPool4
Summary2_save2[[r]] <- Summary2.1_CI
M4data <- as.data.frame(cbind(apply(Summary2.1_CI,1,lower95),apply(Summary2.1_CI,1,upper95)))
colnames(M4data) <- c("l95","u95")

include_true_M4 <- as.numeric((M4data$l95 <= true) & (M4data$u95>= true))
include_null_M4 <- as.numeric((M4data$l95 <= mynull) & (M4data$u95>= mynull))
include_good_M4 <- as.numeric((mygood==include_null_M4) & (M4data$l95 <= true) & (M4data$u95>= true))
width_M4 <- M4data$u95-M4data$l95

M4_CI[,r]   <- include_true_M4
M4_CI2[,r]  <- include_null_M4
M4_CI3[,r]  <- include_good_M4
M4_width[,r]   <- width_M4

###############################
# Method 5: Without Bootstrap #
###############################
mycoeffs <- eval(parse(text=paste("list(",paste(paste("coef(lm(y~.,data=c",seq(1:M),"))",sep=""),sep=",", collapse=","),")")))
mystds <- eval(parse(text=paste("list(",paste(paste("summary(lm(y~.,data=c",seq(1:M),"))[[4]][,2]",sep=""),sep=",", collapse=","),")")))
if(M>1){Summary1.5 <- mi.inference2(mycoeffs, mystds, confidence=0.95)}
if(M==1){Summary1.5 <- list(est=unlist(mycoeffs),std.err=unlist(mystds),lower=unlist(mycoeffs)-qt(0.975,df=ntrain-param)*unlist(mystds),upper=unlist(mycoeffs)+qt(0.975,df=ntrain-param)*unlist(mystds))}

include_true_M5 <- as.numeric((Summary1.5$lower <= true) & (Summary1.5$upper>= true))
include_null_M5 <- as.numeric((Summary1.5$lower <= mynull) & (Summary1.5$upper>= mynull))
include_good_M5 <- as.numeric((mygood==include_null_M5) & (Summary1.5$lower <= true) & (Summary1.5$upper>= true))
width_M5 <- Summary1.5$upper-Summary1.5$lower

M5_CI[,r]   <- include_true_M5
M5_CI2[,r]  <- include_null_M5
M5_CI3[,r]  <- include_good_M5
M5_width[,r]   <- width_M5
M5_se[,r] <- Summary1.5$std.err
M5_est[,r] <- Summary1.5$est

################################################
# Method 6: original data without missing data #
################################################

m6      <- lm(y~.,data=original)

Summary1.6      <- list(est=coef(m6),lower=coef(m6)-qt(0.975,df=ntrain-param)*summary(m6)[[4]][,2],upper=coef(m6)+qt(0.975,df=ntrain-param)*summary(m6)[[4]][,2])
include_true_M6 <- as.numeric((Summary1.6$lower <= true) & (Summary1.6$upper>= true))
include_null_M6 <- as.numeric((Summary1.6$lower <= mynull) & (Summary1.6$upper>= mynull))
include_good_M6 <- as.numeric((mygood==include_null_M6) & (Summary1.6$lower <= true) & (Summary1.6$upper>= true))
width_M6 <- Summary1.6$upper-Summary1.6$lower

M6_CI[,r]        <- include_true_M6
M6_CI2[,r]       <- include_null_M6
M6_CI3[,r]       <- include_good_M6
M6_width[,r]     <- width_M6
M6_se[,r]        <- summary(m6)[[4]][,2]
M6_est[,r]       <- coef(m6)

###############################################
ptm.ib2 <- proc.time()
ibt <- round(((ptm.ib2-ptm.ib)/60)[1],digits=2)
if(r==1){cat(paste("The simulation will run for about another", runs*ibt-ibt, "minutes \n"))}

}) # End: loop simulation runs


###################
# Produce results #
###################

s_est_a   <- apply(M_est[,!apply(M_est,2,is.na)[1,]],1,mean)
s_est3_a <-  apply(M3_est[,!apply(M3_est,2,is.na)[1,]],1,mean)
s_est5_a <-  apply(M5_est[,!apply(M5_est,2,is.na)[1,]],1,mean)

s_CI1_a <- apply(M1_CI[,!apply(M1_CI,2,is.na)[1,]],1,mean)
s_CI2_a <- apply(M2_CI[,!apply(M2_CI,2,is.na)[1,]],1,mean)
s_CI3_a <- apply(M3_CI[,!apply(M3_CI,2,is.na)[1,]],1,mean)
s_CI4_a <- apply(M4_CI[,!apply(M4_CI,2,is.na)[1,]],1,mean)
s_CI5_a <- apply(M5_CI[,!apply(M5_CI,2,is.na)[1,]],1,mean)
s_CI6_a <- apply(M6_CI[,!apply(M6_CI,2,is.na)[1,]],1,mean)

s_CI1_b <- apply(M1_CI2[,!apply(M1_CI2,2,is.na)[1,]],1,mean)
s_CI2_b <- apply(M2_CI2[,!apply(M2_CI2,2,is.na)[1,]],1,mean)
s_CI3_b <- apply(M3_CI2[,!apply(M3_CI2,2,is.na)[1,]],1,mean)
s_CI4_b <- apply(M4_CI2[,!apply(M4_CI2,2,is.na)[1,]],1,mean)
s_CI5_b <- apply(M5_CI2[,!apply(M5_CI2,2,is.na)[1,]],1,mean)
s_CI6_b <- apply(M6_CI2[,!apply(M6_CI2,2,is.na)[1,]],1,mean)

s_CI1_c <- apply(M1_CI3[,!apply(M1_CI3,2,is.na)[1,]],1,mean)
s_CI2_c <- apply(M2_CI3[,!apply(M2_CI3,2,is.na)[1,]],1,mean)
s_CI3_c <- apply(M3_CI3[,!apply(M3_CI3,2,is.na)[1,]],1,mean)
s_CI4_c <- apply(M4_CI3[,!apply(M4_CI3,2,is.na)[1,]],1,mean)
s_CI5_c <- apply(M5_CI3[,!apply(M5_CI3,2,is.na)[1,]],1,mean)
s_CI6_c <- apply(M6_CI3[,!apply(M6_CI3,2,is.na)[1,]],1,mean)

s_W1 <- apply(M1_width[,!apply(M1_width,2,is.na)[1,]],1,median)
s_W2 <- apply(M2_width[,!apply(M2_width,2,is.na)[1,]],1,median)
s_W3 <- apply(M3_width[,!apply(M3_width,2,is.na)[1,]],1,median)
s_W4 <- apply(M4_width[,!apply(M4_width,2,is.na)[1,]],1,median)
s_W5 <- apply(M5_width[,!apply(M5_width,2,is.na)[1,]],1,median)
s_W6 <- apply(M6_width[,!apply(M6_width,2,is.na)[1,]],1,median)

mruns <- sum(apply(M1_CI,2,is.na)[1,])
mruns2 <- sum(apply(M2_CI,2,is.na)[1,])
mruns3 <- sum(apply(M3_CI,2,is.na)[1,])
mruns4 <- sum(apply(M4_CI,2,is.na)[1,])
mruns5 <- sum(apply(M5_CI,2,is.na)[1,])
mruns6 <- sum(apply(M6_CI,2,is.na)[1,])
cat(paste("Number of failed runs for the 6 methods:",mruns,mruns2,mruns3,mruns4,mruns5,mruns6),"\n")
missruns <- paste("Number of failed runs for the 6 methods:",mruns,mruns2,mruns3,mruns4,mruns5,mruns6)


# Summarize the distribution
pdf(file=paste(directory,"/Fig1a.pdf",sep=""))
mymax = max(density(M5_est[2,],na.rm=T)$y)+0.1
plot(density(Summary1.1_CI[2,],na.rm=T),main="",sub="",xlab="",lwd=3,lty=3,ylim=c(0,mymax),col="darkgrey")
lines(density(Summary2.1_CI[2,],na.rm=T),main="",sub="",xlab="",lwd=3,lty=2,col="red")
lines(density(M5_est[2,],na.rm=T),main="",sub="",xlab="",lwd=3,lty=1,col="black")
lines(density(M3a_est[2,],na.rm=T),main="",sub="",xlab="",lwd=3,lty=4,col="blue")
axis(side = 1 , at = true[2], labels = F , tick = T , tcl = 1 , lwd.ticks = 3 , col.ticks = "blue")
legend("topright",lty=c(3,4,2,1),legend=c("Method 1","Method 3","Method 4","Method 5"), lwd=3, cex=1.25, col=c("darkgrey","blue","red","black"))
dev.off()

pdf(file=paste(directory,"/Fig1b.pdf",sep=""))
mymax = max(density(M5_est[3,],na.rm=T)$y)+0.1
plot(density(Summary1.1_CI[3,],na.rm=T),main="",sub="",xlab="",lwd=3,lty=3,ylim=c(0,mymax),col="darkgrey")
lines(density(Summary2.1_CI[3,],na.rm=T),main="",sub="",xlab="",lwd=3,lty=2,col="red")
lines(density(M5_est[3,],na.rm=T),main="",sub="",xlab="",lwd=3,lty=1,col="black")
lines(density(M3a_est[3,],na.rm=T),main="",sub="",xlab="",lwd=3,lty=4,col="blue")
axis(side = 1 , at = true[3], labels = F , tick = T , tcl = 1 , lwd.ticks = 3 , col.ticks = "blue")
legend("topright",lty=c(3,4,2,1),legend=c("Method 1","Method 3","Method 4","Method 5"), lwd=3, cex=1.25, col=c("darkgrey","blue","red","black"))
dev.off()

pdf(file=paste(directory,"/Fig1c.pdf",sep=""))
mymax = max(density(M5_est[4,],na.rm=T)$y)+0.1
plot(density(Summary1.1_CI[4,],na.rm=T),main="",sub="",xlab="",lwd=3,lty=3,ylim=c(0,mymax),col="darkgrey")
lines(density(Summary2.1_CI[4,],na.rm=T),main="",sub="",xlab="",lwd=3,lty=2,col="red")
lines(density(M5_est[4,],na.rm=T),main="",sub="",xlab="",lwd=3,lty=1,col="black")
lines(density(M3a_est[4,],na.rm=T),main="",sub="",xlab="",lwd=3,lty=4,col="blue")
axis(side = 1 , at = true[4], labels = F , tick = T , tcl = 1 , lwd.ticks = 3 , col.ticks = "blue")
legend("topright",lty=c(3,4,2,1),legend=c("Method 1","Method 3","Method 4","Method 5"), lwd=3, cex=1.25, col=c("darkgrey","blue","red","black"))
dev.off()

pdf(file=paste(directory,"/Fig1d.pdf",sep=""))
mymax = max(density(M5_est[5,],na.rm=T)$y)+0.1
plot(density(Summary1.1_CI[5,],na.rm=T),main="",sub="",xlab="",lwd=3,lty=3,ylim=c(0,mymax),col="darkgrey")
lines(density(Summary2.1_CI[5,],na.rm=T),main="",sub="",xlab="",lwd=3,lty=2,col="red")
lines(density(M5_est[5,],na.rm=T),main="",sub="",xlab="",lwd=3,lty=1,col="black")
lines(density(M3a_est[5,],na.rm=T),main="",sub="",xlab="",lwd=3,lty=4,col="blue")
axis(side = 1 , at = true[5], labels = F , tick = T , tcl = 1 , lwd.ticks = 3 , col.ticks = "blue")
legend("topright",lty=c(3,4,2,1),legend=c("Method 1","Method 3","Method 4","Method 5"), lwd=3, cex=1.25, col=c("darkgrey","blue","red","black"))
dev.off()

pdf(file=paste(directory,"/Fig1e.pdf",sep=""))
mymax = max(density(M5_est[6,],na.rm=T)$y)+0.1
plot(density(Summary1.1_CI[6,],na.rm=T),main="",sub="",xlab="",lwd=3,lty=3,ylim=c(0,mymax),col="darkgrey")
lines(density(Summary2.1_CI[6,],na.rm=T),main="",sub="",xlab="",lwd=3,lty=2,col="red")
lines(density(M5_est[6,],na.rm=T),main="",sub="",xlab="",lwd=3,lty=1,col="black")
lines(density(M3a_est[6,],na.rm=T),main="",sub="",xlab="",lwd=3,lty=4,col="blue")
axis(side = 1 , at = true[6], labels = F , tick = T , tcl = 1 , lwd.ticks = 3 , col.ticks = "blue")
legend("topright",lty=c(3,4,2,1),legend=c("Method 1","Method 3","Method 4","Method 5"), lwd=3, cex=1.25, col=c("darkgrey","blue","red","black"))
dev.off()

pdf(file=paste(directory,"/Fig1f.pdf",sep=""))
mymax = max(density(M5_est[7,],na.rm=T)$y)+0.1
plot(density(Summary1.1_CI[7,],na.rm=T),main="",sub="",xlab="",lwd=3,lty=3,ylim=c(0,mymax),col="darkgrey")
lines(density(Summary2.1_CI[7,],na.rm=T),main="",sub="",xlab="",lwd=3,lty=2,col="red")
lines(density(M5_est[7,],na.rm=T),main="",sub="",xlab="",lwd=3,lty=1,col="black")
lines(density(M3a_est[7,],na.rm=T),main="",sub="",xlab="",lwd=3,lty=4,col="blue")
axis(side = 1 , at = true[7], labels = F , tick = T , tcl = 1 , lwd.ticks = 3 , col.ticks = "blue")
legend("topright",lty=c(3,4,2,1),legend=c("Method 1","Method 3","Method 4","Method 5"), lwd=3, cex=1.25, col=c("darkgrey","blue","red","black"))
dev.off()

mydensity <- function(mymatrix){density(mymatrix[2,],na.rm=T)}
mydensity3 <- function(mymatrix){density(mymatrix[3,],na.rm=T)}
mydensity4 <- function(mymatrix){density(mymatrix[4,],na.rm=T)}
mydensity5 <- function(mymatrix){density(mymatrix[5,],na.rm=T)}
mydensity6 <- function(mymatrix){density(mymatrix[6,],na.rm=T)}
mydensity7 <- function(mymatrix){density(mymatrix[7,],na.rm=T)}
pymax <- function(myd){max(myd$y)}
pxmax <- function(myd){max(myd$x)}
pxmin <- function(myd){min(myd$x)}

myymax <- max(unlist(lapply(lapply(sPool,mydensity),pymax)))+0.1
myxmax <- max(unlist(lapply(lapply(sPool,mydensity),pxmax)))+0.05
myxmin <- min(unlist(lapply(lapply(sPool,mydensity),pxmin)))-0.05
pdf(file=paste(directory,"/Fig2a.pdf",sep=""))
plot(NULL,ylim=c(0,myymax),xlim=c(myxmin,myxmax),xlab="",ylab="Density")
for(i in 1:M){lines(density(sPool[[i]][2,],na.rm=T),col=i,lwd=2)}
axis(side = 1 , at = true[2], labels = F , tick = T , tcl = 1 , lwd.ticks = 3 , col.ticks = "blue")
lines(c(-5,5),c(0,0),type="l",col="lightgrey")
dev.off()

if(M>1){
myymax <- max(unlist(lapply(lapply(sPool4,mydensity),pymax)))+0.1
pdf(file=paste(directory,"/Fig4a.pdf",sep=""))
plot(NULL,ylim=c(0,myymax),xlim=c(myxmin,myxmax),xlab="",ylab="Density")
for(i in 1:B){lines(density(sPool4[[i]][2,],na.rm=T),col=1,lwd=0.35)}
axis(side = 1 , at = true[2], labels = F , tick = T , tcl = 1 , lwd.ticks = 3 , col.ticks = "blue")
lines(c(-5,5),c(0,0),type="l",col="lightgrey")
dev.off()


myxmax <- max(unlist(lapply(lapply(sPool4,mydensity),pxmax)))+0.05
myxmin <- min(unlist(lapply(lapply(sPool4,mydensity),pxmin)))-0.05
pdf(file=paste(directory,"/Fig3a.pdf",sep=""))
plot(NULL,ylim=c(0,myymax),xlim=c(myxmin,myxmax),xlab="",ylab="Density")
for(i in 1:B){lines(density(sPool4[[i]][2,],na.rm=T),col=1,lwd=0.35)}
axis(side = 1 , at = true[2], labels = F , tick = T , tcl = 1 , lwd.ticks = 3 , col.ticks = "blue")
lines(c(-5,5),c(0,0),type="l",col="lightgrey")
dev.off()
}


myymax <- max(unlist(lapply(lapply(sPool,mydensity3),pymax)))+0.1
myxmax <- max(unlist(lapply(lapply(sPool,mydensity3),pxmax)))+0.05
myxmin <- min(unlist(lapply(lapply(sPool,mydensity3),pxmin)))-0.05
pdf(file=paste(directory,"/Fig2b.pdf",sep=""))
plot(NULL,ylim=c(0,myymax),xlim=c(myxmin,myxmax),xlab="",ylab="Density")
for(i in 1:M){lines(density(sPool[[i]][3,],na.rm=T),col=i,lwd=2)}
axis(side = 1 , at = true[3], labels = F , tick = T , tcl = 1 , lwd.ticks = 3 , col.ticks = "blue")
lines(c(-5,5),c(0,0),type="l",col="lightgrey")
dev.off()

if(M>1){
myymax <- max(unlist(lapply(lapply(sPool4,mydensity3),pymax)))+0.1
pdf(file=paste(directory,"/Fig4b.pdf",sep=""))
plot(NULL,ylim=c(0,myymax),xlim=c(myxmin,myxmax),xlab="",ylab="Density")
for(i in 1:B){lines(density(sPool4[[i]][3,],na.rm=T),col=1,lwd=0.35)}
axis(side = 1 , at = true[3], labels = F , tick = T , tcl = 1 , lwd.ticks = 3 , col.ticks = "blue")
lines(c(-5,5),c(0,0),type="l",col="lightgrey")
dev.off()

myxmax <- max(unlist(lapply(lapply(sPool4,mydensity3),pxmax)))+0.05
myxmin <- min(unlist(lapply(lapply(sPool4,mydensity3),pxmin)))-0.05
pdf(file=paste(directory,"/Fig3b.pdf",sep=""))
plot(NULL,ylim=c(0,myymax),xlim=c(myxmin,myxmax),xlab="",ylab="Density")
for(i in 1:B){lines(density(sPool4[[i]][3,],na.rm=T),col=1,lwd=0.35)}
axis(side = 1 , at = true[3], labels = F , tick = T , tcl = 1 , lwd.ticks = 3 , col.ticks = "blue")
lines(c(-5,5),c(0,0),type="l",col="lightgrey")
dev.off()
}

myymax <- max(unlist(lapply(lapply(sPool,mydensity4),pymax)))+0.1
myxmax <- max(unlist(lapply(lapply(sPool,mydensity4),pxmax)))+0.05
myxmin <- min(unlist(lapply(lapply(sPool,mydensity4),pxmin)))-0.05
pdf(file=paste(directory,"/Fig2c.pdf",sep=""))
plot(NULL,ylim=c(0,myymax),xlim=c(myxmin,myxmax),xlab="",ylab="Density")
for(i in 1:M){lines(density(sPool[[i]][4,],na.rm=T),col=i,lwd=2)}
axis(side = 1 , at = true[4], labels = F , tick = T , tcl = 1 , lwd.ticks = 3 , col.ticks = "blue")
lines(c(-5,5),c(0,0),type="l",col="lightgrey")
dev.off()

if(M>1){
myymax <- max(unlist(lapply(lapply(sPool4,mydensity4),pymax)))+0.1
pdf(file=paste(directory,"/Fig4c.pdf",sep=""))
plot(NULL,ylim=c(0,myymax),xlim=c(myxmin,myxmax),xlab="",ylab="Density")
for(i in 1:B){lines(density(sPool4[[i]][4,],na.rm=T),col=1,lwd=0.35)}
axis(side = 1 , at = true[4], labels = F , tick = T , tcl = 1 , lwd.ticks = 3 , col.ticks = "blue")
lines(c(-5,5),c(0,0),type="l",col="lightgrey")
dev.off()

myxmax <- max(unlist(lapply(lapply(sPool4,mydensity4),pxmax)))+0.05
myxmin <- min(unlist(lapply(lapply(sPool4,mydensity4),pxmin)))-0.05
pdf(file=paste(directory,"/Fig3c.pdf",sep=""))
plot(NULL,ylim=c(0,myymax),xlim=c(myxmin,myxmax),xlab="",ylab="Density")
for(i in 1:B){lines(density(sPool4[[i]][4,],na.rm=T),col=1,lwd=0.35)}
axis(side = 1 , at = true[4], labels = F , tick = T , tcl = 1 , lwd.ticks = 3 , col.ticks = "blue")
lines(c(-5,5),c(0,0),type="l",col="lightgrey")
dev.off()
}


myymax <- max(unlist(lapply(lapply(sPool,mydensity5),pymax)))+0.1
myxmax <- max(unlist(lapply(lapply(sPool,mydensity5),pxmax)))+0.05
myxmin <- min(unlist(lapply(lapply(sPool,mydensity5),pxmin)))-0.05
pdf(file=paste(directory,"/Fig2d.pdf",sep=""))
plot(NULL,ylim=c(0,myymax),xlim=c(myxmin,myxmax),xlab="",ylab="Density")
for(i in 1:M){lines(density(sPool[[i]][5,],na.rm=T),col=i,lwd=2)}
axis(side = 1 , at = true[5], labels = F , tick = T , tcl = 1 , lwd.ticks = 3 , col.ticks = "blue")
lines(c(-5,5),c(0,0),type="l",col="lightgrey")
dev.off()

if(M>1){
myymax <- max(unlist(lapply(lapply(sPool4,mydensity5),pymax)))+0.1
pdf(file=paste(directory,"/Fig4d.pdf",sep=""))
plot(NULL,ylim=c(0,myymax),xlim=c(myxmin,myxmax),xlab="",ylab="Density")
for(i in 1:B){lines(density(sPool4[[i]][5,],na.rm=T),col=1,lwd=0.35)}
axis(side = 1 , at = true[5], labels = F , tick = T , tcl = 1 , lwd.ticks = 3 , col.ticks = "blue")
lines(c(-5,5),c(0,0),type="l",col="lightgrey")
dev.off()

myxmax <- max(unlist(lapply(lapply(sPool4,mydensity5),pxmax)))+0.05
myxmin <- min(unlist(lapply(lapply(sPool4,mydensity5),pxmin)))-0.05
pdf(file=paste(directory,"/Fig3d.pdf",sep=""))
plot(NULL,ylim=c(0,myymax),xlim=c(myxmin,myxmax),xlab="",ylab="Density")
for(i in 1:B){lines(density(sPool4[[i]][5,],na.rm=T),col=1,lwd=0.35)}
axis(side = 1 , at = true[5], labels = F , tick = T , tcl = 1 , lwd.ticks = 3 , col.ticks = "blue")
lines(c(-5,5),c(0,0),type="l",col="lightgrey")
dev.off()
}

myymax <- max(unlist(lapply(lapply(sPool,mydensity6),pymax)))+0.1
myxmax <- max(unlist(lapply(lapply(sPool,mydensity6),pxmax)))+0.05
myxmin <- min(unlist(lapply(lapply(sPool,mydensity6),pxmin)))-0.05
pdf(file=paste(directory,"/Fig2e.pdf",sep=""))
plot(NULL,ylim=c(0,myymax),xlim=c(myxmin,myxmax),xlab="",ylab="Density")
for(i in 1:M){lines(density(sPool[[i]][6,],na.rm=T),col=i,lwd=2)}
axis(side = 1 , at = true[6], labels = F , tick = T , tcl = 1 , lwd.ticks = 3 , col.ticks = "blue")
lines(c(-5,5),c(0,0),type="l",col="lightgrey")
dev.off()

if(M>1){
myymax <- max(unlist(lapply(lapply(sPool4,mydensity6),pymax)))+0.1
pdf(file=paste(directory,"/Fig4e.pdf",sep=""))
plot(NULL,ylim=c(0,myymax),xlim=c(myxmin,myxmax),xlab="",ylab="Density")
for(i in 1:B){lines(density(sPool4[[i]][6,],na.rm=T),col=1,lwd=0.35)}
axis(side = 1 , at = true[6], labels = F , tick = T , tcl = 1 , lwd.ticks = 3 , col.ticks = "blue")
lines(c(-5,5),c(0,0),type="l",col="lightgrey")
dev.off()

myxmax <- max(unlist(lapply(lapply(sPool4,mydensity6),pxmax)))+0.05
myxmin <- min(unlist(lapply(lapply(sPool4,mydensity6),pxmin)))-0.05
pdf(file=paste(directory,"/Fig3e.pdf",sep=""))
plot(NULL,ylim=c(0,myymax),xlim=c(myxmin,myxmax),xlab="",ylab="Density")
for(i in 1:B){lines(density(sPool4[[i]][6,],na.rm=T),col=1,lwd=0.35)}
axis(side = 1 , at = true[6], labels = F , tick = T , tcl = 1 , lwd.ticks = 3 , col.ticks = "blue")
lines(c(-5,5),c(0,0),type="l",col="lightgrey")
dev.off()
}

myymax <- max(unlist(lapply(lapply(sPool,mydensity7),pymax)))+0.1
myxmax <- max(unlist(lapply(lapply(sPool,mydensity7),pxmax)))+0.05
myxmin <- min(unlist(lapply(lapply(sPool,mydensity7),pxmin)))-0.05
pdf(file=paste(directory,"/Fig2f.pdf",sep=""))
plot(NULL,ylim=c(0,myymax),xlim=c(myxmin,myxmax),xlab="",ylab="Density")
for(i in 1:M){lines(density(sPool[[i]][7,],na.rm=T),col=i,lwd=2)}
axis(side = 1 , at = true[7], labels = F , tick = T , tcl = 1 , lwd.ticks = 3 , col.ticks = "blue")
lines(c(-5,5),c(0,0),type="l",col="lightgrey")
dev.off()

if(M>1){
myymax <- max(unlist(lapply(lapply(sPool4,mydensity7),pymax)))+0.1
pdf(file=paste(directory,"/Fig4f.pdf",sep=""))
plot(NULL,ylim=c(0,myymax),xlim=c(myxmin,myxmax),xlab="",ylab="Density")
for(i in 1:B){lines(density(sPool4[[i]][7,],na.rm=T),col=1,lwd=0.35)}
axis(side = 1 , at = true[7], labels = F , tick = T , tcl = 1 , lwd.ticks = 3 , col.ticks = "blue")
lines(c(-5,5),c(0,0),type="l",col="lightgrey")
dev.off()

myxmax <- max(unlist(lapply(lapply(sPool4,mydensity7),pxmax)))+0.05
myxmin <- min(unlist(lapply(lapply(sPool4,mydensity7),pxmin)))-0.05
pdf(file=paste(directory,"/Fig3f.pdf",sep=""))
plot(NULL,ylim=c(0,myymax),xlim=c(myxmin,myxmax),xlab="",ylab="Density")
for(i in 1:B){lines(density(sPool4[[i]][7,],na.rm=T),col=1,lwd=0.35)}
axis(side = 1 , at = true[7], labels = F , tick = T , tcl = 1 , lwd.ticks = 3 , col.ticks = "blue")
lines(c(-5,5),c(0,0),type="l",col="lightgrey")
dev.off()
}


prf   <-  function(y){1-(1/((0.075*y)^2+1))}
prf2   <-  function(y){1-(1/(1+(0.05*(y^3))))}
prf3   <-  function(y){1-(1/(1+(exp(y)/16)))}
xval  <- c(seq(-15,15,0.1))
xval2  <- c(seq(0,12,0.1))
xval3  <- c(seq(-5,5,0.1))

pdf(file=paste(directory,"/Fig6a.pdf",sep=""))
plot(xval,prf(xval),type="l",lwd=3,xlab="y",ylab="Pr(Missingness)")  
dev.off()

pdf(file=paste(directory,"/Fig6b.pdf",sep=""))
plot(xval2,prf2(xval2),type="l",lwd=3,xlab="y",ylab="Pr(Missingness)")  
dev.off()

pdf(file=paste(directory,"/Fig6c.pdf",sep=""))
plot(xval3,prf3(xval3),type="l",lwd=3,xlab="y",ylab="Pr(Missingness)")  
dev.off()

# How long did it take?
ptm2 <-  proc.time()
simulationsdauer <- ptm2-ptm
simulationsdauer <- (simulationsdauer/60)
simulationsdauer <- round(simulationsdauer[1], digits=2)
cat(paste("The simulation time was", simulationsdauer, "minutes \n"))
finaltime <-  paste("The simulation time was", simulationsdauer, "minutes")

# Save results

# Table 1: Simulation Info
Info <- matrix(rbind("This is simulation no. 2",paste("Number of intended simulation runs:",runs),missruns,paste("Number of bootstrap samples:",B),paste("Number of multiple imputations:",M),finaltime),dimnames=NULL)
colnames(Info) <- "Setup"
rownames(Info) <- NULL
mytable1 <- xtable(Info, caption='Simulation details')
print(mytable1,file=paste(directory,"/Results_sim2.tex",sep=""),table.placement="H",include.rownames=FALSE)

# Table 2: Correlation
missingstat_final <- matrix(round(missingstat_total/runs,digits=4),nrow=1,ncol=8)
rownames(missingstat_final)<-c("missing prob.")
colnames(missingstat_final)<-c("y","p1","p2","p3","p4","p5","p6","total")
mytable2 <- xtable(missingstat_final, caption='missingness percentages for the variables')
print(mytable2,file=paste(directory,"/Results_sim2.tex",sep=""),append=TRUE,table.placement="H")

# Table 3: point estimates
pe <-  matrix(rbind(true,s_est_a,s_est3_a,s_est5_a),ncol=7,nrow=4,dimnames=list(c("True parameters","estimated (M1,M2)","estimated (M3,M4)","estimated (M5)"),c("beta0","beta1","beta2","beta3","beta4","beta5","beta6")))
mytable3 <- xtable(pe, caption='point estimates for the different variables (averaged over simulation runs)')
print(mytable3,file=paste(directory,"/Results_sim2.tex",sep=""),append=TRUE,table.placement="H")

# Table 4: coverage probability
cp1 <- matrix(rbind(s_CI1_a,s_CI2_a,s_CI3_a,s_CI4_a,s_CI5_a,s_CI6_a),ncol=7,nrow=6,dimnames=list(c("Method 1","Method 2","Method 3","Method 4","Method 5","Method 6"),c("beta0","beta1","beta2","beta3","beta4","beta5","beta6")))
mytable4 <- xtable(cp1, caption='estimated coverage probability of true parameter')
print(mytable4,file=paste(directory,"/Results_sim2.tex",sep=""),append=TRUE,table.placement="H")

# Table 5: coverage probability of null
cp2 <- matrix(rbind(s_CI1_b,s_CI2_b,s_CI3_b,s_CI4_b,s_CI5_b,s_CI6_b),ncol=7,nrow=6,dimnames=list(c("Method 1","Method 2","Method 3","Method 4","Method 5","Method 6"),c("beta0","beta1","beta2","beta3","beta4","beta5","beta6")))
mytable5 <- xtable(cp2, caption='estimated coverage probability of zero')
print(mytable5,file=paste(directory,"/Results_sim2.tex",sep=""),append=TRUE,table.placement="H")

# Table 6: correct coverage of true parameter and in/exclusion of zero
cp3 <- matrix(rbind(s_CI1_c,s_CI2_c,s_CI3_c,s_CI4_c,s_CI5_c,s_CI6_a),ncol=7,nrow=6,dimnames=list(c("Method 1","Method 2","Method 3","Method 4","Method 5","Method 6"),c("beta0","beta1","beta2","beta3","beta4","beta5","beta6")))
mytable6 <- xtable(cp3, caption='correct coverage of zero and true parameter')
print(mytable6,file=paste(directory,"/Results_sim2.tex",sep=""),append=TRUE,table.placement="H")

# Table 7: interval width
iw <- matrix(rbind(s_W1,s_W2,s_W3,s_W4,s_W5),ncol=7,nrow=5,dimnames=list(c("Method 1","Method 2","Method 3","Method 4","Method 5"),c("beta0","beta1","beta2","beta3","beta4","beta5","beta6")))
mytable7 <- xtable(iw, caption='Median confidence interval width')
print(mytable7,file=paste(directory,"/Results_sim2.tex",sep=""),append=TRUE,table.placement="H")

# Table 8: standard errors
set <- matrix(rbind(apply(M2_se[,!apply(M2_se,2,is.na)[1,]],1,mean),apply(M5_se[,!apply(M5_se,2,is.na)[1,]],1,mean),apply(M5_est[,!apply(M5_est,2,is.na)[1,]],1,sd),apply(M6_se[,!apply(M6_se,2,is.na)[1,]],1,mean)),ncol=7,nrow=4,dimnames=list(c("Method 2","Method 5 - se/runs","Method 5 - se(est)","Original data"),c("beta0","beta1","beta2","beta3","beta4","beta5","beta6")))
mytable8 <- xtable(set, caption='Average standard errors (Method 5 i) average standard error over simulation runs ii) s.e. estimated from all point estimates of simulation)')
print(mytable8,file=paste(directory,"/Results_sim2.tex",sep=""),append=TRUE,table.placement="H")


results <- list(true,s_est_a,s_est3_a,s_CI1_a,s_CI2_a,s_CI3_a,s_CI4_a,s_CI5_a,s_CI1_b,s_CI2_b,s_CI3_b,s_CI4_b,s_CI5_b,s_CI1_c,s_CI2_c,s_CI3_c,s_CI4_c,s_CI5_c,s_W1,s_W2,s_W3,s_W4,s_W5,M2_se,M5_se,M6_se,M5_est,sPool,sPool4,M3a_est,Summary1_save,Summary1_save2,Summary2_save,Summary2_save2,Summary3_save,M1_CI,M2_CI,M3_CI,M4_CI,M5_CI,M1_width,M2_width,M3_width,M4_width,M5_width,cp1,iw,set)
save(results, file=paste(directory,"/sim2.Rdata",sep=""))
return(results)

} # end main function


###################
# Run simulations #
###################
# Note: Below a subfolder "S2" for simulation 2 is used. Further subfolders are "Setting_a"  and "Setting_b" for low/high missingness settings. 
#       Some of the results produced are not reported in the paper
# Note: Method 1= MI Boot pooled, Method 2 = MI Boot, Method 3= Boot MI, Method 4=Boot MI pooled, Method 5=no bootstrap, Method 6=original data without missing values
#       Table 1 in the paper lists the results in a different order  (method 3 and 4)

sim2.1  <- mysimulation(runs=1000,B=200,M=10,aa=0.075,bb=0.25,directory = paste0(getwd(),'/S2/Setting_a')) # Note: typing error in paper: a=0.075, not 0.75
sim2.2  <- mysimulation(runs=1000,B=200,M=10,aa=0.4,bb=2.5,directory = paste0(getwd(),'/S2/Setting_b'))

################
# LOAD RESULTS #
################

load("S2//Setting_a//sim2.Rdata")
m2a<- results
load("S2//Setting_b//sim2.Rdata")
m2b<- results

###########
# TABLE 1 #
###########

# LOW MISSINGNESS
# Coverage Probabilities
m2a[[46]][,2:7]
# Median CI width
m2a[[47]][,2:7]
# Std Error
m2a[[48]][c(1,2,3),2:7]

# HIGH MISSINGNESS
# Coverage Probabilities
m2b[[46]][,2:7]
# Median CI width
m2b[[47]][,2:7]
# Std Error
m2b[[48]][c(1,2,3),2:7]











