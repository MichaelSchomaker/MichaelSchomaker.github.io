Supplementary Material to Schomaker and Heuman, Bootstrap Inference when Using Multiple Imputation                                              #
Statistics in Medicine; 37:2252-2266  

This folder contains:
- four .r files for the 4 simulations reported in the paper
- one .r file which is being used by the four simulation files (combination of MI estimates)
- one .r file which gives an example on how to practically employ the 4 methods discussed in the paper

Read the top lines of each .r file for instructions on how to use the code.
Basically, simply run the simulations. Create empty folders named S1, S2, S3 and S4 
in your working directory where you have placed the .r files. You may need additional subfolders for simulation 1 and 2.
Note: there may be minor deviations from the numbers reported in the paper due to setting seeds. 
Increase the number of simulation runs (>2000) for even clearer results. 