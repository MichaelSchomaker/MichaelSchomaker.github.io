###################################################################################################################################################
# Supplementary Material to Schomaker and Heuman, Bootstrap Inference when Using Multiple Imputation                                              #
# Statistics in Medicine; 37:2252-2266                                                                                                            #
#                                                                                                                                                 #
# Simulation 3                                                                                                                                    #
#                                                                                                                                                 #
# The results can be obtained by simply pasting this file to R                                                                                    #
# Just 1) change your working directory                                                                                                           #
#      2) paste the mi.inference2.r file in the same folder as this file                                                                          #
#      3) Create subfolders as per instruction at the bottom of this file                                                                         #
# Figures and tables are produced automatically                                                                                                   #
# Settings can be varied by changing the function's options further below in the document or by changing the setup below, e.g. n, beta etc.       #
###################################################################################################################################################


# Set working directory
setwd("//home//mschomaker//Code_Reproduce//Bootstrap")

# Load necessary files
source('mi.inference2.r')   # from library "norm" with tiny change 
library(Amelia)
library(copula)
library(xtable)
library(survival)

set.seed(666)

################
## Simulation ##
################
mysimulation <- function(runs=1000,B=200,M=10,directory = "C:/temp"){

ptm <- proc.time()
param <- 2
missingstat_total <- c(rep(0,param+3))
M_est <- matrix(NA,nrow=param,ncol=runs)
M1_CI <- matrix(NA,nrow=param,ncol=runs)
M1_CI2 <- matrix(NA,nrow=param,ncol=runs)
M1_CI3 <- matrix(NA,nrow=param,ncol=runs)
M2_CI <- matrix(NA,nrow=param,ncol=runs)
M2_CI2 <- matrix(NA,nrow=param,ncol=runs)
M2_CI3 <- matrix(NA,nrow=param,ncol=runs)
M3_est <- matrix(NA,nrow=param,ncol=runs)
M3_CI <- matrix(NA,nrow=param,ncol=runs)
M3_CI2 <- matrix(NA,nrow=param,ncol=runs)
M3_CI3 <- matrix(NA,nrow=param,ncol=runs)
M4_CI <- matrix(NA,nrow=param,ncol=runs)
M4_CI2 <- matrix(NA,nrow=param,ncol=runs)
M4_CI3 <- matrix(NA,nrow=param,ncol=runs)
M5_CI <- matrix(NA,nrow=param,ncol=runs)
M5_CI2 <- matrix(NA,nrow=param,ncol=runs)
M5_CI3 <- matrix(NA,nrow=param,ncol=runs)
M6_CI <- matrix(NA,nrow=param,ncol=runs)
M6_CI2 <- matrix(NA,nrow=param,ncol=runs)
M6_CI3 <- matrix(NA,nrow=param,ncol=runs)
M1_width <- matrix(NA,nrow=param,ncol=runs)
M2_width <- matrix(NA,nrow=param,ncol=runs)
M3_width <- matrix(NA,nrow=param,ncol=runs)
M4_width <- matrix(NA,nrow=param,ncol=runs)
M5_width <- matrix(NA,nrow=param,ncol=runs)
M6_width <- matrix(NA,nrow=param,ncol=runs)
M2_se <- matrix(NA,nrow=param,ncol=runs)
M5_se <- matrix(NA,nrow=param,ncol=runs)
M6_se <- matrix(NA,nrow=param,ncol=runs)
M5_est <- matrix(NA,nrow=param,ncol=runs)
M6_est <- matrix(NA,nrow=param,ncol=runs)
Summary1 <- rep(list(rep(list(matrix(NA,ncol=7,nrow=1,dimnames=NULL) ),B)),M)
Summary2 <- rep(list(rep(list(matrix(NA,ncol=7,nrow=1,dimnames=NULL) ),M)),B)
Summary1_save <- rep(list(NA),runs)
Summary2_save <- rep(list(NA),runs)
Summary3_save <- rep(list(NA),runs)
Summary1_save2 <- rep(list(NA),runs)
Summary2_save2 <- rep(list(NA),runs)


# Simulation loop
for (r in 1:runs)try({
cat("This is simulation run",r,"\n" )
ptm.ib <- proc.time()

ntrain <- 1000        
mycopula <-  mvdc(claytonCopula(1, dim=2),c("lnorm","lnorm"),list(list(meanlog=4.286, sdlog=1.086),list(meanlog=10.760, sdlog=1.808607)))
mycovdata <- rMvdc(ntrain,mycopula)
colnames(mycovdata)<- c("p1","p2")
mycovdata <- as.data.frame(mycovdata)
mycovdata <- as.data.frame(cbind(log(mycovdata$p1),log10(mycovdata$p2))) 
colnames(mycovdata)<- c("p1","p2")
mu    <-  - 0.3*mycovdata$p1 + 0.3*mycovdata$p2
D <- -log(runif(ntrain)) / (0.1 * exp(mu))
C <- -log(runif(ntrain)) / 0.2
y <- apply(cbind(D,C), 1, min)
event <- 1 * (D < C)

true <- c(-0.3,0.3)
mynull <- c(rep(0,2))
mygood <- c(0,0)

probab   <-  1-(1/((0.075*y)^2+1))

p1mis <- mycovdata$p1

for(k in 1:ntrain){p1mis[k] <- sample(c(mycovdata$p1[k],NA),1,prob=c(1-probab[k],probab[k]))}

dataex <- as.data.frame(cbind(y,event,p1mis,mycovdata$p2))
colnames(dataex)<-c("y","event","p1","p2")
original <- as.data.frame(cbind(y,event,mycovdata$p1,mycovdata$p2))
colnames(original)<-c("y","event","p1","p2")

# Check missingness properties  
avmis <- function(myvector){
return(mean(is.na(myvector)))
}
avmistot <- function(myvector){
return(any(is.na(myvector)))
}
missingstat <- apply(dataex,c(2),avmis)
missingstat2 <- mean(apply(dataex,c(1),avmistot))
missingstat <- round(c(missingstat,missingstat2),digits=4)
names(missingstat)<-c("y","event","p1","p2","total")
missingstat_total <- missingstat_total+missingstat


# Imputations 
M=M                             

dataex_imp <- amelia(dataex,p2s=0,m=M,noms=c(2),logs=c(1))
for(m in 1:M){
impname <- (paste("c",m,sep=""))
assign(impname, dataex_imp$imputations[[m]])
}

###########################
## Parameter estimation ###
###########################


###################################
# Loop: Imputation
for(m in 1:M)try({
mydata <- get(paste("c",m,sep=""))

# Loop: Bootstrap
for(b in 1:B)try({
if(b==1){mydata<-get(paste("c",m,sep=""))} # in the first run we take the original data, afterwards bootstrap samples
if(b>1){mydata<-get(paste("c",m,sep=""))[sample(dim(get(paste("c",m,sep="")))[1],replace=TRUE),]}

m1 <- coxph(Surv(y,event)~., data=mydata)

Summary1[[m]][[b]] <- coefficients(m1)


}) # End: loop Bootstrap

}) # End: loop imputation

#############
# Method 1  #
#############


sPool       <- lapply(lapply(Summary1,unlist),matrix,ncol=B)
Summary1.1_CI <- do.call(cbind, lapply(sPool, unlist))
Summary1.1    <-  matrix(Summary1.1_CI[,c(seq(1,(B*M)-(B-1),B))],ncol=M)
Summary1_save[[r]]  <- sPool
Summary1_save2[[r]] <- Summary1.1_CI
upper95<-function(myvector){quantile(myvector, probs=0.975, na.rm=T)}
lower95<-function(myvector){quantile(myvector, probs=0.025, na.rm=T)}

M1data <- as.data.frame(cbind(apply(Summary1.1 ,1,mean),apply(Summary1.1_CI,1,lower95),apply(Summary1.1_CI,1,upper95)))
colnames(M1data) <- c("est","l95","u95")

include_true_M1 <- as.numeric((M1data$l95 <= true) & (M1data$u95>= true))
include_null_M1 <- as.numeric((M1data$l95 <= mynull) & (M1data$u95 >= mynull))
include_good_M1 <- as.numeric((mygood==include_null_M1) & (M1data$l95 <= true) & (M1data$u95>= true))

width_M1 <- M1data$u95-M1data$l95

M_est[,r]       <- M1data$est
M1_CI[,r]       <- include_true_M1
M1_CI2[,r]      <- include_null_M1
M1_CI3[,r]      <- include_good_M1
M1_width[,r]    <- width_M1

#############
# Method 2  #
#############


myse <- function(mymatrix){apply(mymatrix,1,sd)}
Summary1.2.all.est <- rep(list(NULL),M)
for(m in 1:M){Summary1.2.all.est[[m]] <- Summary1.1[,m]}
Summary1.2.all.se <- lapply(sPool,myse)
if(M>1){Summary1.2 <- mi.inference2(Summary1.2.all.est, Summary1.2.all.se, confidence=0.95)}
if(M==1){Summary1.2 <- list(lower=unlist(Summary1.2.all.est)-qt(0.975,df=ntrain-param)*unlist(Summary1.2.all.se),upper=unlist(Summary1.2.all.est)+qt(0.975,df=ntrain-param)*unlist(Summary1.2.all.se),std.err=unlist(Summary1.2.all.se))}

include_true_M2 <- as.numeric((Summary1.2$lower <= true) & (Summary1.2$upper>= true))
include_null_M2 <- as.numeric((Summary1.2$lower <= mynull) & (Summary1.2$upper >= mynull))
include_good_M2 <- as.numeric((mygood==include_null_M2) & (Summary1.2$lower <= true) & (Summary1.2$upper>= true))

width_M2 <- Summary1.2$upper-Summary1.2$lower


M2_CI[,r]  <- include_true_M2
M2_CI2[,r]  <- include_null_M2
M2_CI3[,r]  <- include_good_M2
M2_width[,r]   <- width_M2
M2_se[,r] <- Summary1.2$std.err


#############
# Method 3  #
#############
M3a_est <- matrix(NA,nrow=param,ncol=B)

# Loop: Bootstrap
for(b in 1:B)try({
if(b==1){mydata<-dataex} 
if(b>1){mydata<-dataex[sample(dim(dataex)[1],replace=TRUE),]}

dataex_imp2 <- amelia(mydata,p2s=0,m=M,noms=c(2),logs=c(1))

for(m in 1:M){
impname <- (paste("m2.",m,sep=""))
assign(impname, coxph(Surv(y,event)~., data=as.data.frame(dataex_imp2$imputations[[m]])))
}

m3coef<-eval(parse(text=paste("list(",paste(paste("summary(m2.",seq(1:M),")[[7]][,1]",sep=""),sep=",", collapse=","),")")))
m3se <- eval(parse(text=paste("list(",paste(paste("summary(m2.",seq(1:M),")[[7]][,3]",sep=""),sep=",", collapse=","),")")))
if(M>1){Summary1.3a <- mi.inference2(m3coef, m3se, confidence=0.95)}
if(M==1){Summary1.3a <- list(est=unlist(m3coef),lower=unlist(m3coef)-qt(0.975,df=ntrain-param)*unlist(m3se),upper=unlist(m3coef)+qt(0.975,df=ntrain-param)*unlist(m3se))}
if(b==1){M3_est[,r]<-Summary1.3a$est}
M3a_est[,b] <- Summary1.3a$est
for(m in 1:M){Summary2[[b]][[m]] <- m3coef[[m]]}
}) # End: loop Bootstrap

include_true_M3 <- as.numeric((apply(M3a_est,1,lower95) <= true)   & (apply(M3a_est,1,upper95)>= true))
include_null_M3 <- as.numeric((apply(M3a_est,1,lower95) <= mynull) & (apply(M3a_est,1,upper95)>= mynull))
include_good_M3 <- as.numeric((mygood==include_null_M3) & (apply(M3a_est,1,lower95) <= true)   & (apply(M3a_est,1,upper95)>= true))
width_M3 <- apply(M3a_est,1,upper95)-(apply(M3a_est,1,lower95))

M3_CI[,r]       <- include_true_M3
M3_CI2[,r]      <- include_null_M3
M3_CI3[,r]      <- include_good_M3
M3_width[,r]    <- width_M3
Summary3_save[[r]]  <- M3a_est

#############
# Method 4  #
#############

sPool4       <- lapply(lapply(Summary2,unlist),matrix,ncol=M)
Summary2.1_CI <- do.call(cbind, lapply(sPool4, unlist))
Summary2_save[[r]]  <- sPool4
Summary2_save2[[r]] <- Summary2.1_CI
M4data <- as.data.frame(cbind(apply(Summary2.1_CI,1,lower95),apply(Summary2.1_CI,1,upper95)))
colnames(M4data) <- c("l95","u95")

include_true_M4 <- as.numeric((M4data$l95 <= true) & (M4data$u95>= true))
include_null_M4 <- as.numeric((M4data$l95 <= mynull) & (M4data$u95>= mynull))
include_good_M4 <- as.numeric((mygood==include_null_M4) & (M4data$l95 <= true) & (M4data$u95>= true))
width_M4 <- M4data$u95-M4data$l95

M4_CI[,r]   <- include_true_M4
M4_CI2[,r]  <- include_null_M4
M4_CI3[,r]  <- include_good_M4
M4_width[,r]   <- width_M4

###############################
# Method 5: Without Bootstrap #
###############################
mycoeffs <- eval(parse(text=paste("list(",paste(paste("coef(coxph(Surv(y,event)~.,data=c",seq(1:M),"))",sep=""),sep=",", collapse=","),")")))
mystds <- eval(parse(text=paste("list(",paste(paste("summary(coxph(Surv(y,event)~.,data=c",seq(1:M),"))[[7]][,3]",sep=""),sep=",", collapse=","),")")))
if(M>1){Summary1.5 <- mi.inference2(mycoeffs, mystds, confidence=0.95)}
if(M==1){Summary1.5 <- list(est=unlist(mycoeffs),std.err=unlist(mystds),lower=unlist(mycoeffs)-qt(0.975,df=ntrain-param)*unlist(mystds),upper=unlist(mycoeffs)+qt(0.975,df=ntrain-param)*unlist(mystds))}

include_true_M5 <- as.numeric((Summary1.5$lower <= true) & (Summary1.5$upper>= true))
include_null_M5 <- as.numeric((Summary1.5$lower <= mynull) & (Summary1.5$upper>= mynull))
include_good_M5 <- as.numeric((mygood==include_null_M5) & (Summary1.5$lower <= true) & (Summary1.5$upper>= true))
width_M5 <- Summary1.5$upper-Summary1.5$lower

M5_CI[,r]   <- include_true_M5
M5_CI2[,r]  <- include_null_M5
M5_CI3[,r]  <- include_good_M5
M5_width[,r]   <- width_M5
M5_se[,r] <- Summary1.5$std.err
M5_est[,r] <- Summary1.5$est

################################################
# Method 6: original data without missing data #
################################################

m6      <- coxph(Surv(y,event)~.,data=original)

Summary1.6      <- list(est=coef(m6),lower=coef(m6)-qt(0.975,df=ntrain-param)*summary(m6)[[7]][,3],upper=coef(m6)+qt(0.975,df=ntrain-param)*summary(m6)[[7]][,3])
include_true_M6 <- as.numeric((Summary1.6$lower <= true) & (Summary1.6$upper>= true))
include_null_M6 <- as.numeric((Summary1.6$lower <= mynull) & (Summary1.6$upper>= mynull))
include_good_M6 <- as.numeric((mygood==include_null_M6) & (Summary1.6$lower <= true) & (Summary1.6$upper>= true))
width_M6 <- Summary1.6$upper-Summary1.6$lower

M6_CI[,r]        <- include_true_M6
M6_CI2[,r]       <- include_null_M6
M6_CI3[,r]       <- include_good_M6
M6_width[,r]     <- width_M6
M6_se[,r]        <- summary(m6)[[7]][,3]
M6_est[,r]       <- coef(m6)

###############################################
ptm.ib2 <- proc.time()
ibt <- round(((ptm.ib2-ptm.ib)/60)[1],digits=2)
if(r==1){cat(paste("The simulation will run for about another", runs*ibt-ibt, "minutes \n"))}

}) # End: loop simulation runs


###################
# Produce results #
###################

s_est_a   <- apply(M_est[,!apply(M_est,2,is.na)[1,]],1,mean)
s_est3_a <-  apply(M3_est[,!apply(M3_est,2,is.na)[1,]],1,mean)
s_est5_a <-  apply(M5_est[,!apply(M5_est,2,is.na)[1,]],1,mean)

s_CI1_a <- apply(M1_CI[,!apply(M1_CI,2,is.na)[1,]],1,mean)
s_CI2_a <- apply(M2_CI[,!apply(M2_CI,2,is.na)[1,]],1,mean)
s_CI3_a <- apply(M3_CI[,!apply(M3_CI,2,is.na)[1,]],1,mean)
s_CI4_a <- apply(M4_CI[,!apply(M4_CI,2,is.na)[1,]],1,mean)
s_CI5_a <- apply(M5_CI[,!apply(M5_CI,2,is.na)[1,]],1,mean)
s_CI6_a <- apply(M6_CI[,!apply(M6_CI,2,is.na)[1,]],1,mean)

s_CI1_b <- apply(M1_CI2[,!apply(M1_CI2,2,is.na)[1,]],1,mean)
s_CI2_b <- apply(M2_CI2[,!apply(M2_CI2,2,is.na)[1,]],1,mean)
s_CI3_b <- apply(M3_CI2[,!apply(M3_CI2,2,is.na)[1,]],1,mean)
s_CI4_b <- apply(M4_CI2[,!apply(M4_CI2,2,is.na)[1,]],1,mean)
s_CI5_b <- apply(M5_CI2[,!apply(M5_CI2,2,is.na)[1,]],1,mean)
s_CI6_b <- apply(M6_CI2[,!apply(M6_CI2,2,is.na)[1,]],1,mean)

s_CI1_c <- apply(M1_CI3[,!apply(M1_CI3,2,is.na)[1,]],1,mean)
s_CI2_c <- apply(M2_CI3[,!apply(M2_CI3,2,is.na)[1,]],1,mean)
s_CI3_c <- apply(M3_CI3[,!apply(M3_CI3,2,is.na)[1,]],1,mean)
s_CI4_c <- apply(M4_CI3[,!apply(M4_CI3,2,is.na)[1,]],1,mean)
s_CI5_c <- apply(M5_CI3[,!apply(M5_CI3,2,is.na)[1,]],1,mean)
s_CI6_c <- apply(M6_CI3[,!apply(M6_CI3,2,is.na)[1,]],1,mean)

s_W1 <- apply(M1_width[,!apply(M1_width,2,is.na)[1,]],1,median)
s_W2 <- apply(M2_width[,!apply(M2_width,2,is.na)[1,]],1,median)
s_W3 <- apply(M3_width[,!apply(M3_width,2,is.na)[1,]],1,median)
s_W4 <- apply(M4_width[,!apply(M4_width,2,is.na)[1,]],1,median)
s_W5 <- apply(M5_width[,!apply(M5_width,2,is.na)[1,]],1,median)
s_W6 <- apply(M6_width[,!apply(M6_width,2,is.na)[1,]],1,median)

mruns <- sum(apply(M1_CI,2,is.na)[1,])
mruns2 <- sum(apply(M2_CI,2,is.na)[1,])
mruns3 <- sum(apply(M3_CI,2,is.na)[1,])
mruns4 <- sum(apply(M4_CI,2,is.na)[1,])
mruns5 <- sum(apply(M5_CI,2,is.na)[1,])
mruns6 <- sum(apply(M6_CI,2,is.na)[1,])
cat(paste("Number of failed runs for the 6 methods:",mruns,mruns2,mruns3,mruns4,mruns5,mruns6),"\n")
missruns <- paste("Number of failed runs for the 6 methods:",mruns,mruns2,mruns3,mruns4,mruns5,mruns6)


# Summarize the distribution
pdf(file=paste0(getwd(),'/S3/Fig1a.pdf'))       
mymax = max(density(M5_est[1,],na.rm=T)$y)+0.1
plot(density(Summary1.1_CI[1,],na.rm=T),main="",sub="",xlab="",lwd=3,lty=3,ylim=c(0,mymax),col="darkgrey")
lines(density(Summary2.1_CI[1,],na.rm=T),main="",sub="",xlab="",lwd=3,lty=2,col="red")
lines(density(M5_est[1,],na.rm=T),main="",sub="",xlab="",lwd=3,lty=1,col="black")
lines(density(M3a_est[1,],na.rm=T),main="",sub="",xlab="",lwd=3,lty=4,col="blue")
axis(side = 1 , at = true[1], labels = F , tick = T , tcl = 1 , lwd.ticks = 3 , col.ticks = "blue")
legend("topright",lty=c(3,4,2,1),legend=c("Method 1","Method 3","Method 4","Method 5"), lwd=3, cex=1.25, col=c("darkgrey","blue","red","black"))
dev.off()

pdf(file=paste0(getwd(),'/S3/Fig1b.pdf')) 
mymax = max(density(M5_est[2,],na.rm=T)$y)+0.1
plot(density(Summary1.1_CI[2,],na.rm=T),main="",sub="",xlab="",lwd=3,lty=3,ylim=c(0,mymax),col="darkgrey")
lines(density(Summary2.1_CI[2,],na.rm=T),main="",sub="",xlab="",lwd=3,lty=2,col="red")
lines(density(M5_est[2,],na.rm=T),main="",sub="",xlab="",lwd=3,lty=1,col="black")
lines(density(M3a_est[2,],na.rm=T),main="",sub="",xlab="",lwd=3,lty=4,col="blue")
axis(side = 1 , at = true[2], labels = F , tick = T , tcl = 1 , lwd.ticks = 3 , col.ticks = "blue")
legend("topright",lty=c(3,4,2,1),legend=c("Method 1","Method 3","Method 4","Method 5"), lwd=3, cex=1.25, col=c("darkgrey","blue","red","black"))
dev.off()

mydensity <- function(mymatrix){density(mymatrix[1,],na.rm=T)}
mydensity2 <- function(mymatrix){density(mymatrix[2,],na.rm=T)}

pymax <- function(myd){max(myd$y)}
pxmax <- function(myd){max(myd$x)}
pxmin <- function(myd){min(myd$x)}

myymax <- max(unlist(lapply(lapply(sPool,mydensity),pymax)))+0.1
myxmax <- max(unlist(lapply(lapply(sPool,mydensity),pxmax)))+0.05
myxmin <- min(unlist(lapply(lapply(sPool,mydensity),pxmin)))-0.05
pdf(file=paste0(getwd(),'/S3/Fig2a.pdf')) 
plot(NULL,ylim=c(0,myymax),xlim=c(myxmin,myxmax),xlab="",ylab="Density")
for(i in 1:M){lines(density(sPool[[i]][1,],na.rm=T),col=i,lwd=2)}
axis(side = 1 , at = true[1], labels = F , tick = T , tcl = 1 , lwd.ticks = 3 , col.ticks = "blue")
lines(c(-5,5),c(0,0),type="l",col="lightgrey")
dev.off()

if(M>1){
myymax <- max(unlist(lapply(lapply(sPool4,mydensity),pymax)))+0.1
pdf(file=paste0(getwd(),'/S3/Fig4a.pdf')) 
plot(NULL,ylim=c(0,myymax),xlim=c(myxmin,myxmax),xlab="",ylab="Density")
for(i in 1:B){lines(density(sPool4[[i]][2,],na.rm=T),col=1,lwd=0.35)}
axis(side = 1 , at = true[2], labels = F , tick = T , tcl = 1 , lwd.ticks = 3 , col.ticks = "blue")
lines(c(-5,5),c(0,0),type="l",col="lightgrey")
dev.off()


myxmax <- max(unlist(lapply(lapply(sPool4,mydensity),pxmax)))+0.05
myxmin <- min(unlist(lapply(lapply(sPool4,mydensity),pxmin)))-0.05
pdf(file=paste0(getwd(),'/S3/Fig3a.pdf')) 
plot(NULL,ylim=c(0,myymax),xlim=c(myxmin,myxmax),xlab="",ylab="Density")
for(i in 1:B){lines(density(sPool4[[i]][2,],na.rm=T),col=1,lwd=0.35)}
axis(side = 1 , at = true[2], labels = F , tick = T , tcl = 1 , lwd.ticks = 3 , col.ticks = "blue")
lines(c(-5,5),c(0,0),type="l",col="lightgrey")
dev.off()
}


myymax <- max(unlist(lapply(lapply(sPool,mydensity2),pymax)))+0.1
myxmax <- max(unlist(lapply(lapply(sPool,mydensity2),pxmax)))+0.05
myxmin <- min(unlist(lapply(lapply(sPool,mydensity2),pxmin)))-0.05
pdf(file=paste0(getwd(),'/S3/Fig2b.pdf')) 
plot(NULL,ylim=c(0,myymax),xlim=c(myxmin,myxmax),xlab="",ylab="Density")
for(i in 1:M){lines(density(sPool[[i]][2,],na.rm=T),col=i,lwd=2)}
axis(side = 1 , at = true[2], labels = F , tick = T , tcl = 1 , lwd.ticks = 3 , col.ticks = "blue")
lines(c(-5,5),c(0,0),type="l",col="lightgrey")
dev.off()

if(M>1){
myymax <- max(unlist(lapply(lapply(sPool4,mydensity2),pymax)))+0.1
pdf(file=paste0(getwd(),'/S3/Fig4b.pdf')) 
plot(NULL,ylim=c(0,myymax),xlim=c(myxmin,myxmax),xlab="",ylab="Density")
for(i in 1:B){lines(density(sPool4[[i]][2,],na.rm=T),col=1,lwd=0.35)}
axis(side = 1 , at = true[2], labels = F , tick = T , tcl = 1 , lwd.ticks = 3 , col.ticks = "blue")
lines(c(-5,5),c(0,0),type="l",col="lightgrey")
dev.off()

myxmax <- max(unlist(lapply(lapply(sPool4,mydensity2),pxmax)))+0.05
myxmin <- min(unlist(lapply(lapply(sPool4,mydensity2),pxmin)))-0.05
pdf(file=paste0(getwd(),'/S3/Fig3b.pdf')) 
plot(NULL,ylim=c(0,myymax),xlim=c(myxmin,myxmax),xlab="",ylab="Density")
for(i in 1:B){lines(density(sPool4[[i]][2,],na.rm=T),col=1,lwd=0.35)}
axis(side = 1 , at = true[2], labels = F , tick = T , tcl = 1 , lwd.ticks = 3 , col.ticks = "blue")
lines(c(-5,5),c(0,0),type="l",col="lightgrey")
dev.off()
}

# How long did it take?
ptm2 <-  proc.time()
simulationsdauer <- ptm2-ptm
simulationsdauer <- (simulationsdauer/60)
simulationsdauer <- round(simulationsdauer[1], digits=2)
cat(paste("The simulation time was", simulationsdauer, "minutes \n"))
finaltime <-  paste("The simulation time was", simulationsdauer, "minutes")

# Save results

# Table 1: Simulation Info
Info <- matrix(rbind("This is simulation no. 3",paste("Number of intended simulation runs:",runs),missruns,paste("Number of bootstrap samples:",B),paste("Number of multiple imputations:",M),finaltime),dimnames=NULL)
colnames(Info) <- "Setup"
rownames(Info) <- NULL
mytable1 <- xtable(Info, caption='Simulation details')
print(mytable1,file=paste(directory,"/S3/Results_sim3.tex",sep=""),table.placement="H",include.rownames=FALSE)

# Table 2: Correlation
missingstat_final <- matrix(round(missingstat_total/runs,digits=4),nrow=1,ncol=5)
rownames(missingstat_final)<-c("missing prob.")
colnames(missingstat_final)<-c("y","event","p1","p2","total")
mytable2 <- xtable(missingstat_final, caption='missingness percentages for the variables')
print(mytable2,file=paste(directory,"/S3/Results_sim3.tex",sep=""),append=TRUE,table.placement="H")

# Table 3: point estimates
pe <-  matrix(rbind(true,s_est_a,s_est3_a,s_est5_a),ncol=2,nrow=4,dimnames=list(c("True parameters","estimated (M1,M2)","estimated (M3,M4)","estimated (M5)"),c("beta1","beta2")))
mytable3 <- xtable(pe, caption='point estimates for the different variables (averaged over simulation runs)')
print(mytable3,file=paste(directory,"/S3/Results_sim3.tex",sep=""),append=TRUE,table.placement="H")

# Table 4: coverage probability
cp1 <- matrix(rbind(s_CI1_a,s_CI2_a,s_CI3_a,s_CI4_a,s_CI5_a,s_CI6_a),ncol=2,nrow=6,dimnames=list(c("Method 1","Method 2","Method 3","Method 4","Method 5","Method 6"),c("beta1","beta2")))
mytable4 <- xtable(cp1, caption='estimated coverage probability of true parameter')
print(mytable4,file=paste(directory,"/S3/Results_sim3.tex",sep=""),append=TRUE,table.placement="H")

# Table 5: coverage probability of null
cp2 <- matrix(rbind(s_CI1_b,s_CI2_b,s_CI3_b,s_CI4_b,s_CI5_b,s_CI6_b),ncol=2,nrow=6,dimnames=list(c("Method 1","Method 2","Method 3","Method 4","Method 5","Method 6"),c("beta1","beta2")))
mytable5 <- xtable(cp2, caption='estimated coverage probability of zero')
print(mytable5,file=paste(directory,"/S3/Results_sim3.tex",sep=""),append=TRUE,table.placement="H")

# Table 6: correct coverage of true parameter and in/exclusion of zero
cp3 <- matrix(rbind(s_CI1_c,s_CI2_c,s_CI3_c,s_CI4_c,s_CI5_c,s_CI6_a),ncol=2,nrow=6,dimnames=list(c("Method 1","Method 2","Method 3","Method 4","Method 5","Method 6"),c("beta1","beta2")))
mytable6 <- xtable(cp3, caption='correct coverage of zero and true parameter')
print(mytable6,file=paste(directory,"/S3/Results_sim3.tex",sep=""),append=TRUE,table.placement="H")

# Table 7: interval width
iw <- matrix(rbind(s_W1,s_W2,s_W3,s_W4,s_W5),ncol=2,nrow=5,dimnames=list(c("Method 1","Method 2","Method 3","Method 4","Method 5"),c("beta1","beta2")))
mytable7 <- xtable(iw, caption='Median confidence interval width')
print(mytable7,file=paste(directory,"/S3/Results_sim3.tex",sep=""),append=TRUE,table.placement="H")

# Table 8: standard errors
set <- matrix(rbind(apply(M2_se[,!apply(M2_se,2,is.na)[1,]],1,mean),apply(M5_se[,!apply(M5_se,2,is.na)[1,]],1,mean),apply(M5_est[,!apply(M5_est,2,is.na)[1,]],1,sd),apply(M6_se[,!apply(M6_se,2,is.na)[1,]],1,mean)),ncol=2,nrow=4,dimnames=list(c("Method 2","Method 5 - se/runs","Method 5 - se(est)","Original data"),c("beta1","beta2")))
mytable8 <- xtable(set, caption='Average standard errors (Method 5 i) average standard error over simulation runs ii) s.e. estimated from all point estimates of simulation)')
print(mytable8,file=paste(directory,"/S3/Results_sim3.tex",sep=""),append=TRUE,table.placement="H")

results <- list(true,s_est_a,s_est3_a,s_CI1_a,s_CI2_a,s_CI3_a,s_CI4_a,s_CI5_a,s_CI1_b,s_CI2_b,s_CI3_b,s_CI4_b,s_CI5_b,s_CI1_c,s_CI2_c,s_CI3_c,s_CI4_c,s_CI5_c,s_W1,s_W2,s_W3,s_W4,s_W5,M2_se,M5_se,M6_se,M5_est,sPool,sPool4,M3a_est,Summary1_save,Summary1_save2,Summary2_save,Summary2_save2,Summary3_save,M1_CI,M2_CI,M3_CI,M4_CI,M5_CI,M1_width,M2_width,M3_width,M4_width,M5_width,cp1,iw,set)
save(results, file=paste(directory,"/S3/sim3.Rdata",sep=""))
return(results)

} # end main function


##################
# Run simulation #
##################
# Note: A subfolder "S3" for simulation 3 is used. Please generate it in your working directory.
#       Some of the results produced are not reported in the paper
# Note: Method 1= MI Boot pooled, Method 2 = MI Boot, Method 3= Boot MI, Method 4=Boot MI pooled, Method 5=no bootstrap, Method 6=original data without missing values
#       Table 1 in the paper lists the results in a different order  (method 3 and 4)


sim3  <- mysimulation(runs=1000,B=200,M=10, directory = getwd())

################
# LOAD RESULTS #
################

load("S3//sim3.Rdata")
m3<- results

###########
# TABLE 1 #
###########

# Coverage Probabilities
m3[[46]]
# Median CI width
m3[[47]]
# Std Error
m3[[48]][c(1,2,3),]






