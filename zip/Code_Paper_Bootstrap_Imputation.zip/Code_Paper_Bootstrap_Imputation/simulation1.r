###################################################################################################################################################
# Supplementary Material to Schomaker and Heuman, Bootstrap Inference when Using Multiple Imputation                                              #
# Statistics in Medicine; 37:2252-2266                                                                                                            #
#                                                                                                                                                 #
# Simulation 1                                                                                                                                    #
#                                                                                                                                                 #
# The results can be obtained by simply pasting this file to R                                                                                    #
# Just 1) change your working directory                                                                                                           #
#      2) paste the mi.inference2.r file in the same folder as this file                                                                          #
#      3) Create subfolders as per instruction at the bottom of this file                                                                         #
# Figures and tables are produced automatically                                                                                                   #
# Settings can be varied by changing the function's options further below in the document or by changing the setup below, e.g. n, beta etc.       #
###################################################################################################################################################


# Set working directory
setwd("//home//mschomaker//Code_Reproduce//Bootstrap")

# Load necessary files
source('mi.inference2.r')# from library "norm" with tiny change 
library(Amelia)
library(copula)
library(xtable)
library(ggplot2)

set.seed(666)

################
## Simulation ##
################
mysimulation <- function(runs=1000,B=200,M=10,directory = "C:/temp"){

ptm <- proc.time()
param <- 2
missingstat_total <- c(rep(0,3))
M_est <- matrix(NA,nrow=param,ncol=runs)
M1_CI <- matrix(NA,nrow=param,ncol=runs)
M1_CI2 <- matrix(NA,nrow=param,ncol=runs)
M1_CI3 <- matrix(NA,nrow=param,ncol=runs)
M2_CI <- matrix(NA,nrow=param,ncol=runs)
M2_CI2 <- matrix(NA,nrow=param,ncol=runs)
M2_CI3 <- matrix(NA,nrow=param,ncol=runs)
M3_est <- matrix(NA,nrow=param,ncol=runs)
M3_CI <- matrix(NA,nrow=param,ncol=runs)
M3_CI2 <- matrix(NA,nrow=param,ncol=runs)
M3_CI3 <- matrix(NA,nrow=param,ncol=runs)
M4_CI <- matrix(NA,nrow=param,ncol=runs)
M4_CI2 <- matrix(NA,nrow=param,ncol=runs)
M4_CI3 <- matrix(NA,nrow=param,ncol=runs)
M5_CI <- matrix(NA,nrow=param,ncol=runs)
M5_CI2 <- matrix(NA,nrow=param,ncol=runs)
M5_CI3 <- matrix(NA,nrow=param,ncol=runs)
M6_est <- matrix(NA,nrow=param,ncol=runs)
M6_CI <- matrix(NA,nrow=param,ncol=runs)
M6_CI2 <- matrix(NA,nrow=param,ncol=runs)
M6_CI3 <- matrix(NA,nrow=param,ncol=runs)
M1_width <- matrix(NA,nrow=param,ncol=runs)
M2_width <- matrix(NA,nrow=param,ncol=runs)
M3_width <- matrix(NA,nrow=param,ncol=runs)
M4_width <- matrix(NA,nrow=param,ncol=runs)
M5_width <- matrix(NA,nrow=param,ncol=runs)
M6_width <- matrix(NA,nrow=param,ncol=runs)
M2_se <- matrix(NA,nrow=param,ncol=runs)
M5_se <- matrix(NA,nrow=param,ncol=runs)
M6_se <- matrix(NA,nrow=param,ncol=runs)
M5_est <- matrix(NA,nrow=param,ncol=runs)
Summary1 <- rep(list(rep(list(matrix(NA,ncol=7,nrow=1,dimnames=NULL) ),B)),M)
Summary2 <- rep(list(rep(list(matrix(NA,ncol=7,nrow=1,dimnames=NULL) ),M)),B)
Summary1_save <- rep(list(NA),runs)
Summary2_save <- rep(list(NA),runs)
Summary3_save <- rep(list(NA),runs)
Summary1_save2 <- rep(list(NA),runs)
Summary2_save2 <- rep(list(NA),runs)


# Simulation loop
for (r in 1:runs)try({
cat("This is simulation run",r,"\n" )
ptm.ib <- proc.time()

ntrain <- 1000        
p1 <- rnorm(ntrain, 0, 1)          
mu      <- 0 + 0.4*p1
mysigma <- 2
y <- rnorm(ntrain, mu, mysigma)

true <- c(0,0.4)
mynull <- c(rep(0,param))
mygood <- c(1,0)

# Declare values of X1 to be missing
probab   <-  1-(1/((0.25*y)^2+1))
p1mis <- p1
for(k in 1:ntrain){p1mis[k] <- sample(c(p1[k],NA),1,prob=c(1-probab[k],probab[k]))}

# Data 
dataex          <- as.data.frame(cbind(y,p1mis))
colnames(dataex)[2] <- "p1"
original        <- as.data.frame(cbind(y,p1))

# Check missingness properties  
avmis <- function(myvector){
return(mean(is.na(myvector)))
}
avmistot <- function(myvector){
return(any(is.na(myvector)))
}
missingstat <- apply(dataex,c(2),avmis)
missingstat2 <- mean(apply(dataex,c(1),avmistot))
missingstat <- round(c(missingstat,missingstat2),digits=4)
names(missingstat)<-c("y","p1","total")
missingstat_total <- missingstat_total+missingstat


# Imputations 
M=M

dataex_imp <- amelia(dataex,p2s=0,m=M)
for(m in 1:M){
impname <- (paste("c",m,sep=""))
assign(impname, dataex_imp$imputations[[m]])
}

###########################
## Parameter estimation ###
###########################


###################################
# Loop: Imputation
for(m in 1:M)try({
mydata <- get(paste("c",m,sep=""))

# Loop: Bootstrap
for(b in 1:B)try({
if(b==1){mydata<-get(paste("c",m,sep=""))} # in the first run we take the original data, afterwards bootstrap samples
if(b>1){mydata<-get(paste("c",m,sep=""))[sample(dim(get(paste("c",m,sep="")))[1],replace=TRUE),]}

m1 <- lm(y~., data=mydata)

Summary1[[m]][[b]] <- coefficients(m1)


}) # End: loop Bootstrap

}) # End: loop imputation

############
# Method 1 #
############

sPool               <- lapply(lapply(Summary1,unlist),matrix,ncol=B)
Summary1.1_CI       <- do.call(cbind, lapply(sPool, unlist))
Summary1_save[[r]]  <- sPool
Summary1_save2[[r]] <- Summary1.1_CI
Summary1.1    <-  matrix(Summary1.1_CI[,c(seq(1,(B*M)-(B-1),B))],ncol=M)
upper95<-function(myvector){quantile(myvector, probs=0.975)}
lower95<-function(myvector){quantile(myvector, probs=0.025)}

M1data <- as.data.frame(cbind(apply(Summary1.1 ,1,mean),apply(Summary1.1_CI,1,lower95),apply(Summary1.1_CI,1,upper95)))
colnames(M1data) <- c("est","l95","u95")

include_true_M1 <- as.numeric((M1data$l95 <= true) & (M1data$u95>= true))
include_null_M1 <- as.numeric((M1data$l95 <= mynull) & (M1data$u95 >= mynull))
include_good_M1 <- as.numeric((mygood==include_null_M1) & (M1data$l95 <= true) & (M1data$u95>= true))

width_M1 <- M1data$u95-M1data$l95

M_est[,r]       <- M1data$est
M1_CI[,r]       <- include_true_M1
M1_CI2[,r]      <- include_null_M1
M1_CI3[,r]      <- include_good_M1
M1_width[,r]    <- width_M1

############
# Method 2 #
############

myse <- function(mymatrix){apply(mymatrix,1,sd)}
Summary1.2.all.est <- rep(list(NULL),M)
for(m in 1:M){Summary1.2.all.est[[m]] <- Summary1.1[,m]}
Summary1.2.all.se <- lapply(sPool,myse)
if(M>1){Summary1.2 <- mi.inference2(Summary1.2.all.est, Summary1.2.all.se, confidence=0.95)}
if(M==1){Summary1.2 <- list(lower=unlist(Summary1.2.all.est)-qt(0.975,df=ntrain-param)*unlist(Summary1.2.all.se),upper=unlist(Summary1.2.all.est)+qt(0.975,df=ntrain-param)*unlist(Summary1.2.all.se),std.err=unlist(Summary1.2.all.se))}

include_true_M2 <- as.numeric((Summary1.2$lower <= true) & (Summary1.2$upper>= true))
include_null_M2 <- as.numeric((Summary1.2$lower <= mynull) & (Summary1.2$upper >= mynull))
include_good_M2 <- as.numeric((mygood==include_null_M2) & (Summary1.2$lower <= true) & (Summary1.2$upper>= true))

width_M2 <- Summary1.2$upper-Summary1.2$lower


M2_CI[,r]  <- include_true_M2
M2_CI2[,r]  <- include_null_M2
M2_CI3[,r]  <- include_good_M2
M2_width[,r]   <- width_M2
M2_se[,r] <- Summary1.2$std.err


############
# Method 3 #
############

M3a_est <- matrix(NA,nrow=param,ncol=B)

# Loop: Bootstrap
for(b in 1:B)try({
if(b==1){mydata<-dataex} 
if(b>1){mydata<-dataex[sample(dim(dataex)[1],replace=TRUE),]}

dataex_imp2 <- amelia(mydata,p2s=0,m=M)#,bounds=matrix(c(5,6,0,0,12,12),ncol=3,nrow=2))

for(m in 1:M){
impname <- (paste("m2.",m,sep=""))
assign(impname, lm(y~., data=as.data.frame(dataex_imp2$imputations[[m]])))
}


m3coef<-eval(parse(text=paste("list(",paste(paste("summary(m2.",seq(1:M),")[[4]][,1]",sep=""),sep=",", collapse=","),")")))
m3se <- eval(parse(text=paste("list(",paste(paste("summary(m2.",seq(1:M),")[[4]][,2]",sep=""),sep=",", collapse=","),")")))
if(M>1){Summary1.3a <- mi.inference2(m3coef, m3se, confidence=0.95)}
if(M==1){Summary1.3a <- list(est=unlist(m3coef),lower=unlist(m3coef)-qt(0.975,df=ntrain-param)*unlist(m3se),upper=unlist(m3coef)+qt(0.975,df=ntrain-param)*unlist(m3se))}
if(b==1){M3_est[,r]<-Summary1.3a$est}
M3a_est[,b] <- Summary1.3a$est
for(m in 1:M){Summary2[[b]][[m]] <- m3coef[[m]]}
}) # End: loop Bootstrap

include_true_M3 <- as.numeric((apply(M3a_est,1,lower95) <= true)   & (apply(M3a_est,1,upper95)>= true))
include_null_M3 <- as.numeric((apply(M3a_est,1,lower95) <= mynull) & (apply(M3a_est,1,upper95)>= mynull))
include_good_M3 <- as.numeric((mygood==include_null_M3) & (apply(M3a_est,1,lower95) <= true)   & (apply(M3a_est,1,upper95)>= true))
width_M3 <- apply(M3a_est,1,upper95)-(apply(M3a_est,1,lower95))

M3_CI[,r]       <- include_true_M3
M3_CI2[,r]      <- include_null_M3
M3_CI3[,r]      <- include_good_M3
M3_width[,r]    <- width_M3
Summary3_save[[r]]  <- M3a_est

############
# Method 4 #
############

sPool4       <- lapply(lapply(Summary2,unlist),matrix,ncol=M)
Summary2.1_CI <- do.call(cbind, lapply(sPool4, unlist))
Summary2_save[[r]]  <- sPool4
Summary2_save2[[r]] <- Summary2.1_CI
M4data <- as.data.frame(cbind(apply(Summary2.1_CI,1,lower95),apply(Summary2.1_CI,1,upper95)))
colnames(M4data) <- c("l95","u95")

include_true_M4 <- as.numeric((M4data$l95 <= true) & (M4data$u95>= true))
include_null_M4 <- as.numeric((M4data$l95 <= mynull) & (M4data$u95>= mynull))
include_good_M4 <- as.numeric((mygood==include_null_M4) & (M4data$l95 <= true) & (M4data$u95>= true))
width_M4 <- M4data$u95-M4data$l95

M4_CI[,r]   <- include_true_M4
M4_CI2[,r]  <- include_null_M4
M4_CI3[,r]  <- include_good_M4
M4_width[,r]   <- width_M4

###############################
# Method 5: Without Bootstrap #
###############################

mycoeffs <- eval(parse(text=paste("list(",paste(paste("coef(lm(y~.,data=c",seq(1:M),"))",sep=""),sep=",", collapse=","),")")))
mystds <- eval(parse(text=paste("list(",paste(paste("summary(lm(y~.,data=c",seq(1:M),"))[[4]][,2]",sep=""),sep=",", collapse=","),")")))
if(M>1){Summary1.5 <- mi.inference2(mycoeffs, mystds, confidence=0.95)}
if(M==1){Summary1.5 <- list(est=unlist(mycoeffs),std.err=unlist(mystds),lower=unlist(mycoeffs)-qt(0.975,df=ntrain-param)*unlist(mystds),upper=unlist(mycoeffs)+qt(0.975,df=ntrain-param)*unlist(mystds))}

include_true_M5 <- as.numeric((Summary1.5$lower <= true) & (Summary1.5$upper>= true))
include_null_M5 <- as.numeric((Summary1.5$lower <= mynull) & (Summary1.5$upper>= mynull))
include_good_M5 <- as.numeric((mygood==include_null_M5) & (Summary1.5$lower <= true) & (Summary1.5$upper>= true))
width_M5 <- Summary1.5$upper-Summary1.5$lower

M5_CI[,r]   <- include_true_M5
M5_CI2[,r]  <- include_null_M5
M5_CI3[,r]  <- include_good_M5
M5_width[,r]   <- width_M5
M5_se[,r] <- Summary1.5$std.err
M5_est[,r] <- Summary1.5$est

################################################
# Method 6: original data without missing data #
################################################
m6      <- lm(y~.,data=original)

Summary1.6      <- list(est=coef(m6),lower=coef(m6)-qt(0.975,df=ntrain-param)*summary(m6)[[4]][,2],upper=coef(m6)+qt(0.975,df=ntrain-param)*summary(m6)[[4]][,2])
include_true_M6 <- as.numeric((Summary1.6$lower <= true) & (Summary1.6$upper>= true))
include_null_M6 <- as.numeric((Summary1.6$lower <= mynull) & (Summary1.6$upper>= mynull))
include_good_M6 <- as.numeric((mygood==include_null_M6) & (Summary1.6$lower <= true) & (Summary1.6$upper>= true))
width_M6 <- Summary1.6$upper-Summary1.6$lower

M6_CI[,r]        <- include_true_M6
M6_CI2[,r]       <- include_null_M6
M6_CI3[,r]       <- include_good_M6
M6_width[,r]     <- width_M6
M6_se[,r]        <- summary(m6)[[4]][,2]
M6_est[,r]       <- coef(m6)

###############################################
ptm.ib2 <- proc.time()
ibt <- round(((ptm.ib2-ptm.ib)/60)[1],digits=2)
if(r==1){cat(paste("The simulation will run for about another", runs*ibt-ibt, "minutes \n"))}

}) # End: loop simulation runs


###################
# Produce results #
###################

s_est_a   <- apply(M_est[,!apply(M_est,2,is.na)[1,]],1,mean)
s_est3_a <-  apply(M3_est[,!apply(M3_est,2,is.na)[1,]],1,mean)
s_est5_a <-  apply(M5_est[,!apply(M5_est,2,is.na)[1,]],1,mean)

s_CI1_a <- apply(M1_CI[,!apply(M1_CI,2,is.na)[1,]],1,mean)
s_CI2_a <- apply(M2_CI[,!apply(M2_CI,2,is.na)[1,]],1,mean)
s_CI3_a <- apply(M3_CI[,!apply(M3_CI,2,is.na)[1,]],1,mean)
s_CI4_a <- apply(M4_CI[,!apply(M4_CI,2,is.na)[1,]],1,mean)
s_CI5_a <- apply(M5_CI[,!apply(M5_CI,2,is.na)[1,]],1,mean)
s_CI6_a <- apply(M6_CI[,!apply(M6_CI,2,is.na)[1,]],1,mean)

s_CI1_b <- apply(M1_CI2[,!apply(M1_CI2,2,is.na)[1,]],1,mean)
s_CI2_b <- apply(M2_CI2[,!apply(M2_CI2,2,is.na)[1,]],1,mean)
s_CI3_b <- apply(M3_CI2[,!apply(M3_CI2,2,is.na)[1,]],1,mean)
s_CI4_b <- apply(M4_CI2[,!apply(M4_CI2,2,is.na)[1,]],1,mean)
s_CI5_b <- apply(M5_CI2[,!apply(M5_CI2,2,is.na)[1,]],1,mean)
s_CI6_b <- apply(M6_CI2[,!apply(M6_CI2,2,is.na)[1,]],1,mean)

s_CI1_c <- apply(M1_CI3[,!apply(M1_CI3,2,is.na)[1,]],1,mean)
s_CI2_c <- apply(M2_CI3[,!apply(M2_CI3,2,is.na)[1,]],1,mean)
s_CI3_c <- apply(M3_CI3[,!apply(M3_CI3,2,is.na)[1,]],1,mean)
s_CI4_c <- apply(M4_CI3[,!apply(M4_CI3,2,is.na)[1,]],1,mean)
s_CI5_c <- apply(M5_CI3[,!apply(M5_CI3,2,is.na)[1,]],1,mean)
s_CI6_c <- apply(M6_CI3[,!apply(M6_CI3,2,is.na)[1,]],1,mean)

s_W1 <- apply(M1_width[,!apply(M1_width,2,is.na)[1,]],1,median)
s_W2 <- apply(M2_width[,!apply(M2_width,2,is.na)[1,]],1,median)
s_W3 <- apply(M3_width[,!apply(M3_width,2,is.na)[1,]],1,median)
s_W4 <- apply(M4_width[,!apply(M4_width,2,is.na)[1,]],1,median)
s_W5 <- apply(M5_width[,!apply(M5_width,2,is.na)[1,]],1,median)
s_W6 <- apply(M6_width[,!apply(M6_width,2,is.na)[1,]],1,median)

mruns <- sum(apply(M1_CI,2,is.na)[1,])
mruns2 <- sum(apply(M2_CI,2,is.na)[1,])
mruns3 <- sum(apply(M3_CI,2,is.na)[1,])
mruns4 <- sum(apply(M4_CI,2,is.na)[1,])
mruns5 <- sum(apply(M5_CI,2,is.na)[1,])
mruns6 <- sum(apply(M6_CI,2,is.na)[1,])
cat(paste("Number of failed runs for the 6 methods:",mruns,mruns2,mruns3,mruns4,mruns5,mruns6),"\n")
missruns <- paste("Number of failed runs for the 6 methods:",mruns,mruns2,mruns3,mruns4,mruns5,mruns6)

# Summarize the distribution
pdf(file=paste(directory,"/Fig1.pdf",sep=""))
mymax = max(density(M5_est[2,],na.rm=T)$y)+0.1
plot(density(Summary1.1_CI[2,],na.rm=T),main="",sub="",xlab="",lwd=3,lty=3,ylim=c(0,mymax),col="darkgrey")
lines(density(Summary2.1_CI[2,],na.rm=T),main="",sub="",xlab="",lwd=3,lty=2,col="red")
lines(density(M5_est[2,],na.rm=T),main="",sub="",xlab="",lwd=3,lty=1,col="black")
lines(density(M3a_est[2,],na.rm=T),main="",sub="",xlab="",lwd=3,lty=4,col="blue")
axis(side = 1 , at = true[2], labels = F , tick = T , tcl = 1 , lwd.ticks = 3 , col.ticks = "blue")
legend("topright",lty=c(3,4,2,1),legend=c("Method 1","Method 3","Method 4","Method 5"), lwd=3, cex=1.25, col=c("darkgrey","blue","red","black"))
dev.off()

mydensity <- function(mymatrix){density(mymatrix[2,],na.rm=T)}
pymax <- function(myd){max(myd$y)}
pxmax <- function(myd){max(myd$x)}
pxmin <- function(myd){min(myd$x)}
myymax <- max(unlist(lapply(lapply(sPool,mydensity),pymax)))+0.1
myxmax <- max(unlist(lapply(lapply(sPool,mydensity),pxmax)))+0.05
myxmin <- min(unlist(lapply(lapply(sPool,mydensity),pxmin)))-0.05
greys <- gray.colors(10)
pdf(file=paste(directory,"/Fig2.pdf",sep=""))
plot(NULL,ylim=c(0,myymax),xlim=c(myxmin,myxmax),xlab="",ylab="Density")
for(i in 1:M){lines(density(sPool[[i]][2,],na.rm=T),col=greys[i],lwd=2)}
axis(side = 1 , at = 0.4, labels = F , tick = T , tcl = 1 , lwd.ticks = 3 , col.ticks = "blue")
lines(c(-5,5),c(0,0),type="l",col="lightgrey")
dev.off()

if(M>1){
myymax <- max(unlist(lapply(lapply(sPool4,mydensity),pymax)))+0.1
pdf(file=paste(directory,"/Fig4.pdf",sep=""))
plot(NULL,ylim=c(0,myymax),xlim=c(myxmin,myxmax),xlab="",ylab="Density")
for(i in 1:B){lines(density(sPool4[[i]][2,],na.rm=T),col=1,lwd=0.35)}
axis(side = 1 , at = 0.4, labels = F , tick = T , tcl = 1 , lwd.ticks = 3 , col.ticks = "blue")
lines(c(-5,5),c(0,0),type="l",col="lightgrey")
dev.off()

myxmax <- max(unlist(lapply(lapply(sPool4,mydensity),pxmax)))+0.05
myxmin <- min(unlist(lapply(lapply(sPool4,mydensity),pxmin)))-0.05
pdf(file=paste(directory,"/Fig3.pdf",sep=""))
plot(NULL,ylim=c(0,myymax),xlim=c(myxmin,myxmax),xlab="",ylab="Density")
for(i in 1:B){lines(density(sPool4[[i]][2,],na.rm=T),col=1,lwd=0.35)}
axis(side = 1 , at = 0.4, labels = F , tick = T , tcl = 1 , lwd.ticks = 3 , col.ticks = "blue")
lines(c(-5,5),c(0,0),type="l",col="lightgrey")
dev.off()
}

prf   <-  function(y){1-(1/((0.25*y)^2+1))}
xval  <- c(seq(-7.5,7.5,0.05))
pdf(file=paste(directory,"/Fig6.pdf",sep=""))
plot(xval,prf(xval),type="l",lwd=3,xlab="y",ylab="Pr(Missingness)")  
dev.off()

# How long did it take?
ptm2 <-  proc.time()
simulationsdauer <- ptm2-ptm
simulationsdauer <- (simulationsdauer/60)
simulationsdauer <- round(simulationsdauer[1], digits=2)
cat(paste("The simulation time was", simulationsdauer, "minutes \n"))
finaltime <-  paste("The simulation time was", simulationsdauer, "minutes")

# Save results

# Table 1: Simulation Info
Info <- matrix(rbind("This is simulation no. 1",paste("Number of intended simulation runs:",runs),missruns,paste("Number of bootstrap samples:",B),paste("Number of multiple imputations:",M),finaltime),dimnames=NULL)
colnames(Info) <- "Setup"
rownames(Info) <- NULL
mytable1 <- xtable(Info, caption='Simulation details')
print(mytable1,file=paste(directory,"/Results_sim1.tex",sep=""),table.placement="H",include.rownames=FALSE)

# Table 2: Correlation
missingstat_final <- matrix(round(missingstat_total/runs,digits=4),nrow=1,ncol=3)
rownames(missingstat_final)<-c("missing prob.")
colnames(missingstat_final)<-c("y","p1","total")
mytable2 <- xtable(missingstat_final, caption='missingness percentages for the variables')
print(mytable2,file=paste(directory,"/Results_sim1.tex",sep=""),append=TRUE,table.placement="H")

# Table 3: point estimates
pe <-  matrix(rbind(true,s_est_a,s_est3_a,s_est5_a),ncol=2,nrow=4,dimnames=list(c("True parameters","estimated (M1,M2)","estimated (M3,M4)","estimated (M5)"),c("beta0","beta1")))
mytable3 <- xtable(pe, caption='point estimates for the different variables (averaged over simulation runs)')
print(mytable3,file=paste(directory,"/Results_sim1.tex",sep=""),append=TRUE,table.placement="H")

# Table 4: coverage probability
cp1 <- matrix(rbind(s_CI1_a,s_CI2_a,s_CI3_a,s_CI4_a,s_CI5_a,s_CI6_a),ncol=2,nrow=6,dimnames=list(c("Method 1","Method 2","Method 3","Method 4","Method 5","Method 6"),c("beta0","beta1")))
mytable4 <- xtable(cp1, caption='estimated coverage probability of true parameter')
print(mytable4,file=paste(directory,"/Results_sim1.tex",sep=""),append=TRUE,table.placement="H")

# Table 5: coverage probability of null
cp2 <- matrix(rbind(s_CI1_b,s_CI2_b,s_CI3_b,s_CI4_b,s_CI5_b,s_CI6_b),ncol=2,nrow=6,dimnames=list(c("Method 1","Method 2","Method 3","Method 4","Method 5","Method 6"),c("beta0","beta1")))
mytable5 <- xtable(cp2, caption='estimated coverage probability of zero')
print(mytable5,file=paste(directory,"/Results_sim1.tex",sep=""),append=TRUE,table.placement="H")

# Table 6: correct coverage of true parameter and in/exclusion of zero
cp3 <- matrix(rbind(s_CI1_c,s_CI2_c,s_CI3_c,s_CI4_c,s_CI5_c,s_CI6_c),ncol=2,nrow=6,dimnames=list(c("Method 1","Method 2","Method 3","Method 4","Method 5","Method 6"),c("beta0","beta1")))
mytable6 <- xtable(cp3, caption='correct coverage of zero and true parameter')
print(mytable6,file=paste(directory,"/Results_sim1.tex",sep=""),append=TRUE,table.placement="H")

# Table 7: interval width
iw <- matrix(rbind(s_W1,s_W2,s_W3,s_W4,s_W5,s_W6),ncol=2,nrow=6,dimnames=list(c("Method 1","Method 2","Method 3","Method 4","Method 5","Method 6"),c("beta0","beta1")))
mytable7 <- xtable(iw, caption='Median confidence interval width')
print(mytable7,file=paste(directory,"/Results_sim1.tex",sep=""),append=TRUE,table.placement="H")

# Table 8: standard errors
set <- matrix(rbind(apply(M2_se[,!apply(M2_se,2,is.na)[1,]],1,mean),apply(M5_se[,!apply(M5_se,2,is.na)[1,]],1,mean),apply(M5_est[,!apply(M5_est,2,is.na)[1,]],1,sd),apply(M6_se[,!apply(M6_se,2,is.na)[1,]],1,mean)),ncol=2,nrow=4,dimnames=list(c("Method 2","Method 5 - se/runs","Method 5 - se(est)","Original data"),c("beta0","beta1")))
mytable8 <- xtable(set, digits=3, caption='Average standard errors (Method 5 i) average standard error over simulation runs ii) s.e. estimated from all point estimates of simulation)')
print(mytable8,file=paste(directory,"/Results_sim1.tex",sep=""),append=TRUE,table.placement="H")


results <- list(true,s_est_a,s_est3_a,s_CI1_a,s_CI2_a,s_CI3_a,s_CI4_a,s_CI5_a,s_CI1_b,s_CI2_b,s_CI3_b,s_CI4_b,s_CI5_b,s_CI1_c,s_CI2_c,s_CI3_c,s_CI4_c,s_CI5_c,s_W1,s_W2,s_W3,s_W4,s_W5,M2_se,M5_se,M6_se,M5_est,sPool,sPool4,M3a_est,Summary1_save,Summary1_save2,Summary2_save,Summary2_save2,Summary3_save,cp1,cp2,cp3,iw,set)
save(results, file=paste(directory,"/sim1.Rdata",sep=""))
return(results)

} # end main function

###################
# Run simulations #
###################
# Note: Below a subfolder S1 for simulation 1 is used. Within this folder the subfolders M1,M2,M3,M4,M5,M10 and M20 are used to save results for the different settings 
#       Some of the results produced are not reported in the paper
# Note: Method 1= MI Boot pooled, Method 2 = MI Boot, Method 3= Boot MI, Method 4=Boot MI pooled, Method 5=no bootstrap, Method 6=original data without missing values
#       Table 1 in the paper lists the results in a different order  (method 3 and 4)


# Main simulation from Table 1
sim1.10 <- mysimulation(runs=1000,B=200,M=10,directory = paste0(getwd(),'/S1/M10') )

# Simulations used for Figure 1
sim1.5  <- mysimulation(runs=1000,B=200,M=5 ,directory =  paste0(getwd(),'/S1/M5'))
sim1.4  <- mysimulation(runs=1000,B=200,M=4 ,directory =  paste0(getwd(),'/S1/M4'))
sim1.3  <- mysimulation(runs=1000,B=200,M=3 ,directory =  paste0(getwd(),'/S1/M3'))
sim1.2  <- mysimulation(runs=1000,B=200,M=2 ,directory =  paste0(getwd(),'/S1/M2'))
sim1.1  <- mysimulation(runs=1000,B=200,M=1 ,directory =  paste0(getwd(),'/S1/M1'))
sim1.20 <- mysimulation(runs=1000,B=200,M=20,directory =  paste0(getwd(),'/S1/M20'))

################
# LOAD RESULTS #
################


load("S1//M1//sim1.Rdata")
m1<- results
sPool1 <- results[[31]]
sPool1.2 <- results[[33]]
est1.1  <- results[[32]]
est1.2  <- results[[35]] 
load("S1//M2//sim1.Rdata")
m2<- results
sPool2 <- results[[31]]
sPool2.2 <- results[[33]]
est2.1  <- results[[32]]
est2.2  <- results[[35]] 
load("S1//M3//sim1.Rdata")
m3<- results
sPool3 <- results[[31]]
sPool3.2 <- results[[33]]
est3.1  <- results[[32]]
est3.2  <- results[[35]] 
load("S1//M4//sim1.Rdata")
m4<- results
sPool4 <- results[[31]]
sPool4.2 <- results[[33]]
est4.1  <- results[[32]]
est4.2  <- results[[35]] 
load("S1//M5//sim1.Rdata")
m5<- results
sPool5 <- results[[31]]
sPool5.2 <- results[[33]]
est5.1  <- results[[32]]
est5.2  <- results[[35]] 
load("S1//M10//sim1.Rdata")
m10<- results
sPool10 <- results[[31]]
sPool10.2 <- results[[33]]
est10.1  <- results[[32]]
est10.2  <- results[[35]]
load("S1//M20//sim1.Rdata")
m20<- results
sPool20 <- results[[31]]
sPool20.2 <- results[[33]]
est20.1  <- results[[32]]
est20.2  <- results[[35]] 

###########
# TABLE 1 #
###########
# Coverage Probabilities
m10[[36]][,2]
# Median CI width
m10[[39]][,2]
# Std Error
m10[[40]][c(1,2,3),2]

############
# FIGURE 1 #
############

CP <- matrix(c(m20[[36]][,2],m10[[36]][,2],m5[[36]][,2],m4[[36]][,2],m3[[36]][,2],m2[[36]][,2],m1[[36]][,2]),ncol=1)
CP <- as.data.frame(CP)
CP$Imputations<- c(rep(20,6),rep(10,6),rep(5,6),rep(4,6),rep(3,6),rep(2,6),rep(1,6))
CP$Method <- rep(c("MI Boot (PS)","MI Boot","Boot MI","Boot MI (PS)","no bootstrap","original data"),7)
colnames(CP)[1] <- "covprob"

mycolors  <- c("black","black", "orangered3","orangered3", "springgreen3", "gold")
mylinetypes <-c("solid","dashed","solid","dashed","solid","dashed")

pdf(file="Figure1.pdf", width=9)
c1 <- ggplot(CP) + geom_line(aes(x=Imputations, y= covprob, colour=Method, group=Method, linetype=Method),size=I(1.5)) 
c1.1 <- c1  + scale_colour_manual(values = mycolors) + scale_linetype_manual(values=c(1,2,1,2,4,4))  + scale_x_continuous("Number of Imputations",breaks=c(1:5,10,20)) + scale_y_continuous("Coverage Probability",breaks=c(0.8,0.85,0.9,0.95,1)) +theme_bw()   + geom_abline(intercept = 0.95, slope= 0) + coord_cartesian(ylim=c(0.8,1))
c1.2 <- c1.1  + theme(axis.title.x = element_text(size=16), axis.text.x = element_text(size=16),axis.title.y = element_text(size=16, angle = 90), axis.text.y = element_text(size=16), legend.text =  element_text(size=11), legend.title =  element_text(size=13, face = "bold", hjust = 0),legend.position =   "bottom", legend.key.width = unit(2, "cm"))   
plot(c1.2)
dev.off()

############
# FIGURE 2 #
############
M=10
B=200
pick <- 10     # we pick simulation run number 10 to produce the figure
estp1 <-  matrix(est10.1[[pick]][,c(seq(1,(B*M)-(B-1),B))],ncol=M)[2,]
mydensity <- function(mymatrix){density(mymatrix[2,],na.rm=T)}
pymax <- function(myd){max(myd$y)}
pxmax <- function(myd){max(myd$x)}
pxmin <- function(myd){min(myd$x)}
myymax <- max(unlist(lapply(lapply(sPool10[[pick]],mydensity),pymax)))+0.1
myxmax <- max(unlist(lapply(lapply(sPool10[[pick]],mydensity),pxmax)))+0.05
myxmin <- min(unlist(lapply(lapply(sPool10[[pick]],mydensity),pxmin)))-0.05
greys <- gray.colors(10)
pdf(file="Figure2.pdf")
par(mfrow=c(2,1))
plot(NULL,ylim=c(0,myymax),xlim=c(0,myxmax),xlab="",ylab="Density",main="MI Boot (PS)")
for(i in 1:M){lines(density(sPool10[[pick]][[i]][2,],na.rm=T),col=greys[i],lwd=2)}
axis(side = 1 , at = 0.4, labels = F , tick = T , tcl = 1 , lwd.ticks = 3 , col.ticks = "black")
lines(c(-5,5),c(0,0),type="l",col="lightgrey")
axis(side = 1 , at = estp1, labels = F , tick = T , tcl = 1 , lwd.ticks = 3 , col.ticks = "black")
plot(NULL,ylim=c(0,27.5),xlim=c(0,myxmax),xlab="",ylab="Density",main="Boot MI (PS)")
for(i in 1:50){lines(density(sPool10.2[[pick]][[i]][2,],na.rm=T),col=gray.colors(50)[i],lwd=2)}
axis(side = 1 , at = est10.2[[pick]][2,][150:200], labels = F , tick = T , tcl = 0.4 , lwd.ticks = 3 , col.ticks = "black")
lines(c(-5,5),c(0,0),type="l",col="lightgrey")
dev.off()












