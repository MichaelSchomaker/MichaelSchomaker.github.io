#############################################################################################################
# Supplementary Material to Schomaker and Heuman, Bootstrap Inference when Using Multiple Imputation        #
# Statistics in Medicine; 37:2252-2266                                                                      #
#                                                                                                           #
# Simple example on how to employ the 4 methods from the paper in a simple linear regression setup          #
#############################################################################################################


##############################
# 0) libraries and functions #
##############################

library(Amelia)  # for imputation
library(copula)  # data generation with copulas

# multiple imputation inference - function from library(norm), slightly modified
mi.inference2 <-     # modified from library norm
function (est, std.err, confidence = 0.95)
{
    qstar <- est[[1]]
    for (i in 2:length(est)) {
        qstar <- cbind(qstar, est[[i]])
    }
    qbar <- apply(qstar, 1, mean)
    u <- std.err[[1]]
    for (i in 2:length(std.err)) {
        u <- cbind(u, std.err[[i]])
    }
    #dimnames(u)[[1]] <- dimnames(qstar)[[1]]
    u <- u^2
    ubar <- apply(u, 1, mean)
    bm <- apply(qstar, 1, var)
    m <- dim(qstar)[2]
    tm <- ubar + ((1 + (1/m)) * bm)
    rem <- (1 + (1/m)) * bm/ubar
    nu <- (m - 1) * (1 + (1/rem))^2
    alpha <- 1 - (1 - confidence)/2
    low <- qbar - qt(alpha, nu) * sqrt(tm)
    up <- qbar + qt(alpha, nu) * sqrt(tm)
    pval <- 2 * (1 - pt(abs(qbar/sqrt(tm)), nu))
    fminf <- (rem + 2/(nu + 3))/(rem + 1)
    result <- list(est = qbar, std.err = sqrt(tm), df = nu, signif = pval,
        lower = low, upper = up, r = rem, fminf = fminf, wiv = ubar, biw = bm)
    result
}

############################
# 1) Data Generation       #
############################

ntrain <- 1000
p1 <- rnorm(ntrain, 0, 1)
mu      <- 0 + 0.4*p1
mysigma <- 2
y <- rnorm(ntrain, mu, mysigma)

# Declare values of X1 to be missing
probab   <-  1-(1/((0.075*y)^2+1))
p1mis <- p1
for(k in 1:ntrain){p1mis[k] <- sample(c(p1[k],NA),1,prob=c(1-probab[k],probab[k]))}

# data set
dataex          <- as.data.frame(cbind(y,p1mis))
colnames(dataex)[2] <- "p1"

# Multiple Imputation
M=10
dataex_imp <- amelia(dataex,p2s=0,m=M)

# Imputed datasets are now called c1, c2 etc.
for(m in 1:M){
impname <- (paste("c",m,sep=""))
assign(impname, dataex_imp$imputations[[m]])
}

################################################
## 2) The 4 Different Methods from the Paper ###
################################################

# Number of bootstrap samples
B=1000

# Matrices to store results for different bootstrap samples and imputations
Summary1 <- rep(list(rep(list(matrix(NA,ncol=7,nrow=1,dimnames=NULL) ),B)),M)
Summary2 <- rep(list(rep(list(matrix(NA,ncol=7,nrow=1,dimnames=NULL) ),M)),B)

# a) First impute, then bootstrap, i.e "MI Boot" and "MI Boot (pooled)"

###################################
# Loop: Imputation
for(m in 1:M)try({
mydata <- get(paste("c",m,sep=""))

# Loop: Bootstrap
for(b in 1:B)try({
if(b==1){mydata<-get(paste("c",m,sep=""))} # in the first run we take the original data, afterwards bootstrap samples
if(b>1){mydata<-get(paste("c",m,sep=""))[sample(dim(get(paste("c",m,sep="")))[1],replace=TRUE),]}

m1 <- lm(y~., data=mydata)

Summary1[[m]][[b]] <- coefficients(m1)


}) # End: loop Bootstrap

}) # End: loop imputation


##############################
# "MI Boot (pooled sample)"  #
##############################

sPool               <- lapply(lapply(Summary1,unlist),matrix,ncol=B)
Summary1.1_CI       <- do.call(cbind, lapply(sPool, unlist))
Summary1.1    <-  matrix(Summary1.1_CI[,c(seq(1,(B*M)-(B-1),B))],ncol=M)
upper95<-function(myvector){quantile(myvector, probs=0.975)}
lower95<-function(myvector){quantile(myvector, probs=0.025)}

M1data <- as.data.frame(cbind(apply(Summary1.1 ,1,mean),apply(Summary1.1_CI,1,lower95),apply(Summary1.1_CI,1,upper95)))
colnames(M1data) <- c("est","l95","u95")


###############
# "MI Boot"   #
###############
myse <- function(mymatrix){apply(mymatrix,1,sd)}
Summary1.2.all.est <- rep(list(NULL),M)
for(m in 1:M){Summary1.2.all.est[[m]] <- Summary1.1[,m]}
Summary1.2.all.se <- lapply(sPool,myse)
if(M>1){Summary1.2 <- mi.inference2(Summary1.2.all.est, Summary1.2.all.se, confidence=0.95)}
if(M==1){Summary1.2 <- list(lower=unlist(Summary1.2.all.est)-qt(0.975,df=ntrain-param)*unlist(Summary1.2.all.se),upper=unlist(Summary1.2.all.est)+qt(0.975,df=ntrain-param)*unlist(Summary1.2.all.se),std.err=unlist(Summary1.2.all.se))}

M1bdata <- cbind(Summary1.2$est, Summary1.2$lower, Summary1.2$upper)
colnames(M1bdata) <- c("est","l95","u95")


###############
# "Boot MI"   #
###############

param=2 # number of parameters
M3a_est <- matrix(NA,nrow=param,ncol=B)      # to store results


# Loop: Bootstrap
for(b in 1:B)try({
if(b==1){mydata<-dataex}
if(b>1){mydata<-dataex[sample(dim(dataex)[1],replace=TRUE),]}

dataex_imp2 <- amelia(mydata,p2s=0,m=M)

for(m in 1:M){
impname <- (paste("m2.",m,sep=""))
assign(impname, lm(y~., data=as.data.frame(dataex_imp2$imputations[[m]])))
}

m3coef<-eval(parse(text=paste("list(",paste(paste("summary(m2.",seq(1:M),")[[4]][,1]",sep=""),sep=",", collapse=","),")")))
m3se <- eval(parse(text=paste("list(",paste(paste("summary(m2.",seq(1:M),")[[4]][,2]",sep=""),sep=",", collapse=","),")")))
if(M>1){Summary1.3a <- mi.inference2(m3coef, m3se, confidence=0.95)}
if(M==1){Summary1.3a <- list(est=unlist(m3coef),lower=unlist(m3coef)-qt(0.975,df=ntrain-param)*unlist(m3se),upper=unlist(m3coef)+qt(0.975,df=ntrain-param)*unlist(m3se))}
M3a_est[,b] <- Summary1.3a$est
for(m in 1:M){Summary2[[b]][[m]] <- m3coef[[m]]}
}) # End: loop Bootstrap


M2data <- cbind(apply(M3a_est,1,mean),apply(M3a_est,1,lower95),apply(M3a_est,1,upper95))

#################################
# "Boot MI (pooled sample)"     #
#################################

sPool4       <- lapply(lapply(Summary2,unlist),matrix,ncol=M)
Summary2.1_CI <- do.call(cbind, lapply(sPool4, unlist))
M4data <- cbind(apply(Summary2.1_CI,1,mean),apply(Summary2.1_CI,1,lower95),apply(Summary2.1_CI,1,upper95))
colnames(M4data) <- c("est","l95","u95")


#####################
# Without Bootstrap #
#####################

mycoeffs <- eval(parse(text=paste("list(",paste(paste("coef(lm(y~.,data=c",seq(1:M),"))",sep=""),sep=",", collapse=","),")")))
mystds <- eval(parse(text=paste("list(",paste(paste("summary(lm(y~.,data=c",seq(1:M),"))[[4]][,2]",sep=""),sep=",", collapse=","),")")))
if(M>1){Summary1.5 <- mi.inference2(mycoeffs, mystds, confidence=0.95)}
if(M==1){Summary1.5 <- list(est=unlist(mycoeffs),std.err=unlist(mystds),lower=unlist(mycoeffs)-qt(0.975,df=ntrain-param)*unlist(mystds),upper=unlist(mycoeffs)+qt(0.975,df=ntrain-param)*unlist(mystds))}

M5data<- cbind(Summary1.5$est, Summary1.5$lower, Summary1.5$upper)
colnames(M5data) <- c("est","l95","u95")

######################
# 3) Compare results #
######################

# i) no bootstrap inference
M5data

# ii) MI Boot (pooled sample)
M1data

# iii) MI Boot
M1bdata

# iv) Boot MI
M2data

# iv) Boot MI (pooled sample)
M4data