###################################################################################################################################################
# Supplementary Material to Schomaker and Heuman, Bootstrap Inference when Using Multiple Imputation                                              #
# Statistics in Medicine; 37:2252-2266                                                                                                            #
#                                                                                                                                                 #
# Simulation 4                                                                                                                                    #
#                                                                                                                                                 #
# The results can be obtained by simply pasting this file to R                                                                                    #
# Just 1) change your working directory                                                                                                           #
#      2) paste the mi.inference2.r file in the same folder as this file                                                                          #
#      3) Create subfolders as per instruction at the bottom of this file                                                                         #
# Figures and tables are produced automatically                                                                                                   #
# Settings can be varied by changing the function's options further below in the document or by changing the setup below, e.g. n, beta etc.       #
###################################################################################################################################################


# Set working directory
setwd("//home//mschomaker//Code_Reproduce//Bootstrap")

source('mi.inference2.r')# from library "norm" with tiny change
library(simcausal)
library(ltmle)
library(Amelia)
library(xtable)

##################################################
# Specify data-genrating process using simcausal #
##################################################

#left-truncated normal distribution
rnorm_trunc <- function(n, mean, sd, minval = 0, maxval = 10000,
                        min.low = 0, max.low = 50, min.high = 5000, max.high = 10000)
{
  out <- rnorm(n = n, mean = mean, sd = sd)
  minval <- minval[1]; min1 <- min.low[1]; max1 <- max.low[1]
  maxval <- maxval[1]; min2 <- min.high[1]; max2 <- max.high[1]
  leq.zero <- length(out[out <= minval])
  geq.max <- length(out[out >= maxval])
  out[out <= minval] <- runif(n = leq.zero, min = min1, max = max1)
  out[out >= maxval] <- runif(n = geq.max, min = min2, max = max2)
  out
}

#define the number of time points
t.end <- 12

#initialize the dag
D <- DAG.empty()

#everything at baseline (t = 0)
D.base <- D +
  node("V1",                                      #region 
       t = 0,
       distr = "rbern",
       prob = 4392/5826) +
  node("V2",                                      #sex
       t = 0,
       distr = "rbern",
       prob = ifelse(V1[0] == 1, 2222/4392, 758/1434)) +
  node("V3",                                      #age
       t = 0,
       distr = "runif",
       min = 1,
       max = 5) +
  node("L1",                                      #cd4-count 
       t = 0,
       distr = "rnorm_trunc",
       mean = ifelse(V1[0] == 1, 650, 720),
       sd = ifelse(V1[0] == 1, 350, 400),
       minval = 0, maxval = 10000,
       min.low = 0, max.low = 50, min.high = 5000, max.high = 10000) +
  node("L1scaled",                                #auxilliary-variable -> scaled L1_0
       t = 0,
       distr = "rnorm",
       mean = (L1[0]-671.7468)/(10*352.2788)+1,
       sd = 0) +
  node("L2",                                      #cd4% 
       t = 0,
       distr = "rnorm_trunc",
       mean = .16 + .05 * (L1[0] - 650)/650,
       sd = .07,
       minval = .06, maxval = .8,
       min.low = .03, max.low = .09, min.high = .7, max.high = .8) +
  node("L2scaled",                                #auxilliary-variable 
       t = 0,
       distr = "rnorm",
       mean = (L2[0]-0.1648594)/(10*0.06980332)+1,
       sd = 0) +
  node("L3",                                      #waz 
       t = 0,
       distr = "rnorm_trunc",
       mean = ifelse(V1[0] == 1, - 1.65 + .1 * V3[0] + .05 * (L1[0] - 650)/650 + .05 * (L2[0] - 16)/16,
                     - 2.05 + .1 * V3[0] + .05 * (L1[0] - 650)/650 + .05 * (L2[0] - 16)/16),
       sd = 1,
       minval = -5, maxval = 5,
       min.low = -10, max.low = -3, min.high = 3, max.high = 10) +
  node("A",                                       #art 
       t = 0,
       distr = "rbern",
       prob = 0) +
  node("C",                                      # death (censoring indicator) 
       t = 0,
       distr = "rbern",
       prob = 0,
       EFU = T) +
  node("Y",                                      #haz 
       t = 0,
       distr = "rnorm_trunc",
       mean = -2.6 + .1 * I(V3[0] > 2) + .3 * I(V1[0] == 0) + (L3[0] + 1.45),
       sd = 1.1,
       minval = -5, maxval = 5,
       min.low = -10, max.low = -3, min.high = 3, max.high = 10)

#time-dependent variables at later time-points
D <- D.base +
  node("L1",                                      #cd4-count
       t = 1:4,
       distr = "rnorm_trunc",
       mean = 13*log(t * (1034-662)/8) + L1[t-1] + 2 * L2[t-1] + 2 * L3[t-1] + 2.5 * A[t-1],
       sd = 50,
       minval = 0, maxval = 10000,
       min.low = 0, max.low = 50, min.high = 5000, max.high = 10000) +
  node("L1",                                      #cd4-count
       t = 5:8,
       distr = "rnorm_trunc",
       mean = 4*log(t * (1034-662)/8) + L1[t-1] + 2 * L2[t-1] + 2 * L3[t-1] + 2.5 * A[t-1],
       sd = 50,
       minval = 0, maxval = 10000,
       min.low = 0, max.low = 50, min.high = 5000, max.high = 10000) +
  node("L1",                                      #cd4-count
       t = 9:t.end,
       distr = "rnorm_trunc",
       mean = L1[t-1] + 2 * L2[t-1] + 2 * L3[t-1] + 2.5 * A[t-1],
       sd = 50,
       minval = 0, maxval = 10000,
       min.low = 0, max.low = 50, min.high = 5000, max.high = 10000) +
  node("L2",                                      #cd4%
       t = 1:t.end,
       distr = "rnorm_trunc",
       mean = L2[t-1] + .0003 * (L1[t]-L1[t-1]) + .0005 * (L3[t-1]) + .0005 * A[t-1] * L1scaled[0],
       sd = .02,
       minval = .06, maxval = .8,
       min.low = .03, max.low = .09, min.high = .7, max.high = .8) +
  node("L3",                                      #waz
       t = 1:t.end,
       distr = "rnorm_trunc",
       mean = L3[t-1] + .0017 * (L1[t] - L1[t-1]) + .2 * (L2[t] - L2[t-1]) + .005 * A[t-1] * L2scaled[0],
       sd = .5,
       minval = -5, maxval = 5,
       min.low = -10, max.low = -3, min.high = 3, max.high = 10) +
  node("A",                                       #art
       t = 1:t.end,
       distr = "rbern",
       prob = ifelse(A[t-1] == 1, 1, plogis(-2.4 + .015 * (750 - L1[t]) + 5 * (.2 - L2[t]) - .8 * L3[t] + .8 * t))) +
  node("C",                                      #death
       t = 1:t.end,
       distr = "rbern",
       prob = plogis(-6 + .01 * (750 - L1[t]) + 1 * (.2 - L2[t]) - .65 * L3[t] - A[t]),
       EFU = T)

D <- D +
  node("Y",                                      #haz
       t = 1:t.end,
       distr = "rnorm_trunc",
       mean = Y[t-1] +
         .00005 * (L1[t] - L1[t-1]) - 0.000001 * ((L1[t] - L1[t-1])*sqrt(L1scaled[0]))^2 +
         .01 * (L2[t] - L2[t-1]) - .0001 * ((L2[t] - L2[t-1])*sqrt(L2scaled[0]))^2 +
         .07 * ((L3[t]-L3[t-1])*(L3[0]+1.5135)) - .001 * ((L3[t]-L3[t-1])*(L3[0]+1.5135))^2 +
         .005 * A[t] + .075 * A[t-1] + .05 * A[t]*A[t-1] ,
       sd = .01,
       minval = -5, maxval = 5,
       min.low = -10, max.low = -3, min.high = 3, max.high = 10)

# observed data for n=5000

Dset <- set.DAG(D)
Odat <- simcausal::sim(DAG = Dset, n = 5000, rndseed = 7693, wide=T)
Odat$V1_0 <- factor(Odat$V1_0, levels = c(0, 1), labels = c("west","southern"))
Odat$V2_0 <- factor(Odat$V2_0, levels = c(0, 1), labels = c("female","male"))
Odat <- Odat[,-c(1,6,8)]

#specify dynamic interventions
Dset <- set.DAG(D)
int.a <- c(node("A", t = 1:t.end, distr = "rbern",
              prob = ifelse(A[t-1] == 1, 1, ifelse(L1[t] < theta1 | L2[t] < theta2 | L3[t] < theta3, 1, 0))),
           node("C", t = 1:t.end, distr = "rbern", prob = 0))

D.dyn1 <- Dset + action("A_th1", nodes = int.a, theta1 = 10000, theta2 = .99, theta3 = 10) # treat all (A=1)
D.dyn2 <- Dset + action("A_th2", nodes = int.a, theta1 = 750, theta2 = .25, theta3 = -2) # treat 750/25/-2
D.dyn3 <- Dset + action("A_th3", nodes = int.a, theta1 = 350, theta2 = .15, theta3 = -2) # treat 350/15/-2
D.dyn4 <- Dset + action("A_th4", nodes = int.a, theta1 = -1, theta2 = -.1, theta3 = -11) # treat never (A=0)

dat1 <- simcausal::sim(DAG = D.dyn1, actions = "A_th1", n = 1000000, rndseed = 7693)
dat2 <- simcausal::sim(DAG = D.dyn2, actions = "A_th2", n = 1000000, rndseed = 7693)
dat3 <- simcausal::sim(DAG = D.dyn3, actions = "A_th3", n = 1000000, rndseed = 7693)
dat4 <- simcausal::sim(DAG = D.dyn4, actions = "A_th4", n = 1000000, rndseed = 7693)

true <- matrix(NA,ncol=5,nrow=13)
rownames(true) <- 0:12
colnames(true) <- c("immediate ART", "<750; <25%; < -2", "<350; <15%; < -2", "no ART", "obs.data")

true[1,1] <- mean(na.omit((dat1[["A_th1"]])$Y_0))
true[2,1] <- mean(na.omit((dat1[["A_th1"]])$Y_1))
true[3,1] <- mean(na.omit((dat1[["A_th1"]])$Y_2))
true[4,1] <- mean(na.omit((dat1[["A_th1"]])$Y_3))
true[5,1] <- mean(na.omit((dat1[["A_th1"]])$Y_4))
true[6,1] <- mean(na.omit((dat1[["A_th1"]])$Y_5))
true[7,1] <- mean(na.omit((dat1[["A_th1"]])$Y_6))
true[8,1] <- mean(na.omit((dat1[["A_th1"]])$Y_7))
true[9,1] <- mean(na.omit((dat1[["A_th1"]])$Y_8))
true[10,1] <- mean(na.omit((dat1[["A_th1"]])$Y_9))
true[11,1] <- mean(na.omit((dat1[["A_th1"]])$Y_10))
true[12,1] <- mean(na.omit((dat1[["A_th1"]])$Y_11))
true[13,1] <- mean(na.omit((dat1[["A_th1"]])$Y_12))

true[1,2] <- mean(na.omit((dat2[["A_th2"]])$Y_0))
true[2,2] <- mean(na.omit((dat2[["A_th2"]])$Y_1))
true[3,2] <- mean(na.omit((dat2[["A_th2"]])$Y_2))
true[4,2] <- mean(na.omit((dat2[["A_th2"]])$Y_3))
true[5,2] <- mean(na.omit((dat2[["A_th2"]])$Y_4))
true[6,2] <- mean(na.omit((dat2[["A_th2"]])$Y_5))
true[7,2] <- mean(na.omit((dat2[["A_th2"]])$Y_6))
true[8,2] <- mean(na.omit((dat2[["A_th2"]])$Y_7))
true[9,2] <- mean(na.omit((dat2[["A_th2"]])$Y_8))
true[10,2] <- mean(na.omit((dat2[["A_th2"]])$Y_9))
true[11,2] <- mean(na.omit((dat2[["A_th2"]])$Y_10))
true[12,2] <- mean(na.omit((dat2[["A_th2"]])$Y_11))
true[13,2] <- mean(na.omit((dat2[["A_th2"]])$Y_12))

true[1,3] <- mean(na.omit((dat3[["A_th3"]])$Y_0))
true[2,3] <- mean(na.omit((dat3[["A_th3"]])$Y_1))
true[3,3] <- mean(na.omit((dat3[["A_th3"]])$Y_2))
true[4,3] <- mean(na.omit((dat3[["A_th3"]])$Y_3))
true[5,3] <- mean(na.omit((dat3[["A_th3"]])$Y_4))
true[6,3] <- mean(na.omit((dat3[["A_th3"]])$Y_5))
true[7,3] <- mean(na.omit((dat3[["A_th3"]])$Y_6))
true[8,3] <- mean(na.omit((dat3[["A_th3"]])$Y_7))
true[9,3] <- mean(na.omit((dat3[["A_th3"]])$Y_8))
true[10,3] <- mean(na.omit((dat3[["A_th3"]])$Y_9))
true[11,3] <- mean(na.omit((dat3[["A_th3"]])$Y_10))
true[12,3] <- mean(na.omit((dat3[["A_th3"]])$Y_11))
true[13,3] <- mean(na.omit((dat3[["A_th3"]])$Y_12))

true[1,4] <- mean(na.omit((dat4[["A_th4"]])$Y_0))
true[2,4] <- mean(na.omit((dat4[["A_th4"]])$Y_1))
true[3,4] <- mean(na.omit((dat4[["A_th4"]])$Y_2))
true[4,4] <- mean(na.omit((dat4[["A_th4"]])$Y_3))
true[5,4] <- mean(na.omit((dat4[["A_th4"]])$Y_4))
true[6,4] <- mean(na.omit((dat4[["A_th4"]])$Y_5))
true[7,4] <- mean(na.omit((dat4[["A_th4"]])$Y_6))
true[8,4] <- mean(na.omit((dat4[["A_th4"]])$Y_7))
true[9,4] <- mean(na.omit((dat4[["A_th4"]])$Y_8))
true[10,4] <- mean(na.omit((dat4[["A_th4"]])$Y_9))
true[11,4] <- mean(na.omit((dat4[["A_th4"]])$Y_10))
true[12,4] <- mean(na.omit((dat4[["A_th4"]])$Y_11))
true[13,4] <- mean(na.omit((dat4[["A_th4"]])$Y_12))

true[1,5] <- mean(na.omit(Odat$Y_0))
true[2,5] <- mean(na.omit(Odat$Y_1))
true[3,5] <- mean(na.omit(Odat$Y_2))
true[4,5] <- mean(na.omit(Odat$Y_3))
true[5,5] <- mean(na.omit(Odat$Y_4))
true[6,5] <- mean(na.omit(Odat$Y_5))
true[7,5] <- mean(na.omit(Odat$Y_6))
true[8,5] <- mean(na.omit(Odat$Y_7))
true[9,5] <- mean(na.omit(Odat$Y_8))
true[10,5] <- mean(na.omit(Odat$Y_9))
true[11,5] <- mean(na.omit(Odat$Y_10))
true[12,5] <- mean(na.omit(Odat$Y_11))
true[13,5] <- mean(na.omit(Odat$Y_12))

true2 <- true

##############
# Simulation #
##############

mysimulation <- function(runs=2,B=2,M=2,N=1000,directory = "C:/Users/01429265/Documents/Research_Statistics/Imputation_and_Bootstrapping/Simulations/Simulation7"){

ptm <- proc.time()
param <- 2
missingstat_total <- c(rep(0,3))
M_est <- matrix(NA,nrow=param,ncol=runs)
M1_CI <- matrix(NA,nrow=param,ncol=runs)
M1_CI2 <- matrix(NA,nrow=param,ncol=runs)
M1_CI3 <- matrix(NA,nrow=param,ncol=runs)
M2_est  <- matrix(NA,nrow=param,ncol=runs)
M2_CI <- matrix(NA,nrow=param,ncol=runs)
M2_CI2 <- matrix(NA,nrow=param,ncol=runs)
M2_CI3 <- matrix(NA,nrow=param,ncol=runs)
M3_est <- matrix(NA,nrow=param,ncol=runs)
M3_CI <- matrix(NA,nrow=param,ncol=runs)
M3_CI2 <- matrix(NA,nrow=param,ncol=runs)
M3_CI3 <- matrix(NA,nrow=param,ncol=runs)
M4_CI <- matrix(NA,nrow=param,ncol=runs)
M4_CI2 <- matrix(NA,nrow=param,ncol=runs)
M4_CI3 <- matrix(NA,nrow=param,ncol=runs)
M5_CI <- matrix(NA,nrow=param,ncol=runs)
M5_CI2 <- matrix(NA,nrow=param,ncol=runs)
M5_CI3 <- matrix(NA,nrow=param,ncol=runs)
M6_est <- matrix(NA,nrow=param,ncol=runs)
M6_CI <- matrix(NA,nrow=param,ncol=runs)
M6_CI2 <- matrix(NA,nrow=param,ncol=runs)
M6_CI3 <- matrix(NA,nrow=param,ncol=runs)
M1_width <- matrix(NA,nrow=param,ncol=runs)
M2_width <- matrix(NA,nrow=param,ncol=runs)
M3_width <- matrix(NA,nrow=param,ncol=runs)
M4_width <- matrix(NA,nrow=param,ncol=runs)
M5_width <- matrix(NA,nrow=param,ncol=runs)
M6_width <- matrix(NA,nrow=param,ncol=runs)
M2_se <- matrix(NA,nrow=param,ncol=runs)
M3_se <- matrix(NA,nrow=param,ncol=runs)
M5_se <- matrix(NA,nrow=param,ncol=runs)
M6_se <- matrix(NA,nrow=param,ncol=runs)
M5_est <- matrix(NA,nrow=param,ncol=runs)
Summary1 <- rep(list(rep(list(matrix(NA,ncol=param,nrow=1,dimnames=NULL) ),B)),M)
Summary2 <- rep(list(rep(list(matrix(NA,ncol=param,nrow=1,dimnames=NULL) ),M)),B)
Summary1_save <- rep(list(NA),runs)
Summary2_save <- rep(list(NA),runs)
Summary3_save <- rep(list(NA),runs)
Summary1_save2 <- rep(list(NA),runs)
Summary2_save2 <- rep(list(NA),runs)
cpt2 <- rep(NA,runs)
cpt3 <- rep(NA,runs)
#



for(r in 1:runs)try({
#
ptm.ib <- proc.time()
#
cat(paste("This is simulation run number",r, "\n"))
#
cn <- runif(1,1,100000000)
simdat  <- simcausal::sim(DAG = Dset, n = N, wide=F, rndseed=cn)
simdat  <-  simdat[,-c(5,6)]
#
true <- true2[13,c(1,4)]
#
probab   <-  1-(1/((0.001*simdat$L1[simdat$t==0])^2+1))
for(k in 1:N){simdat$L2[simdat$t==0][k] <- sample(c(simdat$L2[simdat$t==0][k],NA),1,prob=c(1-probab[k],probab[k]))}
#
probab2   <-  1-(1/((0.00005*simdat$t[simdat$t!=0]*simdat$L1[simdat$t!=0])^2+1))
for(k in 1:N){simdat$L2[simdat$t!=0][k] <- sample(c(simdat$L2[simdat$t!=0][k],NA),1,prob=c(1-probab2[k],probab2[k]))}
#
probab3   <-  1-(1/((0.2*abs(simdat$Y[simdat$t==0]))^2+1))
for(k in 1:N){simdat$L3[simdat$t==0][k] <- sample(c(simdat$L3[simdat$t==0][k],NA),1,prob=c(1-probab3[k],probab3[k]))}
#
probab4   <-  1-(1/((0.015*simdat$t[simdat$t!=0]*abs(simdat$Y[simdat$t!=0]))^2+1))
probab4[is.na(probab4)] <- mean(na.omit(probab4))
for(k in 1:N){simdat$L3[simdat$t!=0][k] <- sample(c(simdat$L3[simdat$t!=0][k],NA),1,prob=c(1-probab4[k],probab4[k]))}
# 
probab5   <-  0.1
for(k in 1:dim(simdat)[1]){simdat$L1[k] <- sample(c(simdat$L1[k],NA),1,prob=c(1-probab5,probab5))}
#
probab6   <-  1-(1/((0.7*abs(simdat$L3[simdat$t==0]))^2+1))
probab6[is.na(probab6)] <- mean(na.omit(probab6))
for(k in 1:N){simdat$Y[simdat$t==0][k] <- sample(c(simdat$Y[simdat$t==0][k],NA),1,prob=c(1-probab6[k],probab6[k]))}
#
probab7   <-  1-(1/((0.015*simdat$t[simdat$t!=0]*abs(simdat$L3[simdat$t!=0]))^2+1))
probab7[is.na(probab7)] <- mean(na.omit(probab4))
for(k in 1:N){simdat$Y[simdat$t!=0][k] <- sample(c(simdat$Y[simdat$t!=0][k],NA),1,prob=c(1-probab7[k],probab7[k]))}
#
ct1 <- proc.time()
#
cat("MI Boot...")
simdatMI <- amelia(simdat, m=M, p2s=0, lags=c("L1","L2","L3","A","Y"), leads=c("L1","L2","L3","A","Y"), cs=c("ID"),ts=c("t"), idvars="C", bounds=matrix(c(5,6,7,10,0,0,-10,-10,10000,80,10,10),ncol=3,nrow=4),intercs=F,polytime=3,splinetime=3,incheck=F)
#par(mfrow=c(2,2))
#compare.density(simdatMI,var="L1")
#compare.density(simdatMI,var="L2")
#compare.density(simdatMI,var="L3")
#compare.density(simdatMI,var="Y")
#
for(m in 1:M){
impname <- (paste("c",m,sep=""))
assign(impname, reshape(simdatMI$imputations[[m]], v.names = c("L1","L2","L3","A","C","Y"), idvar = "ID",
                timevar = "t", direction = "wide") )
assign(impname, get(impname)[,-c(1,8,9)])
temp <- get(impname)
colnames(temp)[1:7] <-   c("b1","b2","b3","b4","b5","b6","b7")
temp[, c(grep("C",colnames(temp)))][temp[, c(grep("C",colnames(temp)))]==1] <- 2
temp[, c(grep("C",colnames(temp)))][temp[, c(grep("C",colnames(temp)))]==0] <- 1
temp[, c(grep("C",colnames(temp)))][temp[, c(grep("C",colnames(temp)))]==2] <- 0
for(j in c(grep("C",colnames(temp)))){temp[, j] <- BinaryToCensoring(is.uncensored=temp[, j])}
assign(impname, temp)
}
#

###############
### MI Boot ###
###############

# Loop: Imputation
for(m in 1:M)try({
mydata <- get(paste("c",m,sep=""))

# Loop: Bootstrap
for(b in 1:B)try({
if(b==1){mydata<-get(paste("c",m,sep=""))} # in the first run we take the original data, afterwards bootstrap samples
if(b>1){mydata<-get(paste("c",m,sep=""))[sample(dim(get(paste("c",m,sep="")))[1],replace=TRUE),]}

m1  <-  suppressMessages(suppressWarnings(ltmle(mydata,
                  Anodes=c(grep("A.",colnames(mydata))),
                  Cnodes=c(grep("C",colnames(mydata))),
                  Lnodes=sort(c(grep("L1.",colnames(mydata)),grep("L2.",colnames(mydata)),grep("L3.",colnames(mydata)))),
                  Ynodes=c(grep("Y.",colnames(mydata))), Yrange=c(-10,10),
                  Qform=NULL, gform=NULL, deterministic.g.function=MaintainTreatment, abar=rep(1,12), stratify=FALSE, variance.method="ic",
                  SL.library=NULL, estimate.time=T, gcomp=T)))
m2  <-  suppressMessages(suppressWarnings(ltmle(mydata,
                  Anodes=c(grep("A.",colnames(mydata))),
                  Cnodes=c(grep("C",colnames(mydata))),
                  Lnodes=sort(c(grep("L1.",colnames(mydata)),grep("L2.",colnames(mydata)),grep("L3.",colnames(mydata)))),
                  Ynodes=c(grep("Y.",colnames(mydata))), Yrange=c(-10,10),
                  Qform=NULL, gform=NULL, deterministic.g.function=MaintainTreatment, abar=rep(0,12), stratify=FALSE, variance.method="ic",
                  SL.library=NULL, estimate.time=T, gcomp=T)))

Summary1[[m]][[b]][1] <- m1$estimates[1]
Summary1[[m]][[b]][2] <- m2$estimates[1]

}) # End: loop Bootstrap

}) # End: loop imputation

#############
# Method 1  #
#############

sPool               <- lapply(lapply(Summary1,unlist),matrix,ncol=B)
Summary1.1_CI       <- do.call(cbind, lapply(sPool, unlist))
Summary1_save[[r]]  <- sPool
Summary1_save2[[r]] <- Summary1.1_CI
Summary1.1    <-  matrix(Summary1.1_CI[,c(seq(1,(B*M)-(B-1),B))],ncol=M)
upper95<-function(myvector){quantile(myvector, probs=0.975)}
lower95<-function(myvector){quantile(myvector, probs=0.025)}

M1data <- as.data.frame(cbind(apply(Summary1.1 ,1,mean),apply(Summary1.1_CI,1,lower95),apply(Summary1.1_CI,1,upper95)))
colnames(M1data) <- c("est","l95","u95")

include_true_M1 <- as.numeric((M1data$l95 <= true) & (M1data$u95>= true))

width_M1 <- M1data$u95-M1data$l95

M_est[,r]       <- M1data$est
M1_CI[,r]       <- include_true_M1
M1_width[,r]    <- width_M1

#############
# Method 2  #
#############

myse <- function(mymatrix){apply(mymatrix,1,sd)}
Summary1.2.all.est <- rep(list(NULL),M)
for(m in 1:M){Summary1.2.all.est[[m]] <- Summary1.1[,m]}
Summary1.2.all.se <- lapply(sPool,myse)
if(M>1){Summary1.2 <- mi.inference2(Summary1.2.all.est, Summary1.2.all.se, confidence=0.95)}
if(M==1){Summary1.2 <- list(lower=unlist(Summary1.2.all.est)-qt(0.975,df=ntrain-param)*unlist(Summary1.2.all.se),upper=unlist(Summary1.2.all.est)+qt(0.975,df=ntrain-param)*unlist(Summary1.2.all.se),std.err=unlist(Summary1.2.all.se))}

include_true_M2 <- as.numeric((Summary1.2$lower <= true) & (Summary1.2$upper>= true))
width_M2 <- Summary1.2$upper-Summary1.2$lower

M2_est[,r] <- Summary1.2$est
M2_CI[,r]  <- include_true_M2
M2_width[,r]   <- width_M2
M2_se[,r] <- Summary1.2$std.err

ct2 <- proc.time()

cat("Boot MI...\n")

#############
# Method 3  #
#############
ct3 <- proc.time()
M3a_est <- matrix(NA,nrow=param,ncol=B)

ct3 <- proc.time()
# Loop: Bootstrap
for(b in 1:B)try({
if(b==1){mydata<-simdat
colnames(mydata)[c(1,5)] <- c("id","time")
} 
if(b>1){                                   # this is the longitudinal bootstrap: clever and fast
simdat_wide <- reshape(simdat, v.names = c("L1","L2","L3","A","C","Y"), idvar = "ID",
                timevar = "t", direction = "wide")
simdat_wide <- simdat_wide[,-c(1)]
mydata<-simdat_wide[sample(dim(simdat_wide)[1],replace=TRUE),]
mydata <- reshape(mydata, varying=colnames(mydata)[c(4:dim(mydata)[2])], direction = "long", times=rep(c(1:13),N))
mydata <- mydata[order(mydata$id, mydata$time),]
ind <- is.na(mydata$L1) & is.na(mydata$L2) & is.na(mydata$L3) & is.na(mydata$A) & is.na(mydata$C)& is.na(mydata$Y)
mydata <- mydata[-c(1:dim(mydata)[1])[ind==T],]
}
simdatMI_2 <- amelia(mydata, m=M, p2s=0, lags=c("L1","L2","L3","A","Y"), leads=c("L1","L2","L3","A","Y"), cs=c("id"),ts=c("time"), idvars="C", bounds=matrix(c(5,6,7,10,0,0,-10,-10,10000,80,10,10),ncol=3,nrow=4),intercs=F,polytime=3,splinetime=3,incheck=F)

for(m in 1:M){
impname <- (paste("c",m,sep=""))
assign(impname, reshape(simdatMI_2$imputations[[m]], v.names = c("L1","L2","L3","A","C","Y"), idvar = "id",
                timevar = "time", direction = "wide") )
assign(impname, get(impname)[,-c(1,8,9)])
temp <- get(impname)
colnames(temp)[1:7] <-   c("b1","b2","b3","b4","b5","b6","b7")
temp[, c(grep("C",colnames(temp)))][temp[, c(grep("C",colnames(temp)))]==1] <- 2
temp[, c(grep("C",colnames(temp)))][temp[, c(grep("C",colnames(temp)))]==0] <- 1
temp[, c(grep("C",colnames(temp)))][temp[, c(grep("C",colnames(temp)))]==2] <- 0
for(j in c(grep("C",colnames(temp)))){temp[, j] <- BinaryToCensoring(is.uncensored=temp[, j])}
assign(impname, temp)
}

coeff <- matrix(NA,ncol=param,nrow=M)
for(m in 1:M){
t1 <- suppressMessages(suppressWarnings(ltmle(get((paste("c",m,sep=""))),
                  Anodes=c(grep("A.",colnames(get((paste("c",m,sep="")))))),
                  Cnodes=c(grep("C",colnames(get((paste("c",m,sep="")))))),
                  Lnodes=sort(c(grep("L1.",colnames(get((paste("c",m,sep=""))))),grep("L2.",colnames(get((paste("c",m,sep=""))))),grep("L3.",colnames(get((paste("c",m,sep=""))))))),
                  Ynodes=c(grep("Y.",colnames(get((paste("c",m,sep="")))))), Yrange=c(-10,10),
                  Qform=NULL, gform=NULL, deterministic.g.function=MaintainTreatment, abar=rep(1,12), stratify=FALSE, variance.method="ic",
                  SL.library=NULL, estimate.time=T, gcomp=T)))
t2 <- suppressMessages(suppressWarnings(ltmle(get((paste("c",m,sep=""))),
                  Anodes=c(grep("A.",colnames(get((paste("c",m,sep="")))))),
                  Cnodes=c(grep("C",colnames(get((paste("c",m,sep="")))))),
                  Lnodes=sort(c(grep("L1.",colnames(get((paste("c",m,sep=""))))),grep("L2.",colnames(get((paste("c",m,sep=""))))),grep("L3.",colnames(get((paste("c",m,sep=""))))))),
                  Ynodes=c(grep("Y.",colnames(get((paste("c",m,sep="")))))), Yrange=c(-10,10),
                  Qform=NULL, gform=NULL, deterministic.g.function=MaintainTreatment, abar=rep(0,12), stratify=FALSE, variance.method="ic",
                  SL.library=NULL, estimate.time=T, gcomp=T)))
                  
coeff[m,] <- c(t1$estimate[1],t2$estimate[1])
}

m3coef <- apply(coeff,2,mean)
M3_est[,r]<-m3coef
M3a_est[,b] <- m3coef 
for(m in 1:M){Summary2[[b]][[m]] <- coeff[m,]}
}) # End: loop Bootstrap
ct4 <- proc.time()

include_true_M3 <- as.numeric((apply(M3a_est,1,lower95) <= true)   & (apply(M3a_est,1,upper95)>= true))
width_M3 <- apply(M3a_est,1,upper95)-(apply(M3a_est,1,lower95))

M3_CI[,r]       <- include_true_M3
M3_se[,r] <- apply(M3a_est,1,sd)
M3_width[,r]    <- width_M3
Summary3_save[[r]]  <- M3a_est

#############
# Method 4  #
#############

sPool4       <- lapply(lapply(Summary2,unlist),matrix,ncol=M)
Summary2.1_CI <- do.call(cbind, lapply(sPool4, unlist))
Summary2_save[[r]]  <- sPool4
Summary2_save2[[r]] <- Summary2.1_CI
M4data <- as.data.frame(cbind(apply(Summary2.1_CI,1,lower95),apply(Summary2.1_CI,1,upper95)))
colnames(M4data) <- c("l95","u95")

include_true_M4 <- as.numeric((M4data$l95 <= true) & (M4data$u95>= true))
width_M4 <- M4data$u95-M4data$l95

M4_CI[,r]   <- include_true_M4
M4_width[,r]   <- width_M4
ct4 <- proc.time()
###############################################
# Check missingness properties  
avmis <- function(myvector){
return(mean(is.na(myvector)))
}
avmistot <- function(myvector){
return(any(is.na(myvector)))
}
missingstat <- apply(simdat[simdat$t==0,],c(2),avmis)
missingstat2 <- mean(apply(simdat[simdat$t==0,],c(1),avmistot))
missingstat3 <- apply(simdat[simdat$t!=0,],c(2),avmis)
missingstat4 <- mean(apply(simdat[simdat$t!=0,],c(1),avmistot))
missingstat <- round(c(missingstat,missingstat2, missingstat3, missingstat4),digits=4)
names(missingstat)<-c(colnames(simdat),"total", colnames(simdat),"total")
missingstat_total <- missingstat_total+missingstat
###############################################
cpt2[r] <-   ((ct2-ct1)/60)[1]
cpt3[r] <-   ((ct4-ct3)/60)[1]

##############################################
ptm.ib2 <- proc.time()
ibt <- round(((ptm.ib2-ptm.ib)/60)[1],digits=2)
if(r==1){cat(paste("The simulation will run for about another", runs*ibt-ibt, "minutes \n"))}
##############################################
tempresults <- list(true, M_est, M2_est, M3_est, M1_CI, M2_CI, M3_CI, M4_CI, M1_width, M2_width, M3_width, M4_width, Summary1_save, Summary2_save, Summary3_save, M2_se, M3_se, cpt2, cpt3)
save(tempresults, file=paste(directory,"/S4/tempresults.Rdata",sep=""))
#
}) # End: loop simulation runs



###################
# Produce results #
###################

s_est_a   <- apply(M_est[,!apply(M_est,2,is.na)[1,]],1,mean)
s_est2_a <-  apply(M2_est[,!apply(M2_est,2,is.na)[1,]],1,mean)
s_est3_a <-  apply(M3_est[,!apply(M3_est,2,is.na)[1,]],1,mean)

s_CI1_a <- apply(M1_CI[,!apply(M1_CI,2,is.na)[1,]],1,mean)
s_CI2_a <- apply(M2_CI[,!apply(M2_CI,2,is.na)[1,]],1,mean)
s_CI3_a <- apply(M3_CI[,!apply(M3_CI,2,is.na)[1,]],1,mean)
s_CI4_a <- apply(M4_CI[,!apply(M4_CI,2,is.na)[1,]],1,mean)

s_W1 <- apply(M1_width[,!apply(M1_width,2,is.na)[1,]],1,median)
s_W2 <- apply(M2_width[,!apply(M2_width,2,is.na)[1,]],1,median)
s_W3 <- apply(M3_width[,!apply(M3_width,2,is.na)[1,]],1,median)
s_W4 <- apply(M4_width[,!apply(M4_width,2,is.na)[1,]],1,median)

mruns <- sum(apply(M1_CI,2,is.na)[1,])
mruns2 <- sum(apply(M2_CI,2,is.na)[1,])
mruns3 <- sum(apply(M3_CI,2,is.na)[1,])
mruns4 <- sum(apply(M4_CI,2,is.na)[1,])

cat(paste("Number of failed runs for the 4 methods:",mruns,mruns2,mruns3,mruns4),"\n")
missruns <- paste("Number of failed runs for the 4 methods:",mruns,mruns2,mruns3,mruns4)

# Summarize the distribution
l1 <- length(unlist(Summary1_save))
l2 <- length(unlist(Summary2_save))
l3 <- length(unlist(Summary3_save))

pdf(file=paste(directory,"/S4/Fig1.pdf",sep=""))
plot(density(c(do.call(cbind, lapply(Summary1_save, unlist)))[seq(1,l3-1,2)],na.rm=T),main="",sub="",xlab="",lwd=3,lty=4,col="blue", xlim=c(-1.4,-0.7))
lines(density(c(do.call(cbind, lapply(Summary1_save, unlist)))[seq(1,l1-1,2)],na.rm=T),main="",sub="",xlab="",lwd=3,lty=3,col="darkgrey")
lines(density(c(do.call(cbind, lapply(Summary1_save, unlist)))[seq(1,l2-1,2)],na.rm=T),main="",sub="",xlab="",lwd=3,lty=2,col="red")
axis(side = 1 , at = true[1], labels = F , tick = T , tcl = 1 , lwd.ticks = 3 , col.ticks = "blue")
legend("topright",lty=c(3,4,2,1),legend=c("MI Boot pooled","Boot MI","Boot MI pooled"), lwd=3, cex=1.25, col=c("darkgrey","blue","red"))
dev.off()

pdf(file=paste(directory,"/S4/Fig2.pdf",sep=""))
plot(density(c(do.call(cbind, lapply(Summary1_save, unlist)))[seq(2,l3,2)],na.rm=T),main="",sub="",xlab="",lwd=3,lty=4,col="blue", xlim=c(-2.8,-2.2))
lines(density(c(do.call(cbind, lapply(Summary1_save, unlist)))[seq(2,l1,2)],na.rm=T),main="",sub="",xlab="",lwd=3,lty=3,col="darkgrey")
lines(density(c(do.call(cbind, lapply(Summary1_save, unlist)))[seq(2,l2,2)],na.rm=T),main="",sub="",xlab="",lwd=3,lty=2,col="red")
axis(side = 1 , at = true[2], labels = F , tick = T , tcl = 1 , lwd.ticks = 3 , col.ticks = "blue")
legend("topright",lty=c(3,4,2,1),legend=c("MI Boot pooled","Boot MI","Boot MI pooled"), lwd=3, cex=1.25, col=c("darkgrey","blue","red"))
dev.off()

# Save results
# How long did it take?
ptm2 <-  proc.time()
simulationsdauer <- ptm2-ptm
simulationsdauer <- (simulationsdauer/60)
simulationsdauer <- round(simulationsdauer[1], digits=2)
cat(paste("The simulation time was", simulationsdauer, "minutes \n"))
finaltime <-  paste("The simulation time was", simulationsdauer, "minutes")



# Table 1: Simulation Info
Info <- matrix(rbind("This is simulation no. 4",paste("Number of intended simulation runs:",runs),missruns,paste("Number of bootstrap samples:",B),paste("Number of multiple imputations:",M),finaltime),dimnames=NULL)
colnames(Info) <- "Setup"
rownames(Info) <- NULL
mytable1 <- xtable(Info, caption='Simulation details')
print(mytable1,file=paste(directory,"/S4/Results_sim4.tex",sep=""),table.placement="H",include.rownames=FALSE)

# Table 2: Missingness Probability
missingstat_final <- matrix(round(missingstat_total/runs,digits=4),nrow=1)
rownames(missingstat_final)<-c("missing prob.")
colnames(missingstat_final)<- names(missingstat_total)
missingstat_final <-  missingstat_final[,-c(1:5,13:17)]
mytable2 <- xtable(t(as.matrix(missingstat_final)), caption='missingness percentages for the variables')
print(mytable2,file=paste(directory,"/S4/Results_sim4.tex",sep=""),append=TRUE,table.placement="H")

# Table 3: point estimates
pe <-  matrix(rbind(true,s_est2_a,s_est3_a),ncol=2,nrow=3,dimnames=list(c("True parameters","estimated (MI Boot)","estimated (Boot MI)"),c("psi_1","psi_2")))
mytable3 <- xtable(pe, caption='point estimates for the different variables (averaged over simulation runs)')
print(mytable3,file=paste(directory,"/S4/Results_sim4.tex",sep=""),append=TRUE,table.placement="H")

# Table 4: coverage probability
cp1 <- matrix(rbind(s_CI1_a,s_CI2_a,s_CI3_a,s_CI4_a),ncol=2,nrow=4,dimnames=list(c("MI Boot pooled","MI Boot","Boot MI","Boot MI pooled"),c("psi_1","psi_2")))
mytable4 <- xtable(cp1, caption='estimated coverage probability of true parameter')
print(mytable4,file=paste(directory,"/S4/Results_sim4.tex",sep=""),append=TRUE,table.placement="H")

# Table 7: interval width
iw <- matrix(rbind(s_W1,s_W2,s_W3,s_W4),ncol=2,nrow=4,dimnames=list(c("MI Boot pooled","MI Boot","Boot MI","Boot MI pooled"),c("psi_1","psi_2")))
mytable7 <- xtable(iw, caption='Median confidence interval width')
print(mytable7,file=paste(directory,"/S4/Results_sim4.tex",sep=""),append=TRUE,table.placement="H")

# Table 8: standard errors
set <- matrix(rbind(apply(M2_se[,!apply(M2_se,2,is.na)[1,]],1,mean),apply(M3_se[,!apply(M3_se,2,is.na)[1,]],1,mean),apply(M5_se[,!apply(M5_se,2,is.na)[1,]],1,mean),apply(M5_est[,!apply(M5_est,2,is.na)[1,]],1,sd),apply(M6_se[,!apply(M6_se,2,is.na)[1,]],1,mean)),ncol=2,nrow=5,dimnames=list(c("MI Boot","Boot MI","no bootstrap - se/runs","no bootstrap - se(est)","Original data"),c("psi_1","psi_2")))
mytable8 <- xtable(set[1:2,], digits=3, caption='Average standard errors')
print(mytable8,file=paste(directory,"/S4/Results_sim4.tex",sep=""),append=TRUE,table.placement="H")

# Table 9: computation time
ctt <- matrix(c(mean(cpt2),mean(cpt3)),ncol=1,nrow=2,dimnames=list(c("MI Boot","Boot MI"),c("mean CT")))
mytable9 <- xtable(ctt, digits=4, caption='mean computation time (in minutes)')
print(mytable9,file=paste(directory,"/S4/Results_sim4.tex",sep=""),append=TRUE,table.placement="H")

#
results <- list(true, M_est, M2_est, M3_est, M1_CI, M2_CI, M3_CI, M4_CI, M1_width, M2_width, M3_width, M4_width, Summary1_save, Summary2_save, Summary3_save, M2_se, M3_se, cpt2, cpt3, cp1, iw)
save(results, file=paste(directory,"/S4/sim4.Rdata",sep=""))
return(results)

#
}

##################
# Run simulation #
##################
# Note: A subfolder "S4" for simulation 4 is used. Please generate it in your working directory.
#       Some of the results produced are not reported in the paper
set.seed(241280)
sim4 <- mysimulation(runs=2,B=200,M=10,N=1000,directory = getwd())


################
# LOAD RESULTS #
################

load("S4//sim4.Rdata")
m4<- results

###########
# TABLE 1 #
###########

# Coverage Probabilities
m4[[20]]
# Median CI width
m4[[21]]


