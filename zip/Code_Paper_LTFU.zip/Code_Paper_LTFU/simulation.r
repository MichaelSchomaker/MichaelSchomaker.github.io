#################################################################################################################
# Supplementary Material toSchomaker M, Gsponer T, Estill J, Fox M, Boulle A.                                   #
# Non-ignorable loss to follow-up: correcting mortality estimates based on additional outcome ascertainment.    #
# Statistics in Medicine. 2014;33(1):129-42.                                                                    #
#                                                                                                               #
# Simulation from the paper                                                                                     #
#################################################################################################################




############################
# Load necessary libraries #
############################
library(copula) # Copulas to produce multivariate correlations
library(xtable) # save the output as Latex file
library(Amelia) # Multiple Imputation
library(Zelig)  # Combine MI results   - IMPORTANT: install Zelig, version 3.5.1 from CRAN Archive for the below (original) code to work: https://cran.r-project.org/src/contrib/Archive/Zelig/
                # Current use of zelig is discouraged
library(mgcv)   # Generalized Additive Models =GAM
library(BMA)    # Bayesian Model Averaging
library(norm)   # multiple imputation combining
library(boot)   # for inv.logit function
library(survival) # for Cox PH model

set.seed(666)   # to make everything reproducable

### set working directory
setwd("//home//mschomaker//Code_Reproduce//LTFU")

################
## Simulation ##
################
# Simulation "function" whereby number of runs, ascertainment, sample size, number of imputations, and output can be controlled
mysimulation <- function(runs,ascert=1/3,N=1000,m=10,print.to.latex=T,directory='C:/temp/'){

# we will need these matrices later in the simulation...
ptm <- proc.time()
myLTFU <- rep(NA,3)
param <- 5
amountmethods <- 23
Loss_total <- matrix(rep(NA,runs*(amountmethods+4)),ncol=runs,nrow=amountmethods+4) 
Loss_total2 <- matrix(rep(NA,runs*(amountmethods-4)),ncol=runs,nrow=amountmethods-4) 
LTFU_Total <- matrix(rep(NA,runs*(3)),nrow=runs,ncol=3)
wtsum <- matrix(rep(0,117),ncol=13,nrow=9)
wm_btw <- matrix(rep(NA,runs*13),ncol=runs,nrow=13) 
misstable<-matrix(c(rep(0,9)),ncol=3,nrow=3)
b<-1

while(b<runs+1)try({

###################
## Generate data ##
## and setting   ##
###################
n <- N         # total sample size

# Copula with medium correlation, theta=1
mycopula <-  mvdc(claytonCopula(1, dim=5),c("norm","lnorm","weibull","binom","gamma"),list(list(mean=1, sd=1),list(meanlog=1, sdlog=0.5),list(shape=1.75,scale=1.9),list(size=1, prob=0.3),list(shape=0.25,scale=2)))
mycovdata <- rMvdc(n,mycopula)
colnames(mycovdata)<-c("X1","X2","X3","X4","X5")
mycovdata <- as.data.frame(mycovdata)
# Create a MNAR survival setup
mymu <-   0.5 + 0.2*mycovdata$X1 + 0.1*mycovdata$X2 + 0.5*mycovdata$X4
lifetimes <- rexp(n, exp(mymu))          # Lifetime depends on X1, X2 and X4 
censtimes <- rexp(n,12.5)
mymu2 <- 2.5+ 12.5*as.numeric(censtimes > lifetimes) # MNAR: Y|R different for R=r
ltfutimes <- rexp(n,mymu2)
ztimes <- pmin(lifetimes, censtimes, ltfutimes)
#lifetimes <- lifetimes1  - (lifetimes1/rnorm(n,3,0))*as.numeric(ztimes==ltfutimes) 
#ztimes <- pmin(lifetimes, censtimes, ltfutimes)
realtimes <-  pmin(lifetimes, censtimes)
status <- as.numeric(censtimes > lifetimes)

# True parameters
true <- c(0.5,0.2,0.1,0,0.5,0)
true2 <-  c(0.2,0.1,0,0.5,0)   #without baseline hazard 

# Missingness functions for X1, X4, Y

# 1) MAR for X1 and X4
probab  <- 1-(1/(1+(0.02*(mycovdata$X2^3))))
probab2 <- 1-(1/(1+exp(1-2*(mycovdata$X3))))
X1mis <- mycovdata$X1
X4mis <- mycovdata$X4
for(k in 1:n){X1mis[k] <- sample(c(mycovdata$X1[k],NA),1,prob=c(1-probab[k],probab[k]))}
for(k in 1:n){X4mis[k] <- sample(c(mycovdata$X4[k],NA),1,prob=c(1-probab2[k],probab2[k]))}

# 2) MNAR for outcome (Y)
missingindicator <- as.numeric(ztimes==ltfutimes)
timemis   <- ztimes
statusmis <- status
statusmis[missingindicator==1] <- 0

newstatus <- rep(NA,n)
newtime <- rep(NA,n)
newstatus[missingindicator==0] <- status[missingindicator==0]
newtime[missingindicator==0] <- ztimes[missingindicator==0]

# 3) Ascertainment
missingindicator2 <- missingindicator
newn <- length(missingindicator2[missingindicator==1])
probab4 <-  ascert + inv.logit(mycovdata$X2/3.5 -mean(mycovdata$X2/3.5)  + (mycovdata$X4/3.5) -mean((mycovdata$X4/3.5))) -0.5  # Probability of ascertainment
probab4 <- probab4[missingindicator==1]
for(k in 1:newn){
if(probab4[k]<0){probab4[k]=1e-07}    # adjustment if there is a problem, but practically this hardly ever happens...
if(probab4[k]>1){probab4[k]=1}
missingindicator2[missingindicator==1][k] <-  sample(c(0,1),1,prob=c(probab4[k],1-probab4[k]),replace=TRUE)
}
timeasc <- rep(NA,n)
statusasc <- rep(NA,n)
for(k in 1:n){
if(missingindicator2[k]==1){
timeasc[k] <- ztimes[k]
statusasc[k] <- statusmis[k]
}
if(missingindicator2[k]==0){
timeasc[k] <- pmin(lifetimes, censtimes)[k]
statusasc[k] <- status[k]
}
}

complete <-rep(NA,n)
for(i in 1:n){
if(missingindicator[i]==0){complete[i]<-1}
if(missingindicator[i]==1 & missingindicator2[i]==1){complete[i]<-0}
if(missingindicator[i]==1 & missingindicator2[i]==0){complete[i]<-1}
}

# Ascertained data + missing outcomes from unascertained data
timeascmis <- rep(NA,n)
statusascmis <- rep(NA,n)
timeascmis[complete==1] <- timeasc[complete==1]
statusascmis[complete==1] <- statusasc[complete==1]


#### Datasets #####
# Original, true data
original <- cbind(realtimes,status,mycovdata$X1,mycovdata$X2,mycovdata$X3,mycovdata$X4,mycovdata$X5,complete)
colnames(original)<-c("Time","Status","X1","X2","X3","X4","X5","complete")
original <- as.data.frame(original)
# Data with noninformative censoring after MNAR LTFU
LTFU <- cbind(timemis,statusmis,missingindicator,X1mis,mycovdata$X2,mycovdata$X3,X4mis,mycovdata$X5,mycovdata$X1,mycovdata$X4)
colnames(LTFU)<-c("Time","Status","LTFU","X1","X2","X3","X4","X5","X1org","X4org")
LTFU <- as.data.frame(LTFU)
# Data after Ascertainment, partly updated event-status
Asc <- cbind(timeasc,statusasc,missingindicator2,X1mis,mycovdata$X2,mycovdata$X3,X4mis,mycovdata$X5,complete,mycovdata$X1,mycovdata$X4)
colnames(Asc)<-c("Time","Status","LTFU","X1","X2","X3","X4","X5","complete","X1org","X4org")
Asc <- as.data.frame(Asc)
# Data whereby outcome (Time,Event) is treated as missing if a patient is LTFU
Wrong <- cbind(newtime,newstatus,X1mis,mycovdata$X2,mycovdata$X3,X4mis,mycovdata$X5,mycovdata$X1,mycovdata$X4)
colnames(Wrong)<-c("Time","Status","X1","X2","X3","X4","X5","X1org","X4org")
Wrong <- as.data.frame(Wrong)
# Imputation after using ascertained data as suggested by reviewer
AscMI <- cbind(timeascmis,statusascmis,X1mis,mycovdata$X2,mycovdata$X3,X4mis,mycovdata$X5,mycovdata$X1,mycovdata$X4) 
colnames(AscMI)<-c("Time","Status","X1","X2","X3","X4","X5","X1org","X4org")
AscMI <- as.data.frame(AscMI)

##################
### Imputation ###
##################

M = m
## Correct imputation, only for covariates for both 1) normal LTFU data and 2) ascertained data
impdata <- Asc[,-c(3,10,11)]
impdata2 <- LTFU[,-c(3,10,11)]
LTFU_imp <- amelia(impdata,p2s=0,m=M,noms=c("Status","X4"),logs=c(4,5,7))                  # 2
LTFU_imp2 <- amelia(impdata2,p2s=0,m=M,noms=c("Status","X4"),logs=c(4,5,7),incheck=F)      # 1
## Wrong Imputation 1) only for outcome  2) for outcome AND covariates
Wrong_imp <- amelia(Wrong[,-c(8,9)],p2s=0,m=M,noms=c("Status","X4"),logs=c(4,5,7),bounds=matrix(c(1,0,5),ncol=3,nrow=1))       #2
Wrong_imp2 <- amelia(Wrong[,-c(3,6)],p2s=0,m=M,noms=c("Status","X4org"),logs=c(3,4,5),bounds=matrix(c(1,0,5),ncol=3,nrow=1))   #1
# Imputation for 1) outcome and 2) outcome + covariates after including Ascertainment information
AscMI_imp <- amelia(AscMI[,-c(8,9)],p2s=0,m=M,noms=c("Status","X4"),logs=c(4,5,7),bounds=matrix(c(1,0,5),ncol=3,nrow=1))       #2
AscMI_imp2 <- amelia(AscMI[,-c(3,6)],p2s=0,m=M,noms=c("Status","X4org"),logs=c(3,4,5),bounds=matrix(c(1,0,5),ncol=3,nrow=1))   #1


###############################
#### Estimation of weights  ###
###############################

####  1) simple upweighing
lr_crude <- glm(complete~1,family=binomial,data=Asc[missingindicator==1,])
weight_lr_crude <-rep(1,n)
delta_lr_crude <- Asc[missingindicator==1,]$complete
weight_lr_crude[missingindicator==1] <- delta_lr_crude/predict(lr_crude, type="response")+1e-07

## 2) logistic regression

# a) available covariates
lr_ac <- glm(complete~X2+X3+X5,family=binomial,data=Asc[missingindicator==1,])
weight_lr_ac <-rep(1,n)
delta_lr_ac <- Asc[missingindicator==1,]$complete
weight_lr_ac[missingindicator==1] <- delta_lr_ac/predict(lr_ac, type="response")+1e-07

# b) multiple imputation
weight_lr_MI <- rep(NA,n)
weight_lr_MI_M  <- rep(NA,n)
for(i in 1:M){
mydataMI <- LTFU_imp$imputations[[i]]
lr_MI <- glm(complete~X1+X2+X3+X4+X5,family=binomial,data=LTFU_imp$imputations[[i]][missingindicator==1,])
weight_lr_MI_M <-rep(1,n)
delta_lr_MI <- LTFU_imp$imputations[[i]][missingindicator==1,]$complete
weight_lr_MI_M[missingindicator==1] <- delta_lr_MI/predict(lr_MI, type="response")
weight_lr_MI <- cbind(weight_lr_MI,weight_lr_MI_M)
}
weight_lr_MI <- weight_lr_MI[,-1]+1e-07
weight_lr_MIsum <- 1/(apply(1/weight_lr_MI,1,mean))+1e-07

# c) missing category
Asc_miscat <- Asc[,c(1,2,3,5,6,8,9,10,11)]
newX1 <- cut(Asc$X1,5,labels=F)
newX1[is.na(newX1)] <- 6
newX4 <- Asc$X4
newX4[is.na(newX4)] <- 2
Asc_miscat <- cbind(Asc_miscat,newX1,newX4)
lr_mc <- glm(complete~as.factor(newX1)+X2+X3+as.factor(newX4)+X5,family=binomial,data=Asc_miscat[missingindicator==1,])
weight_lr_mc <-rep(1,n)
delta_lr_mc <- Asc_miscat[missingindicator==1,]$complete
weight_lr_mc[missingindicator==1] <- delta_lr_mc/predict(lr_mc, type="response")+1e-07

# d) no missing data 
lr_nm <- glm(complete~X1org+X2+X3+X4org+X5,family=binomial,data=Asc[missingindicator==1,])
weight_lr_nm <-rep(1,n)
delta_lr_nm <- Asc[missingindicator==1,]$complete
weight_lr_nm[missingindicator==1] <- delta_lr_nm/predict(lr_nm, type="response")+1e-07


## 3) generalized additive models

#a) available covariates
nr_ac <- gam(complete~s(X2)+s(X3)+s(X5),family=binomial,data=Asc[missingindicator==1,])
weight_nr_ac <-rep(1,n)
delta_nr_ac <- Asc[missingindicator==1,]$complete
weight_nr_ac[missingindicator==1] <- delta_nr_ac/predict(nr_ac, type="response")+1e-07

#b) multiple imputation
weight_nr_MI <- rep(NA,n)
weight_nr_MI_M  <- rep(NA,n)
for(i in 1:M){
nr_MI <- gam(complete~s(X1)+s(X2)+s(X3)+X4+s(X5),family=binomial,data=LTFU_imp$imputations[[i]][missingindicator==1,])
weight_nr_MI_M <-rep(1,n)
delta_nr_MI <- LTFU_imp$imputations[[i]][missingindicator==1,]$complete
weight_nr_MI_M[missingindicator==1] <- delta_nr_MI/predict(nr_MI, type="response")
weight_nr_MI <- cbind(weight_nr_MI,weight_nr_MI_M)
}
weight_nr_MI <- weight_nr_MI[,-1] +1e-07
weight_nr_MIsum <- 1/(apply(1/weight_nr_MI,1,mean))+1e-07

#c) missing category 
nr_mc <- gam(complete~as.factor(newX1)+s(X2)+s(X3)+as.factor(newX4)+s(X5),family=binomial,data=Asc_miscat[missingindicator==1,])
weight_nr_mc <-rep(1,n)
delta_nr_mc <- Asc_miscat[missingindicator==1,]$complete
weight_nr_mc[missingindicator==1] <- delta_nr_mc/predict(nr_mc, type="response")+1e-07

# d) no missing data 
nr_nm <- gam(complete~s(X1org)+s(X2)+s(X3)+X4org+s(X5),family=binomial,data=Asc_miscat[missingindicator==1,])
weight_nr_nm <-rep(1,n)
delta_nr_nm <- Asc[missingindicator==1,]$complete
weight_nr_nm[missingindicator==1] <- delta_nr_nm/predict(nr_nm, type="response")+1e-07


## 4) Bayesian Model Averaging 

# a) available covariates
bma_ac <- bic.glm(complete~X2+X3+X5,glm.family=binomial,data=Asc[missingindicator==1,])
weight_bma_ac <-rep(1,n)
delta_bma_ac <-   Asc[missingindicator==1,]$complete
mu_bma_ac <-  as.matrix(cbind(c(rep(1,dim(Asc[missingindicator==1,])[1])),((Asc[missingindicator==1,])[,c(5,6,8)])))%*%as.matrix((bma_ac$postmean))
pred_bma_ac <- 1/(1+exp(-mu_bma_ac)) 
weight_bma_ac[missingindicator==1] <- delta_bma_ac/pred_bma_ac+1e-07

# b) multiple imputation
weight_bma_MI <- rep(NA,n)
weight_bma_MI_M  <- rep(NA,n)
for(i in 1:M){
bma_MI <- bic.glm(complete~X1+X2+X3+X4+X5,glm.family=binomial,data=LTFU_imp$imputations[[i]][missingindicator==1,])
weight_bma_MI_M <-rep(1,n)
delta_bma_MI <- LTFU_imp$imputations[[i]][missingindicator==1,]$complete
mu_bma_MI <-  as.matrix(cbind(c(rep(1,dim(LTFU_imp$imputations[[i]])[1])),((LTFU_imp$imputations[[i]])[,c(3:7)])))%*%as.matrix((bma_MI$postmean))
pred_bma_MI <- 1/(1+exp(-mu_bma_MI)) 
weight_bma_MI_M[missingindicator==1] <- delta_bma_MI/(pred_bma_MI[missingindicator==1])
weight_bma_MI <- cbind(weight_bma_MI,weight_bma_MI_M)
}
weight_bma_MI <- weight_bma_MI[,-1]+1e-07
weight_bma_MIsum <- 1/(apply(1/weight_bma_MI,1,mean))+1e-07

# c) missing category
newX1_2 <- rep(0,n)
newX1_2[newX1==2] <- 1
newX1_3 <- rep(0,n)
newX1_3[newX1==3] <- 1
newX1_4 <- rep(0,n)
newX1_4[newX1==4] <- 1
newX1_5 <- rep(0,n)
newX1_5[newX1==5] <- 1
newX1_6 <- rep(0,n)
newX1_6[newX1==6] <- 1
newX4_1 <- rep(0,n)
newX4_1[newX4==1] <- 1
newX4_2 <- rep(0,n)
newX4_2[newX4==2] <- 1
Asc_miscat_extra <- as.data.frame(cbind(Asc_miscat,newX1_2,newX1_3,newX1_4,newX1_5,newX1_6,newX4_1,newX4_2))
bma_mc <- bic.glm(complete~as.factor(newX1)+X2+X3+as.factor(newX4)+X5,glm.family=binomial,data=Asc_miscat[missingindicator==1,])
if(length(bma_mc$postmean)!=11){
bma_mc <- bic.glm(complete~newX1_2+newX1_3+newX1_4+newX1_5+newX1_6+X2+X3+newX4_1+newX4_2+X5,glm.family=binomial,data=Asc_miscat_extra)
print("Note: BMA with `missing categories' was calculated `by hand', no problem...")
}
weight_bma_mc <-rep(1,n)
delta_bma_mc <- Asc_miscat[missingindicator==1,]$complete
mu_bma_mc <-  as.matrix(cbind(c(rep(1,n)),newX1_2,newX1_3,newX1_4,newX1_5,newX1_6,((Asc)[,c(5,6)]),newX4_1,newX4_2,((Asc)[,c(8)])))[missingindicator==1,] %*%as.matrix((bma_mc$postmean))
pred_bma_mc <- 1/(1+exp(-mu_bma_mc)) 
weight_bma_mc[missingindicator==1] <- delta_bma_mc/pred_bma_mc+1e-07

# d) no missing data 
bma_nm <- bic.glm(complete~X1org+X2+X3+X4org+X5,glm.family=binomial,data=Asc[missingindicator==1,])
weight_bma_nm <-rep(1,n)
delta_bma_nm <-   Asc[missingindicator==1,]$complete
mu_bma_nm <-  as.matrix(cbind(c(rep(1,dim(Asc[missingindicator==1,])[1])),((Asc[missingindicator==1,])[,c(10,5,6,11,8)])))%*%as.matrix((bma_nm$postmean))
pred_bma_nm <- 1/(1+exp(-mu_bma_nm)) 
weight_bma_nm[missingindicator==1] <- delta_bma_nm/pred_bma_nm+1e-07

###########################################
### Estimation of Cox Regression Models ###
###########################################

for(k in 1:M){LTFU_imp$imputations[[k]]<-cbind(LTFU_imp$imputations[[k]],weight_lr_MI[,k],weight_nr_MI[,k],weight_bma_MI[,k])
colnames(LTFU_imp$imputations[[k]])[9:11] <- c("weight_lr_MIc","weight_nr_MIc","weight_bma_MIc")
}

# Original data
M_org <- coxph(Surv(Time,Status) ~ X1 + X2 + X3 + X4 + X5, method="breslow", data=original)

# no ascertainment for y + complete X + CC of y 
M_CC0 <- coxph(Surv(Time,Status) ~ X1org + X2 + X3 + X4org + X5, method="breslow", data=Wrong)

# no ascertainment for y + complete cases (X+Y)
M_CC1 <- coxph(Surv(Time,Status) ~ X1 + X2 + X3 + X4 + X5, method="breslow", data=Wrong)

# no ascertainment for y + complete cases (X) + wrong Y
M_CC2 <- coxph(Surv(Time,Status) ~ X1 + X2 + X3 + X4 + X5, method="breslow", data=LTFU)

# no ascertainment for y + known X + wrong Y
M_LF <- coxph(Surv(Time,Status) ~ X1org + X2 + X3 + X4org + X5, method="breslow", data=LTFU)

# no ascertainment for y + but imputation for X
M_MI <- suppressWarnings(zelig(Surv(Time,Status) ~ X1 + X2 + X3 + X4 + X5, model="coxph",cite=F, method="breslow", data=LTFU_imp2$imputations))

# Allover imputation, also for Y, wrong!!
M_MI2 <- suppressWarnings(zelig(Surv(Time,Status) ~ X1 + X2 + X3 + X4 + X5, model="coxph",cite=F, method="breslow", data=Wrong_imp$imputations))

# Imputation for y, no missing values for X
M_MI3 <- suppressWarnings(zelig(Surv(Time,Status) ~ X1org + X2 + X3 + X4org + X5, model="coxph",cite=F, method="breslow", data=Wrong_imp2$imputations))

# Imputation for y, no missing values for X - including ascertained information
M_MI4 <- suppressWarnings(zelig(Surv(Time,Status) ~ X1org + X2 + X3 + X4org + X5, model="coxph",cite=F, method="breslow", data=AscMI_imp2$imputations))

# Imputation for y AND for X - including ascertained information
M_MI5 <- suppressWarnings(zelig(Surv(Time,Status) ~ X1 + X2 + X3 + X4 + X5, model="coxph",cite=F, method="breslow", data=AscMI_imp$imputations))


# ascertainment + no upweighting + imputation
M_A <- suppressWarnings(zelig(Surv(Time,Status) ~ X1 + X2 + X3 + X4 + X5, model="coxph", cite=F, weights=complete+1e-010, method="breslow", data=LTFU_imp$imputations))

# ascertainment + no upweighting + NO imputation
M_A1 <- coxph(Surv(Time,Status) ~ X1org + X2 + X3 + X4org + X5, weights=complete+1e-010, method="breslow", data=Asc)

### ascertainment + upweighting + imputation ###
# crude weights + NO imputation
M_Asc0 <- coxph(Surv(Time,Status) ~ X1org + X2 + X3 + X4org + X5, weights=weight_lr_crude, method="breslow", data=Asc)

# crude weights + imputation
M_Asc <- suppressWarnings(zelig(Surv(Time,Status) ~ X1 + X2 + X3 + X4 + X5, model="coxph", cite=F, weights=weight_lr_crude, method="breslow", data=LTFU_imp$imputations))

# logistic regression weights  + NO imputation
M_Asc41 <- coxph(Surv(Time,Status) ~ X1org + X2 + X3 + X4org + X5, weights=weight_lr_nm, method="breslow", data=Asc)

# logistic regression weights  + imputation
M_Asc11 <- suppressWarnings(zelig(Surv(Time,Status) ~ X1 + X2 + X3 + X4 + X5, model="coxph",cite=F, weights=weight_lr_ac, method="breslow", data=LTFU_imp$imputations))
M21coeff <- rep(list(NA),M)
M21var <- rep(list(NA),M)
for(k in 1:M){
M21 <- coxph(Surv(Time,Status) ~ X1 + X2 + X3 + X4 + X5, weights=LTFU_imp$imputations[[k]]$weight_lr_MIc, method="breslow", data=LTFU_imp$imputations[[k]])
M21coeff[[k]] <- (summary(M21)$coefficients)[,1]
M21var[[k]] <- (summary(M21)$coefficients)[,3]
}
M_Asc21 <- mi.inference(M21coeff, M21var, confidence=0.95)
M_Asc31 <- suppressWarnings(zelig(Surv(Time,Status) ~ X1 + X2 + X3 + X4 + X5, model="coxph",cite=F, weights=weight_lr_mc, method="breslow", data=LTFU_imp$imputations))

# nonparametric regression weights  + imputation
M_Asc12 <- suppressWarnings(zelig(Surv(Time,Status) ~ X1 + X2 + X3 + X4 + X5, model="coxph",cite=F, weights=weight_nr_ac, method="breslow", data=LTFU_imp$imputations))
M22coeff <- rep(list(NA),M)
M22var <- rep(list(NA),M)
for(k in 1:M){
M22 <- coxph(Surv(Time,Status) ~ X1 + X2 + X3 + X4 + X5, weights=LTFU_imp$imputations[[k]]$weight_nr_MIc, method="breslow", data=LTFU_imp$imputations[[k]])
M22coeff[[k]] <- (summary(M22)$coefficients)[,1]
M22var[[k]] <- (summary(M22)$coefficients)[,3]
}
M_Asc22 <- mi.inference(M22coeff, M22var, confidence=0.95)
M_Asc32 <- suppressWarnings(zelig(Surv(Time,Status) ~ X1 + X2 + X3 + X4 + X5, model="coxph",cite=F, weights=weight_nr_mc, method="breslow", data=LTFU_imp$imputations))

# nonparametric regression + NO imputation
M_Asc42 <- coxph(Surv(Time,Status) ~ X1org + X2 + X3 + X4org + X5, weights=weight_nr_nm, method="breslow", data=Asc)


# BMA weights + imputation
M_Asc13 <- suppressWarnings(zelig(Surv(Time,Status) ~ X1 + X2 + X3 + X4 + X5, model="coxph",cite=F, weights=weight_bma_ac, method="breslow", data=LTFU_imp$imputations))
M23coeff <- rep(list(NA),M)
M23var <- rep(list(NA),M)
for(k in 1:M){
M23 <- coxph(Surv(Time,Status) ~ X1 + X2 + X3 + X4 + X5, weights=LTFU_imp$imputations[[k]]$weight_bma_MIc, method="breslow", data=LTFU_imp$imputations[[k]])
M23coeff[[k]] <- (summary(M23)$coefficients)[,1]
M23var[[k]] <- (summary(M23)$coefficients)[,3]
}
M_Asc23 <- mi.inference(M23coeff, M23var, confidence=0.95)
M_Asc33 <- suppressWarnings(zelig(Surv(Time,Status) ~ X1 + X2 + X3 + X4 + X5, model="coxph",cite=F, weights=weight_bma_mc, method="breslow", data=LTFU_imp$imputations))

# BMA weights + NO imputation
M_Asc43 <- coxph(Surv(Time,Status) ~ X1org + X2 + X3 + X4org + X5, weights=weight_bma_nm, method="breslow", data=Asc)


######################
##### RESULTS 1 ######
######################

### Evaluation of missingness ###
myLTFU <- rbind(c(mean(missingindicator==1),mean(missingindicator2[missingindicator==1]==0), mean(missingindicator2==1)))
myLTFU <- as.matrix(myLTFU)
colnames(myLTFU) <- c("LTFU","% traced","Missing after Linkage")
LTFU_Total[b,]<- myLTFU

LTFUTable1 <- table(missingindicator,status)
rsum <- apply(LTFUTable1,1,sum)
csum <- apply(LTFUTable1,2,sum)
tabsum <- cbind(LTFUTable1,rsum)
tabsum2 <- rbind(tabsum,c(csum,sum(table(missingindicator,status))))
tabsum3 <- (tabsum2/ sum(table(missingindicator,status)))
misstable <- misstable+tabsum3

### Evaluation of weights ######
myweightsmatrix <- cbind(weight_lr_crude,weight_lr_nm,weight_lr_ac,weight_lr_MIsum,weight_lr_mc,weight_nr_nm,weight_nr_ac, weight_nr_MIsum, weight_nr_mc,weight_bma_nm, weight_bma_ac, weight_bma_MIsum, weight_bma_mc)
wt_summ <- summary(myweightsmatrix)
wm <- myweightsmatrix[missingindicator==1 & missingindicator2==0,]
q25 <- function(x){quantile(x,probs=0.25)}
q75 <- function(x){quantile(x,probs=0.75)}
wmmin <- apply(wm,2,min)
wm25 <-  apply(wm,2,q25)
wm50 <-  apply(wm,2,median)
wmmean <-  apply(wm,2,mean)
wm75 <-  apply(wm,2,q75)
wmmax <- apply(wm,2,max)
wmsd <- apply(wm,2,var)
wtrue <- ((missingindicator2[missingindicator==1]==0)/probab4)[((missingindicator2[missingindicator==1]==0)/probab4)!=0]
wmMAD <- apply(abs((wm-wtrue)-median((wm-wtrue))),2,median)
wmMSE <- apply((wm-wtrue)^2,2,mean)
wmMED <- apply((wm-wtrue)^2,2,median)
wtsummary <- rbind(wmmin,wm25,wm50,wm75,wmmax,wmsd,wmmean,wmMSE,wmMAD)
rownames(wtsummary) <- c("min","Q25","Q50","Q75","Max","Var","MSE","MAD","MED")
colnames(wtsummary) <- c("crude","LR","LR(AC)","LR(MI)","LR(MC)","NR","NR(AC)","NR(MI)","NR(MC)","BMA","BMA(AC)","BMA(MI)","BMA(MC)")
wtsum <- wtsum+wtsummary
wm_btw[,b] <- wmmean

######################
##### RESULTS 2 ######
######################

# Estimates Summary   
myestimates <- matrix(NA,ncol=param,nrow=amountmethods+4)
colnames(myestimates) <- c(paste("beta",1:(param),sep=""))
myestimates[1,]<-true2
          
myestimates[2,] <- coefficients(M_org)
myestimates[3,] <- coefficients(M_CC0)
myestimates[4,] <- coefficients(M_LF)  
myestimates[5,] <- coefficients(summary(M_MI3))[,1] 
myestimates[6,] <- coefficients(summary(M_MI4))[,1] 
myestimates[7,] <- coefficients(M_A1)  
myestimates[8,] <- coefficients(M_Asc0) 
myestimates[9,] <- coefficients(M_Asc41)
myestimates[10,] <- coefficients(M_Asc42)
myestimates[11,]<- coefficients(M_Asc43)         
myestimates[12,]<- coefficients(M_CC1)
myestimates[13,]<- coefficients(M_CC2)
myestimates[14,]<- coefficients(summary(M_MI))[,1]
myestimates[15,]<- coefficients(summary(M_MI2))[,1]
myestimates[16,] <- coefficients(summary(M_MI5))[,1] 
myestimates[17,]<- coefficients(summary(M_A))[,1]
myestimates[18,]<- coefficients(summary(M_Asc))[,1]
myestimates[19,] <- coefficients(summary(M_Asc11))[,1]
myestimates[20,] <- M_Asc21$est
myestimates[21,]<- coefficients(summary(M_Asc31))[,1]
myestimates[22,]<- coefficients(summary(M_Asc12))[,1]
myestimates[23,]<- M_Asc22$est
myestimates[24,]<- coefficients(summary(M_Asc32))[,1]
myestimates[25,]<- coefficients(summary(M_Asc13))[,1]
myestimates[26,]<- M_Asc23$est
myestimates[27,]<- coefficients(summary(M_Asc33))[,1]
rownames(myestimates) <- c("Truth","Org","CC(Y)","LTFU","MI","MI+(new)","Asc/nw","IPW(crude)","IPW(LR)","IPW(NR)","IPW(BMA)","CC(XY)","CC(X)","MI(!Y)","MI(Y)","MI(Y)+(new)","MI+Asc/nw","MI+IPW(crude)","MI+IPW(LR,AC)","MI+IPW(LR,MI)","MI+IPW(LR,MC)","MI+IPW(NR,AC)","MI+IPW(NR,MI)","MI+IPW(NR,MC)","MI+IPW(BMA,AC)","MI+IPW(BMA,MI)","MI+IPW(BMA,MC)")
round(myestimates, digits=2)


### MSE ###
Loss <- c(rep(NA,amountmethods+4))
for(i in 1:length(Loss)){Loss[i]<-sum((myestimates[i,]-myestimates[1,])^2)}
Loss <- round(Loss,digits=4)
Loss <- matrix(Loss,ncol=1,nrow=amountmethods+4)
colnames(Loss)<-c("MSE")
rownames(Loss)<-c("Truth","Org","CC(Y)","LTFU","MI","MI+(new)","Asc/nw","IPW(crude)","IPW(LR)","IPW(NR)","IPW(BMA)","CC(XY)","CC(X)","MI(!Y)","MI(Y)","MI(Y)+(new)","MI+Asc/nw","MI+IPW(crude)","MI+IPW(LR,AC)","MI+IPW(LR,MI)","MI+IPW(LR,MC)","MI+IPW(NR,AC)","MI+IPW(NR,MI)","MI+IPW(NR,MC)","MI+IPW(BMA,AC)","MI+IPW(BMA,MI)","MI+IPW(BMA,MC)")
Loss_total[,b] <- Loss

###################
###   Results 3 ###
###################

## Estimated survival at T50
medsurv <- median(lifetimes)
Orgsum <- summary(survfit(Surv(Time,Status) ~ 1, data=original))
Orgsurv<-((Orgsum$surv[abs((Orgsum$time-medsurv))==min(abs((Orgsum$time-medsurv)))])-0.5)^2
CC1sum <- summary(survfit(Surv(Time,Status) ~ 1, data=Wrong))
CC1surv<-((CC1sum$surv[abs((CC1sum$time-medsurv))==min(abs((CC1sum$time-medsurv)))])-0.5)^2
LTFUsum <- summary(survfit(Surv(Time,Status) ~ 1, data=LTFU))
LTFUsurv<-((LTFUsum$surv[abs((LTFUsum$time-medsurv))==min(abs((LTFUsum$time-medsurv)))])-0.5)^2
mysurv2<-0
for(i in 1:M){
mysum <- summary(survfit(Surv(Time,Status) ~ 1, data=Wrong_imp$imputations[[i]]))
mysurv1 <- (mysum$surv[abs((mysum$time-medsurv))==min(abs((mysum$time-medsurv)))])
mysurv2 <- mysurv1+mysurv2
}
mysurv2<-mysurv2/M
MIsurv<-(mysurv2-0.5)^2
mysurv2_new<-0
for(i in 1:M){
mysum_new <- summary(survfit(Surv(Time,Status) ~ 1, data=AscMI_imp$imputations[[i]]))
mysurv1_new <- (mysum_new$surv[abs((mysum_new$time-medsurv))==min(abs((mysum_new$time-medsurv)))])
mysurv2_new <- mysurv1_new+mysurv2_new
}
mysurv2_new<-mysurv2_new/M
MIsurv_new<-(mysurv2_new-0.5)^2
Asum <- summary(survfit(Surv(Time,Status) ~ 1, weights=complete+1e-10, data=Asc))
Asurv<-((Asum$surv[abs((Asum$time-medsurv))==min(abs((Asum$time-medsurv)))])-0.5)^2
Ascsum <- summary(survfit(Surv(Time,Status) ~ 1, weights=weight_lr_crude, data=Asc))
Ascsurv<-((Ascsum$surv[abs((Ascsum$time-medsurv))==min(abs((Ascsum$time-medsurv)))])-0.5)^2
Ascsum01 <- summary(survfit(Surv(Time,Status) ~ 1, weights=weight_lr_nm, data=Asc))
Ascsurv01<-((Ascsum01$surv[abs((Ascsum01$time-medsurv))==min(abs((Ascsum01$time-medsurv)))])-0.5)^2
Ascsum11 <- summary(survfit(Surv(Time,Status) ~ 1, weights=weight_lr_ac, data=Asc))
Ascsurv11<-((Ascsum11$surv[abs((Ascsum11$time-medsurv))==min(abs((Ascsum11$time-medsurv)))])-0.5)^2
mysurv21<-0
for(i in 1:M){
mysum21 <- summary(survfit(Surv(Time,Status) ~ 1, weights=weight_lr_MI[,i], data=Asc))
mysurv211 <- (mysum21$surv[abs((mysum21$time-medsurv))==min(abs((mysum21$time-medsurv)))])
mysurv21 <- mysurv211+mysurv21
}
mysurv21<-mysurv21/M
Ascsurv21<-(mysurv21-0.5)^2
Ascsum31 <- summary(survfit(Surv(Time,Status) ~ 1, weights=weight_lr_mc, data=Asc))
Ascsurv31<-((Ascsum31$surv[abs((Ascsum31$time-medsurv))==min(abs((Ascsum31$time-medsurv)))])-0.5)^2
Ascsum02 <- summary(survfit(Surv(Time,Status) ~ 1, weights=weight_nr_nm, data=Asc))
Ascsurv02<-((Ascsum02$surv[abs((Ascsum02$time-medsurv))==min(abs((Ascsum02$time-medsurv)))])-0.5)^2
Ascsum12 <- summary(survfit(Surv(Time,Status) ~ 1, weights=weight_nr_ac, data=Asc))
Ascsurv12<-((Ascsum12$surv[abs((Ascsum12$time-medsurv))==min(abs((Ascsum12$time-medsurv)))])-0.5)^2
mysurv22<-0
for(i in 1:M){
mysum22 <- summary(survfit(Surv(Time,Status) ~ 1, weights=weight_nr_MI[,i], data=Asc))
mysurv221 <- (mysum22$surv[abs((mysum22$time-medsurv))==min(abs((mysum22$time-medsurv)))])
mysurv22 <- mysurv221+mysurv22
}
mysurv22<-mysurv22/M
Ascsurv22<-(mysurv22-0.5)^2
Ascsum32 <- summary(survfit(Surv(Time,Status) ~ 1, weights=weight_nr_mc, data=Asc))
Ascsurv32<-((Ascsum32$surv[abs((Ascsum32$time-medsurv))==min(abs((Ascsum32$time-medsurv)))])-0.5)^2
Ascsum03 <- summary(survfit(Surv(Time,Status) ~ 1, weights=weight_bma_nm, data=Asc))
Ascsurv03<-((Ascsum03$surv[abs((Ascsum03$time-medsurv))==min(abs((Ascsum03$time-medsurv)))])-0.5)^2
Ascsum13 <- summary(survfit(Surv(Time,Status) ~ 1, weights=weight_bma_ac, data=Asc))
Ascsurv13<-((Ascsum13$surv[abs((Ascsum13$time-medsurv))==min(abs((Ascsum13$time-medsurv)))])-0.5)^2
mysurv23<-0
for(i in 1:M){
mysum23 <- summary(survfit(Surv(Time,Status) ~ 1, weights=weight_bma_MI[,i], data=Asc))
mysurv231 <- (mysum23$surv[abs((mysum23$time-medsurv))==min(abs((mysum23$time-medsurv)))])
mysurv23 <- mysurv231+mysurv23
}
mysurv23<-mysurv23/M
Ascsurv23<-(mysurv23-0.5)^2
Ascsum33 <- summary(survfit(Surv(Time,Status) ~ 1, weights=weight_bma_mc, data=Asc))
Ascsurv33<-((Ascsum33$surv[abs((Ascsum33$time-medsurv))==min(abs((Ascsum33$time-medsurv)))])-0.5)^2

# Estimated Survival Loss (Squared Error compared to truth)
myestimates2 <- matrix(NA,ncol=1,nrow=amountmethods-4)
myestimates2[1,]<- Orgsurv
myestimates2[2,]<- CC1surv
myestimates2[3,]<- LTFUsurv
myestimates2[4,]<- MIsurv
myestimates2[5,]<- MIsurv_new
myestimates2[6,]<- Asurv
myestimates2[7,]<- Ascsurv
myestimates2[8,]<- Ascsurv01
myestimates2[9,]<- Ascsurv11
myestimates2[10,]<- Ascsurv21
myestimates2[11,]<- Ascsurv31
myestimates2[12,]<- Ascsurv02
myestimates2[13,]<- Ascsurv12
myestimates2[14,]<- Ascsurv22
myestimates2[15,]<- Ascsurv32
myestimates2[16,]<- Ascsurv03
myestimates2[17,]<- Ascsurv13
myestimates2[18,]<- Ascsurv23
myestimates2[19,]<- Ascsurv33
myestimates2 <- 100*myestimates2
myestimates2 <- round(myestimates2,digits=3)
Loss_total2[,b] <- myestimates2
rownames(Loss_total2) <-  c("Org","CC","LTFU","MI(Y)","MI(Y)-new","MI+Asc/nw","IPW(crude)","IPW(LR)","IPW(LR,AC)","IPW(LR,MI)","IPW(LR,MC)","IPW(NR)","IPW(NR,AC)","IPW(NR,MI)","IPW(NR,MC)","IPW(BMA)","IPW(BMA,AC)","IPW(BMA,MI)","IPW(BMA,MC)")



###
myrun <- paste("This was simulation run no.", b)
print(myrun)
###
b<-b+1


})

######################
### FINAL RESULTS ####
######################

### Averaged MSE for beta/Squared Error Loss b1-b5
MSE_final_est   <- apply(Loss_total,1,mean)
MSE_final_se   <- apply(Loss_total,1,sd)
MSE_final   <- matrix(cbind(MSE_final_est,MSE_final_se),ncol =2, nrow=amountmethods+4)
MSE_final <- MSE_final[-1,]
MSE_final   <- matrix(c(MSE_final),ncol =2, nrow=amountmethods+3)
colnames(MSE_final) <- c("MSE", "(SE)")
rownames(MSE_final) <-c("Org","CC(Y)","LTFU","MI","MI+(new)","Asc/nw","IPW(crude)","IPW(LR)","IPW(NR)","IPW(BMA)","CC(XY)","CC(X)","MI(!Y)","MI(Y)","MI(Y)+(new)","MI+Asc/nw","MI+IPW(crude)","MI+IPW(LR,AC)","MI+IPW(LR,MI)","MI+IPW(LR,MC)","MI+IPW(NR,AC)","MI+IPW(NR,MI)","MI+IPW(NR,MC)","MI+IPW(BMA,AC)","MI+IPW(BMA,MI)","MI+IPW(BMA,MC)")
MSE_final <- round(MSE_final,digits=4)

## Suqared Loss for Survival Prediction
Surv_final_est   <- apply(Loss_total2,1,mean)
Surv_final_se   <- apply(Loss_total2,1,sd)
Surv_final   <- matrix(cbind(Surv_final_est,Surv_final_se),ncol =2, nrow=amountmethods-4)
colnames(Surv_final) <- c("Surv. Loss (x10^2)", "(SE)")
rownames(Surv_final) <-c("Org","CC","LTFU","MI(Y)","MI(Y)-new","MI+Asc/nw","IPW(crude)","IPW(LR)","IPW(LR,AC)","IPW(LR,MI)","IPW(LR,MC)","IPW(NR)","IPW(NR,AC)","IPW(NR,MI)","IPW(NR,MC)","IPW(BMA)","IPW(BMA,AC)","IPW(BMA,MI)","IPW(BMA,MC)")
Surv_final <- round(Surv_final,digits=3)


### LTFU ###
LTFU_final <- as.matrix(round(apply(LTFU_Total,2,mean),digits=2))
rownames(LTFU_final) <- c("LTFU","% tracked","Missing after Linkage")

LTFU2_final <- as.matrix(misstable/runs)
pd <- LTFU2_final[,2]/LTFU2_final[,3]
LTFU2_final <- cbind(LTFU2_final,pd)
rownames(LTFU2_final) <- c("non-missing","missing","Sum")
colnames(LTFU2_final) <- c("alive","dead","Sum","%dead")

## Weights Summary ##
wt_final <- round(wtsum/runs,digits=2)
wt_within <- wt_final[6,]
wt_between <- (apply(((t(wm_btw) - wt_final[7,])^2),2,sum))/runs
wt_sd <- sqrt(wt_within+wt_between)  # Variance based on within and between component
wtfinal <- rbind(wt_final[1:5,],wt_sd,wt_final[7:9,])
rownames(wtfinal)[6] <- c("s.e.")   

### SAVE the following results
myascert <- 100*round(ascert,digits=2)
directory_tex <-  paste(directory,"/",myascert,"_",N,".tex",sep="")
directory_R <-  paste(directory,"/",myascert,"_",N,".Rdata",sep="")
allresults<-list(MSE_final,Surv_final,LTFU_final,LTFU2_final,wtfinal)
save(allresults,file=directory_R)

if(print.to.latex==T){   # Latex Files
mytable1 <- xtable(LTFU_final, digits=2, caption='Missingness percentages')
mytable2 <- xtable(wtfinal, digits=2, caption='IP weights properties')
mytable3 <- xtable(MSE_final, digits=3, caption='Mean Squared Error in the Cox model for the different strategies')
mytable4 <- xtable(LTFU2_final, digits=2, caption='Average death proportions for (non-)missing population')
mytable5 <- xtable(Surv_final, digits=2, caption='Average squared loss for predicted Kaplan Meier survival at median-survivaltime')
print(mytable1, file=directory_tex, table.placement="h")
print(mytable4, file=directory_tex,append=T, table.placement="h")
print(mytable5, file=directory_tex,append=T, table.placement="h")
print(mytable3, file=directory_tex,append=T, table.placement="h",hline.after=c(-1,0,1,10,26))
print(mytable2, file=directory_tex,append=T, table.placement="h",floating.environment="sidewaystable")
}

# How long did it take?
ptm2 <-  proc.time()
simulationsdauer <- ptm2-ptm
simulationsdauer <- (simulationsdauer/60)/60
simulationsdauer <- round(simulationsdauer[1], digits=2)
finaltime <- paste("The simulation time was", simulationsdauer, "hour(s)")
print(finaltime)


return(list(LTFU2_final,LTFU_final,Surv_final,MSE_final,wtfinal))
# end
}


### RUN IMULATIONS FROM PAPER ###
ptmfin <- proc.time()
mysimulation(10, N=1000, ascert=0.1, directory=getwd()) 
mysimulation(10, N=1000, ascert=0.2, directory=getwd()) 
mysimulation(10, N=1000, ascert=0.3, directory=getwd())
mysimulation(10, N=1000, ascert=0.4, directory=getwd())
mysimulation(10, N=1000, ascert=0.5, directory=getwd())
mysimulation(10, N=1000, ascert=0.6, directory=getwd())
mysimulation(10, N=1000, ascert=0.7, directory=getwd())
mysimulation(10, N=1000, ascert=0.8, directory=getwd())
mysimulation(10, N=1000, ascert=0.9, directory=getwd())
ptm2fin <-  proc.time()
simulationsdauer <- ptm2fin-ptmfin
simulationsdauer <- (simulationsdauer/60)/60
simulationsdauer <- round(simulationsdauer[1], digits=2)
finaltime <- paste("The simulation time for all simulations was finally", simulationsdauer, "hour(s)")
print(finaltime)



#########################################################
## Produce Results from Paper and Additional Summaries ##
#########################################################

# Figure 2a
Survsummary <- matrix(rep(NA,56),nrow=8,ncol=7)
load(paste0(getwd(),"/10_1000.Rdata"))
Survsummary[,1] <- allresults[[2]][c(2:8,16),1]
load(paste0(getwd(),"/20_1000.Rdata"))
Survsummary[,2] <- allresults[[2]][c(2:8,16),1]
load(paste0(getwd(),"/30_1000.Rdata"))
Survsummary[,3] <- allresults[[2]][c(2:8,16),1]
load(paste0(getwd(),"/40_1000.Rdata"))
Survsummary[,4] <- allresults[[2]][c(2:8,16),1]
load(paste0(getwd(),"/50_1000.Rdata"))
Survsummary[,5] <- allresults[[2]][c(2:8,16),1]
load(paste0(getwd(),"/60_1000.Rdata"))
Survsummary[,6] <- allresults[[2]][c(2:8,16),1]
load(paste0(getwd(),"/70_1000.Rdata"))
Survsummary[,7] <- allresults[[2]][c(2:8,16),1]
rownames(Survsummary) <-   names(allresults[[2]][c(2:8,16),1])
asc <- c(1:7)

pdf(file=paste0(getwd(),"/Figure2a.pdf"), width=7)
plot(0.01 , ylab="Survival Loss" , xlab = "Ascertainment (%)", type = "n" , axes=F, xlim=c(1,7) , ylim=c(0.10,8), log="y")
lines(asc,Survsummary[1,],col="blue")
lines(asc,Survsummary[2,],col="red")
lines(asc,Survsummary[3,],col="green")
lines(asc,Survsummary[4,],col="green",lty=2)
lines(asc,Survsummary[6,],col="black",lty=2)
lines(asc,Survsummary[7,],col="black",lty=3)
lines(asc,Survsummary[8,],col="black",lty=4)
axis(1,at=asc,labels=c("10%","20%","30%","40%","50%","60%","70%"))
axis(2,at=c(0.10,1,2,4,8), las=1)
legend("bottomleft",bty="n",col=c("red","blue","green","green","black","black","black"),legend=c("NIC","CC","MI","MI (asc.)","IPW (asc.,cw)","IPW (asc.,lw)","IPW (asc.,maw)"), lty=c(1,1,1,2,2,3,4), lwd=1.5, cex=1.25)
dev.off()


# Figure 2b
MSEsummary <- matrix(rep(NA,64),nrow=8,ncol=8)
load(paste0(getwd(),"/10_1000.Rdata"))
MSEsummary[,1] <- allresults[[1]][c(2:8,10),1]
load(paste0(getwd(),"/20_1000.Rdata"))
MSEsummary[,2] <-  allresults[[1]][c(2:8,10),1]
load(paste0(getwd(),"/30_1000.Rdata"))
MSEsummary[,3] <-  allresults[[1]][c(2:8,10),1]
load(paste0(getwd(),"/40_1000.Rdata"))
MSEsummary[,4] <-  allresults[[1]][c(2:8,10),1]
load(paste0(getwd(),"/50_1000.Rdata"))
MSEsummary[,5] <-  allresults[[1]][c(2:8,10),1]
load(paste0(getwd(),"/60_1000.Rdata"))
MSEsummary[,6] <-  allresults[[1]][c(2:8,10),1]
load(paste0(getwd(),"/70_1000.Rdata"))
MSEsummary[,7] <-  allresults[[1]][c(2:8,10),1]
load(paste0(getwd(),"/80_1000.Rdata"))
MSEsummary[,8] <-  allresults[[1]][c(2:8,10),1]
rownames(MSEsummary) <-   names( allresults[[1]][c(2:8,10),1])



asc <- c(2:8)
pdf(file=paste0(getwd(),"/Figure2b.pdf"), width=7)
plot(0.01 , ylab="Loss ML in Cox model" , xlab = "Ascertainment (%)", type = "n" , axes=F, xlim=c(2,8) , ylim=c(0.025,0.125))
lines(asc,MSEsummary[1,2:8],col="blue")
lines(asc,MSEsummary[2,2:8],col="red")
lines(asc,MSEsummary[3,2:8],col="green")
lines(asc,MSEsummary[4,2:8],col="green",lty=2)
lines(asc,MSEsummary[6,2:8],col="black",lty=2)
lines(asc,MSEsummary[7,2:8],col="black",lty=3)
lines(asc,MSEsummary[8,2:8],col="black",lty=4)
axis(1,at=asc,labels=c("20%","30%","40%","50%","60%","70%","80%"))
axis(2,at=c(seq(0.025,0.125,0.025)), las=1)
legend("bottomleft",bty="n",ncol=2,col=c("red","blue","green","green","black","black","black"),legend=c("NIC","CC","MI","MI (asc.)","IPW (asc.,cw)","IPW (asc.,lw)","IPW (asc.,maw)"), lty=c(1,1,1,2,2,3,4), lwd=1.5, cex=1.25)
dev.off()

#############
### TABLE ###
#############

# Table 2
Table2 <- matrix(rep(NA,42),nrow=6,ncol=7)
load(paste0(getwd(),"/20_1000.Rdata"))
Table2[1,]<- allresults[[2]][c(9,10,17,18,3,2,4),1]
Table2[2,]<- allresults[[1]][c(17,18,23,24,12,10,13),1]
Table2[3,c(1:4)] <- allresults[[5]][9,c(4,5,12,13)]
load(paste0(getwd(),"/50_1000.Rdata"))
Table2[4,]<- allresults[[2]][c(9,10,17,18,3,2,4),1]
Table2[5,]<- allresults[[1]][c(17,18,23,24,12,10,13),1]
Table2[6,c(1:4)] <- allresults[[5]][9,c(4,5,12,13)]
colnames(Table2) <- c("LR(MI)","LR(MC)","BMA(MI)", "BMA(MC)","NC","CC","MI")
rownames(Table2) <- c("SL","MSE(b)","MSE(w)","SL ","MSE(b) ","MSE(w) ")
Table2out <- xtable(Table2,digits=4,caption='Performance of the different strategies with missing covariate data')
print(Table2out, file=paste0(getwd(),"/Table2.tex"), table.placement="h")


