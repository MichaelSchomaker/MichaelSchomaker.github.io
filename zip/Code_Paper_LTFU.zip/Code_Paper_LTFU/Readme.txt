Supplementary Material to Schomaker M, Gsponer T, Estill J, Fox M, Boulle A. 
Non-ignorable loss to follow-up: correcting mortality estimates based on additional outcome ascertainment. 
Statistics in Medicine. 2014;33(1):129-42.

This folder contains:
- one .r file with the simulations
- one .tar.gz file with an old version of the R-package Zelig

The simulation code will only work if this specific version of "Zelig" is installed
Results will be saved automatically in the working directory (which can be changed at the top of the .r file)