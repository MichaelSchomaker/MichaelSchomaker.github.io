################################################################################
# Screening algorithm 1: based on Cramer's V                                   #
################################################################################

screen.cramersv_base <- function(Y, X, nscreen = 4, num_cat = 10, verbose = T, ...) {
  if(verbose==T){cat("screen.cramersv for", nscreen, "variables; ")}
  start_time <- Sys.time()
  SuperLearner:::.SL.require("vcd")
  #
  if (ncol(X) > nscreen) {
    dat <- cbind(Y, X)
    contin_var <- apply(dat, 2, function(var) length(unique(var)) > num_cat)
    make_categ <- function(var) {
      num_qu <- length(unique(quantile(var, prob = seq(0, 1, 0.2))))
      if(num_qu >2){ret<-cut(var, unique(quantile(var, prob = seq(0, 1, 0.2))), include.lowest = T)}
      if(num_qu<=2){ret<-cut(var, c(-Inf,unique(quantile(var, prob = seq(0, 1, 0.2))),Inf), include.lowest = T)}
      ret
    }
    if (any(contin_var)) {
      dat[, contin_var] <- apply(dat[, contin_var, drop = FALSE], 2, make_categ)
    }
    calc_cram_v <- function(x_var, y_var) vcd::assocstats(table(y_var, x_var))$cramer
    cramers_v <- apply(dat[, !colnames(dat) %in% "Y"], 2, calc_cram_v, y_var = dat[, "Y"])
    if(verbose==T){cat("screened:",colnames(X)[unname(rank(-cramers_v) <= nscreen)],"\n",sep=" ");
      cat("sample size:",dim(X)[1],"; "); 
    }
    whichVariable <- unname(rank(-cramers_v) <= nscreen)
  }else{
    if(verbose==T){cat("screened all", ncol(X), "variables \n")}
    whichVariable <- rep(TRUE, ncol(X))}
  end_time <- Sys.time()
  if(verbose==T){cat("time:", round(difftime(end_time, start_time, units="mins"), digits=4), "mins \n")}
  return(whichVariable)
}


# generic function to create screening algorithms

make.cramer <- function(nscreen=4,verbose=T){
  
tuneGrid <- expand.grid(nscreen = nscreen)

for (q in seq(nrow(tuneGrid))) {
  eval(parse(text = paste0("screen.cramersv_", tuneGrid[q, 1],
    "<- function(..., nscreen = ", tuneGrid[q, 1], ", verbose = ", verbose, ")
                           {screen.cramersv_base(..., nscreen = nscreen, verbose=verbose)}"
  )), envir = .GlobalEnv)
  cat(paste0("You can now make use of the following screening algorithm: ", "screen.cramersv_", tuneGrid[q, 1], "\n"))
}  

}

# explanation of screening algorithm
tell.screen.cramer <- function(){
  cat(paste("Variables are screened by calculating the association measure `Cramer's V' between Y and all X \n",
            "Cramer's V is a standardized chi^2 statistic \n",
            "To calculate it, all continuous variables are categorized into 5 categories, using the variable's quintiles \n",
            "Variables with more than 10 unique values are considered continuous \n",
            " The `nscreen' variables with the highest association are selected"))
}

################################################################################
# Screening algorithm 2: Lasso and Elastic Net                                 #
################################################################################

library(glmnet)
screen.glmnet_base <- function(Y, X, family, alpha = 1, verbose=T,
                           nfolds = 10, nlambda = 200, nscreen=2, ...){
  if(verbose==T){cat("screen.glmnet with alpha=", alpha, " and ", nfolds, " fold CV \n", sep="")}
  start_time <- Sys.time()
  SuperLearner:::.SL.require("glmnet")
  # relevant for column names but shouldn't be a matrix anyways
  X <- as.data.frame(X)
  # chose family dependent upon response
  Y <- as.vector(as.matrix(Y))
  if (all(Y == 0 | Y == 1)) {
    family$family <- "binomial"
  } else {
    family$family <- "gaussian"
  }
  saveY<-Y;saveX<-X
  # needed for var names to select from levels of factors later on
  if (ncol(X) > 26 * 27) stop("Find further column names for X!")
  let <- c(letters, sort(do.call("paste0", expand.grid(letters, letters[1:26]))))
  names(X) <- let[1:ncol(X)]
  # factors are coded as dummies which are standardized in cv.glmnet()
  # intercept is not in model.matrix() because its already in cv.glmnet()
  is_fact_var <- sapply(X, is.factor)
  X <- try(model.matrix(~ -1 + ., data = X), silent = FALSE)
  successfulfit <- FALSE
  fitCV <- try(glmnet::cv.glmnet(
    x = X, y = Y, lambda = NULL, type.measure = "deviance",
    nfolds = nfolds, family = family$family, alpha = alpha,
    nlambda = nlambda, keep = T
  ), silent = TRUE)
  # if no variable was selected, penalization might have been too strong, try log(lambda)
  if (all(fitCV$nzero == 0) | all(is.na(fitCV$nzero))) {
    fitCV <- try(glmnet::cv.glmnet(
      x = X, y = Y, lambda = log(fitCV$glmnet.fit$lambda + 1), type.measure = "deviance",
      nfolds = nfolds, family = family$family, alpha = alpha, keep = T
    ), silent = TRUE)
  }
  if(class(fitCV)=="try-error"){successfulfit <- FALSE}else{successfulfit <- TRUE}
  whichVariable <- NULL
  if(successfulfit==TRUE){
    coefs <- coef(fitCV$glmnet.fit, s = fitCV$lambda.min)
    if(all(coefs[-1]==0)){whichVariable<-screen.cramersv_base(Y=saveY,X=saveX,nscreen=nscreen)
    if(verbose==T){cat("Lasso screened away all variables and screening was thus based on Cramer's V \n")}}else{  
      var_nms <- coefs@Dimnames[[1]]
      # Instead of Group Lasso:
      # If any level of a dummy coded factor is selected, the whole factor is selected
      if (any(is_fact_var)) {
        nms_fac <- names(which(is_fact_var))
        is_selected <- coefs[-1] != 0 # drop intercept
        # model.matrix adds numbers to dummy coded factors which we need to get rid of
        var_nms_sel <- gsub("[^::a-z::]", "", var_nms[-1][is_selected])
        sel_fac <- nms_fac[nms_fac %in% var_nms_sel]
        sel_numer <- var_nms_sel[!var_nms_sel %in% sel_fac]
        all_sel_vars <- c(sel_fac, sel_numer)
        whichVariable <- names(is_fact_var) %in% all_sel_vars
      } else {
        # metric variables only
        whichVariable <- coefs[-1] != 0
      }}
  }  
  if(is.null(whichVariable)){
    whichVariable<-screen.cramersv_base(Y,X)
    if(verbose==T){cat("Lasso failed and screening was based on Cramer's V\n")}}
  if(verbose==T){cat("screened ",sum(whichVariable)," variables: ",paste(colnames(saveX)[whichVariable],sep=" "),"\n");
    cat("sample size:",dim(X)[1],"; ")
  }
  end_time <- Sys.time()
  if(verbose==T){cat("time:", round(difftime(end_time, start_time, units="mins"), digits=4), "mins \n")}
  return(whichVariable)
}

make.glmnet <- function(alpha=1, verbose=T, nfolds = 10, nlambda = 200){
  
  tuneGrid <- expand.grid(alpha=alpha, nfolds=nfolds, nlambda=nlambda)
  
  for (q in seq(nrow(tuneGrid))) {
    eval(parse(text = paste0("screen.glmnet_", paste(tuneGrid[q, ],collapse="_"),
                             "<- function(..., alpha = ", tuneGrid[q, 1], ", verbose = ", verbose, ", nfolds =", tuneGrid[q, 2],
                             ", nlambda=", tuneGrid[q, 3], ")
                           {screen.glmnet_base(..., alpha=alpha, verbose=verbose, nfolds=nfolds, nlambda=nlambda)}"
    )), envir = .GlobalEnv)
    cat(paste0("You can now make use of the following screening algorithm: ", "screen.glmnet_", paste(tuneGrid[q, ],collapse="_"), "\n"))
  }  
  
}

tell.screen.glmnet <- function(){
  cat(paste("The algorithm uses Elastic Net estimation (= LASSO for alpha=1), \n",
            "where the tuning parameter with lowest generalized cross validation score is selected.  \n",
            "Variables with non-zero coefficients are selected. \n",
            "If LASSO fails for numerical reasons, lambda is set as log(lambda+1). \n",
            "If it fails again, Cramer's V is used for variable screening."
            ))
}

################################################################################
# Screening algorithm 3: Lasso and Elastic Net with fixed amount of variables  #                                
################################################################################


screen.glmnet_nVar_base <- function(Y, X, family = list(), alpha = 1, nfolds = 5,
                                    nlambda = 150, nVar = 6, verbose = T, ...) {
  if(verbose==T){cat("screen.glmnet_nVar with alpha=", alpha, ", ", nfolds, " fold CV and selecting ", nVar,  " variables \n", sep="")}
  if(nVar<1){stop("nVar needs to be greater or equal to one")}
  start_time <- Sys.time()
  SuperLearner:::.SL.require("glmnet")
  # relevant for column names but shouldnt be a matrix anyways
  X <- as.data.frame(X)
  
  # chose family dependent upon response
  Y <- as.vector(as.matrix(Y))
  if (all(Y == 0 | Y == 1)) {
    family$family <- "binomial"
  } else {
    family$family <- "gaussian"
  }
  saveY<-Y;saveX<-X
  # needed for var names to select from levels of factors later on
  if (ncol(X) > 26 * 27) stop("Find further column names for X!")
  let <- c(letters, sort(do.call("paste0", expand.grid(letters, letters[1:26]))))
  names(X) <- let[1:ncol(X)]
  
  # factors are coded as dummies which are standardized in cv.glmnet()
  # intercept is not in model.matrix() because its already in cv.glmnet()
  is_fact_var <- sapply(X, is.factor)
  X <- try(model.matrix(~ -1 + ., data = X), silent = FALSE)
  
  # cv.glmnet() calls glmnet(), thus arguments are given to glmnet()
  if (ncol(X) <= nVar) {if(verbose==T){cat("Note: ",nVar,"variables are not available in the data (modify setup!). Set nVar=1 for now. \n")}; nVar<- 1}
   successfulfit <- FALSE 
    fitCV <- try(glmnet::cv.glmnet(
      x = X, y = Y, lambda = NULL, type.measure = "deviance",
      nfolds = nfolds, family = family$family, alpha = alpha,
      nlambda = nlambda, keep = T
    ), silent = TRUE)
    # if no variable was selected, penalization might have been too strong, try log(lambda)
    if (all(fitCV$nzero == 0) | all(is.na(fitCV$nzero))) {
      fitCV <- try(glmnet::cv.glmnet(
        x = X, y = Y, lambda = log(fitCV$glmnet.fit$lambda + 1), type.measure = "deviance",
        nfolds = nfolds, family = family$family, alpha = alpha, keep = T
      ), silent = TRUE)
    }
    if(class(fitCV)=="try-error"){successfulfit <- FALSE}else{successfulfit <- TRUE}
    whichVariable <- NULL
    if(successfulfit==TRUE){
    # if nVar is not available, take the closest to nVar available
    if (all(fitCV$nzero != nVar)) {
      lambda_index_with_nVar <- min(which(abs(fitCV$nzero - nVar) == min(abs(fitCV$nzero - nVar))))
      # nVar is available
    } else if (any(fitCV$nzero == nVar)) {
      lambda_index_with_nVar <- min(which(fitCV$nzero == nVar))
    }
    coefs <- coef(fitCV$glmnet.fit, s = fitCV$glmnet.fit$lambda[lambda_index_with_nVar])
    var_nms <- coefs@Dimnames[[1]]
    
    # Instead of Group Lasso:
    # If any level of a dummy coded factor is selected, the whole factor is selected
    if (any(is_fact_var)) {
      nms_fac <- names(which(is_fact_var))
      is_selected <- coefs[-1] != 0 # drop intercept
      # model.matrix adds numbers to dummy coded factors which we need to get rid of
      var_nms_sel <- gsub("[^::a-z::]", "", var_nms[-1][is_selected])
      sel_fac <- nms_fac[nms_fac %in% var_nms_sel]
      sel_numer <- var_nms_sel[!var_nms_sel %in% sel_fac]
      all_sel_vars <- c(sel_fac, sel_numer)
      whichVariable <- names(is_fact_var) %in% all_sel_vars
    } else {
      # metric variables only
      whichVariable <- coefs[-1] != 0
    }
    if (nVar != sum(whichVariable) & verbose==T) {cat("Note: exactly", nVar, "variables could not be screened, instead", sum(whichVariable), "vars were screened. \n")}
    }
    #
      if(is.null(whichVariable)){
      whichVariable<-screen.cramersv_base(Y,X)
      if(verbose==T){cat("Lasso failed and screening was based on Cramer's V\n")}}
    #
    if(verbose==T){cat("screened ",sum(whichVariable)," variables: ",paste(colnames(saveX)[whichVariable]),"\n",sep=" ");
    cat("sample size:",dim(X)[1],"; ")}
    end_time <- Sys.time()
    if(verbose==T){cat("time:", round(difftime(end_time, start_time, units="mins"), digits=4), "mins \n")}
    #
    return(whichVariable)
}

#
make.glmnet_nVar <- function(alpha=1, nVar=6, verbose=T, nfolds = 5, nlambda = 150){
  
  tuneGrid <- expand.grid(alpha=alpha, nVar=nVar, nfolds=nfolds, nlambda=nlambda)
  
  for (q in seq(nrow(tuneGrid))) {
    eval(parse(text = paste0("screen.glmnet_nVar_", paste(tuneGrid[q, ],collapse="_"),
                             "<- function(..., alpha = ", tuneGrid[q, 1], ", verbose = ", verbose, ", nVar = ", tuneGrid[q, 2],
                             ", nfolds =", tuneGrid[q, 3],
                             ", nlambda=", tuneGrid[q, 4], ")
                           {screen.glmnet_nVar_base(..., alpha=alpha, nVar=nVar, verbose=verbose, nfolds=nfolds, nlambda=nlambda)}"
    )), envir = .GlobalEnv)
    cat(paste0("You can now make use of the following screening algorithm: ", "screen.glmnet_nVar_", paste(tuneGrid[q, ],collapse="_"), "\n"))
  }  
  
}

#
tell.screen.glmnet_nVar <- function(){
  cat(paste("The algorithm uses Elastic Net estimation (= LASSO for alpha=1), \n",
            "where the tuning parameter is selected such that approx. nVar coefficients of variables are not zero.  \n",
            "Those variables with non-zero coefficients are then selected. \n",
            "If LASSO fails for numerical reasons, , Cramer's V is used for variable screening."
  ))
}


###################################################
# Screening algorithm 4: based on random forests  #                                
###################################################

screen.randomForest_base <- function(Y, X, family = list(), nVar = 8, ntree = 200, verbose=T, 
                                     mtry = ifelse(family$family == "gaussian", floor(sqrt(ncol(X))), max(floor(ncol(X) / 3), 1)),
                                     nodesize = ifelse(family$family == "gaussian", 5, 1), maxnodes = NULL,
                                     ...) {
  #
  if(verbose==T){cat("screen.randomForest with ntree=", ntree, ", mtry=", mtry, " and selecting ", nVar,  " variables \n", sep="")}
  if(nVar<1){stop("nVar needs to be greater or equal to one")}
  start_time <- Sys.time()
  SuperLearner:::.SL.require("randomForest")
  # chose family dependent upon response variable
  Y <- as.vector(as.matrix(Y))
  if (all(Y == 0 | Y == 1)) {
    family$family <- "binomial"
  } else {
    family$family <- "gaussian"
  }
  if (ncol(X) > nVar) try({
    t_ime <- {
      if (family$family == "gaussian") {
        rank.rf.fit <- randomForest::randomForest(Y ~ .,
                                                  data = X,
                                                  ntree = ntree, mtry = mtry, nodesize = nodesize,
                                                  keep.forest = FALSE, maxnodes = maxnodes, importance = TRUE
        )
        # variables with the largest %IncMSE are the most important ones
        # negative scores mean zero or low importance
        imp_measure <- rank.rf.fit$importance[, "%IncMSE"]
        whichVariable <- (rank(-imp_measure, ties.method = "random") <= nVar)
      }
      if (family$family == "binomial") {
        rank.rf.fit <- randomForest::randomForest(as.factor(Y) ~ .,
                                                  data = X,
                                                  ntree = ntree, mtry = mtry, nodesize = nodesize,
                                                  keep.forest = FALSE, maxnodes = maxnodes, importance = TRUE
        )
        # variables with the largest mean decrease in accuracy are the most important ones
        # negative scores mean zero or low importance
        imp_measure <- rank.rf.fit$importance[, "MeanDecreaseAccuracy"]
        whichVariable <- (rank(-imp_measure, ties.method = "random") <= nVar)
      }
    }

  })else{stop("number of variables to select is greater than number of columns")}
  if(class(rank.rf.fit)[1]=="try-error"){
    whichVariable <- screen.cramersv_base(Y,X)
    if(verbose==T){cat("Random forest failed and screening was based on Cramer's V\n")}}
  #
  if(verbose==T){cat("screened ",sum(whichVariable)," variables: ",paste(colnames(X)[whichVariable]),"\n",sep=" ");
    cat("sample size:",dim(X)[1],"; ")}
  end_time <- Sys.time()
  if(verbose==T){cat("time:", round(difftime(end_time, start_time, units="secs"), digits=4), "secs \n")}
  #
  return(whichVariable)
  #
}

#
make.randomForest <- function(ntree=200, nVar=6, verbose=T){
  
  tuneGrid <- expand.grid(ntree=ntree, nVar=nVar)
  
  for (q in seq(nrow(tuneGrid))) {
    eval(parse(text = paste0("screen.randomForest_", paste(tuneGrid[q, ],collapse="_"),
                             "<- function(..., ntree = ", tuneGrid[q, 1], ", verbose = ", verbose, ", nVar = ", tuneGrid[q, 2], ")
                           {screen.randomForest_base(..., ntree=ntree, nVar=nVar, verbose=verbose)}"
    )), envir = .GlobalEnv)
    cat(paste0("You can now make use of the following screening algorithm: ", "screen.randomForest_", paste(tuneGrid[q, ],collapse="_"), "\n"))
  }  
  
}

#
tell.screen.randomForest <- function(){
  cat(paste("Explanation Philipp"
  ))
}


################################################################
# Screening algorithm 5: no factor variables, e.g. for SL.hal  #                                
################################################################

screen.nofactor <- function(Y,X,screen = screen.glmnet_nVar_base, verbose=T, ...) {

index <- NULL
whichVariable  <- rep(NA, ncol(X))
if(any(unlist(lapply(X,is.factor)))){
  index <- which(unlist(lapply(X,is.factor))==TRUE)
  if(sum(index)>0){
    cat(paste("Removed the following factor variables:",paste(colnames(X)[index],collapse=" "),"\n" ))
    X <- subset(X, select=-index)
  }
}

whichVariable_reduced <- screen(Y=Y, X=X, ...) 

if(is.null(index)==FALSE){
whichVariable[index]  <- FALSE
whichVariable[-index] <- whichVariable_reduced}else{whichVariable <- whichVariable_reduced}


return(whichVariable)
}