# ToDO
# SL.lae
# SL.glm                  -- KEEP
# SL.bayesglm             -- KEEP
# SL.earth                -- DONE
# SL.gam                  -- DONE
# SL.mgcv                 -- DONE
# SL.gbm
# SL.polymars             TODO, but find solution/warning for ltmle
# SL.randomForest         -- DONE
# SL.rpart                -- DONE
# SL.rpartPrune
# SL.step
# SL.step.interaction    -- DONE
# SL.stepAIC             -- stick to SL.step
# SL.xgboost             -- DONE
# SL.nnet                TODO  
# SL.nnet.philipp
# SL.dbarts               -- DONE
# SL.glmnet               -- DONE
# SL.hal                  -- DONE; but needs the screen.nofactor wrapper so far
# SL.orm                  -- DONE 
################################################################################

################
# 1) SL.earth2 #
################


SL.earth_base <- function(Y, X, newX = NULL, family = list(), obsWeights = NULL, id = NULL, degree = 2, penalty = 3,
                      nk = max(21, 2 * ncol(X) + 1), pmethod = "backward", nfold = 0,
                      ncross = 1, minspan = 0, endspan = 0, verbose=F, ...) {
  #
  if(verbose==T){cat("SL.earth started (degrees=", degree,"). ", sep="")}
  start_time <- Sys.time()
  SuperLearner:::.SL.require("earth")
  #
    if (family$family == "gaussian") {
      fit.earth <- earth::earth(
        x = X, y = Y, degree = degree,
        nk = nk, penalty = penalty, pmethod = pmethod, nfold = nfold,
        ncross = ncross, minspan = minspan, endspan = endspan
      )
    }
    if (family$family == "binomial") {
      fit.earth <- earth::earth(
        x = X, y = Y, degree = degree,
        nk = nk, penalty = penalty, pmethod = pmethod, nfold = nfold,
        ncross = ncross, minspan = minspan, endspan = endspan,
        glm = list(family = binomial)
      )
    }
   #
    pred <- predict(fit.earth, newdata = newX, type = "response")
    fit <- list(object = fit.earth)
    out <- list(pred = pred, fit = fit)
    class(out$fit) <- c("SL.earth")
   #
    end_time <- Sys.time()
    if(verbose==T){cat("SL.earth finished. Time:", round(difftime(end_time, start_time, units="mins"), digits=4), "mins \n\n")}
  #
  return(out)
}

#
make.SL.earth <- function(degree=2,verbose=T){
  
  tuneGrid <- expand.grid(degree = degree)
  
  for (q in seq(nrow(tuneGrid))) {
    eval(parse(text = paste0("SL.earth_", paste(tuneGrid[q, ],collapse="_"),
                             "<- function(..., degree = ", tuneGrid[q, 1], ", verbose = ", verbose, ")
                           {SL.earth_base(..., degree = degree, verbose=verbose)}"
    )), envir = .GlobalEnv)
    cat(paste0("You can now make use of the following learning algorithm: ", "SL.earth_", paste(tuneGrid[q, ],collapse="_"), "\n"))
  }  
  
}

######################
# 2) SL.randomForest #
######################


SL.randomForest_base <- function(Y, X, newX = NULL, family = list(), verbose=T, 
                                 mtry = ifelse(family$family =="gaussian", max(floor(ncol(X) / 3), 1), floor(sqrt(ncol(X)))),
                                 ntree = 100, nodesize = ifelse(family$family == "gaussian",5, 1), 
                                 maxnodes = NULL, importance = FALSE, ...) {
  #
  if(verbose==T){cat("SL.randomForest with ", ntree," trees started. ", sep="")}
  start_time <- Sys.time()
  SuperLearner:::.SL.require("randomForest")
    # avoid infinite search for split points in trees
    if (all(apply(X,2,var) == 0)) {
      fit.rf <- "Empty"
      attr(fit.rf, "class") <- "try-error"
      pred <- rep(mean(Y), nrow(Xnew))
      fit <- list(object = fit.rf)
    }
    #
    if (family$family == "gaussian" & !exists("fit.rf")) {
      fit.rf <- randomForest::randomForest(Y ~ .,
                                           data = X,
                                           ntree = ntree, xtest = newX, keep.forest = TRUE,
                                           mtry = mtry, nodesize = nodesize, maxnodes = maxnodes,
                                           importance = importance
      )
      try(pred <- fit.rf$test$predicted, silent = TRUE)
      if (any(class(fit.rf) == "try-error")) {
        pred <- rep(mean(Y), nrow(Xnew))
        if(verbose==T){"Random forest failed: simply predicting mean of Y."}
      }
      fit <- list(object = fit.rf)
    }
    if (family$family == "binomial" & !exists("fit.rf")) {
      fit.rf <- randomForest::randomForest(
        y = as.factor(Y),
        x = X, ntree = ntree, xtest = newX, keep.forest = TRUE,
        mtry = mtry, nodesize = nodesize, maxnodes = maxnodes,
        importance = importance
      )
      try(pred <- fit.rf$test$votes[, 2], silent = TRUE)
      if (any(class(fit.rf) == "try-error")) {
        pred <- rep(mean(Y), nrow(Xnew))
        if(verbose==T){"Random forest failed: simply predicting mean of Y."}
      }
      fit <- list(object = fit.rf)
    }
    out <- list(pred = pred, fit = fit)
    class(out$fit) <- c("SL.randomForest")
    #
    end_time <- Sys.time()
    if(verbose==T){cat("SL.randomForest finished. Time:", round(difftime(end_time, start_time, units="mins"), digits=4), "mins \n\n")}
    #
    return(out)
}

#
make.SL.randomForest <- function(ntree=100,verbose=T){
  
  tuneGrid <- expand.grid(ntree = ntree)
  
  for (q in seq(nrow(tuneGrid))) {
    eval(parse(text = paste0("SL.randomForest_", paste(tuneGrid[q, ],collapse="_"),
                             "<- function(..., ntree = ", tuneGrid[q, 1], ", verbose = ", verbose, ")
                           {SL.randomForest_base(..., ntree = ntree, verbose=verbose)}"
    )), envir = .GlobalEnv)
    cat(paste0("You can now make use of the following learning algorithm: ", "SL.randomForest_", paste(tuneGrid[q, ],collapse="_"), "\n"))
  }  
  
}


#############
# 3) SL.gam #
#############


SL.gam_base <- function(Y, X, newX = NULL, family = list(), obsWeights = NULL, 
                        df.gam = 2, cts.num = 10, verbose=T,
                    ...) {
  #
  if(verbose==T){cat("SL.gam with ", df.gam," df for smoothing spline started (>", cts.num, " unique values = spline added). ", sep="")}
  start_time <- Sys.time()
  SuperLearner:::.SL.require("gam")
  #
  s <- gam:::s # s() is also used by 'mgcv' package - avoid clash
  # adjust model formula for metric and categorical predictors
  metric_var <- apply(X, 2, function(x) (length(unique(x)) > cts.num))
    if (sum(metric_var) != 0 & sum(metric_var) != length(metric_var)) {
      # metric and categorical variables
      gam.model <- as.formula(paste("Y~", paste(paste("s(",
                                                      colnames(X[, metric_var, drop = FALSE]), ",", df.gam,
                                                      ")",
                                                      sep = ""
      ), collapse = "+"), "+", paste(colnames(X[,
                                                !metric_var,
                                                drop = FALSE
      ]), collapse = "+")))
    }else{
    if (all(metric_var)) {
      # metric variables only
      gam.model <- as.formula(paste("Y~", paste(paste("s(",
                                                      colnames(X[, metric_var, drop = FALSE]), ",", df.gam,
                                                      ")",
                                                      sep = ""
      ), collapse = "+")))
    } else {
      # all categorical
      gam.model <- as.formula(paste("Y~", paste(colnames(X),
                                                collapse = "+"
      ), sep = ""))
    }
    }
    fit.gam <- try(gam::gam(gam.model,
                        data = X, family = family,
                        control = gam::gam.control(maxit = 50, bf.maxit = 50),
                        weights = obsWeights
    ))
    if(class(fit.gam)[1]=="try-error"){
      gam.model <- as.formula(paste("Y~1"))
      fit.gam <- try(gam::gam(gam.model,
                              data = X, family = family,
                              control = gam::gam.control(maxit = 50, bf.maxit = 50),
                              weights = obsWeights
      ))
      if(verbose==T){cat("GAM failed with variables provided. Intercept-only GAM fitted.")}
    }
    # or predict.gam depending on version
    pred <- gam::predict.Gam(fit.gam, newdata = newX, type = "response")
    fit <- list(object = fit.gam)
    out <- list(pred = pred, fit = fit)
    class(out$fit) <- c("SL.gam")
    #
    end_time <- Sys.time()
    if(verbose==T){cat("SL.gam finished. Time:", round(difftime(end_time, start_time, units="mins"), digits=4), "mins \n\n")}
    #
    return(out)
}

#
make.SL.gam <- function(df.gam=2, cts.num = 10,verbose=T){
  
  tuneGrid <- expand.grid(df.gam=df.gam, cts.num=cts.num)
  
  for (q in seq(nrow(tuneGrid))) {
    eval(parse(text = paste0("SL.gam_", paste(tuneGrid[q, ],collapse="_"),
                             "<- function(..., df.gam = ", tuneGrid[q, 1], ", verbose = ", verbose,
                             ", cts.num = ", tuneGrid[q, 2],  ")
                           {SL.gam_base(..., df.gam = df.gam, verbose=verbose, cts.num = cts.num)}"
    )), envir = .GlobalEnv)
    cat(paste0("You can now make use of the following learning algorithm: ", "SL.gam_", paste(tuneGrid[q, ],collapse="_"), "\n"))
  }  
  
}

##############
# 4) SL.mgcv #
##############


SL.mgcv_base <- function(Y, X, newX = NULL, family = list(), obsWeights = NULL, 
                        cts.num = 10, by=NA, verbose=F,
                        ...) {
  #
  if(verbose==T){cat("SL.mgcv started (if >", cts.num, " unique values = spline added; it interacts with: ", by, "). ", sep="")}
  start_time <- Sys.time()
  require("mgcv")
  #
  if(all(by %in% colnames(X))==FALSE){if(verbose==T){cat(paste(by, "not in column names of X. `by=NA' is used.\n"))};by<-NA}
  #
  s <- mgcv:::s # s() is also used by 'gam' package - avoid clash
  # adjust model formula for metric and categorical predictors
  metric_var <- apply(X, 2, function(x) (length(unique(x)) > cts.num))
  if (sum(metric_var) != 0 & sum(metric_var) != length(metric_var)) {
    # metric and categorical variables
    gam.model <- as.formula(paste("Y~", paste(paste("s(",
                                                    colnames(X[, metric_var, drop = FALSE]), ", by=", by,
                                                    ")",
                                                    sep = ""
    ), collapse = "+"), "+", paste(colnames(X[,
                                              !metric_var,
                                              drop = FALSE
    ]), collapse = "+")))
  }else{
    if (all(metric_var)) {
      # metric variables only
      gam.model <- as.formula(paste("Y~", paste(paste("s(",
                                                      colnames(X[, metric_var, drop = FALSE]), ", by=", by,
                                                      ")",
                                                      sep = ""
      ), collapse = "+")))
    } else {
      # all categorical
      gam.model <- as.formula(paste("Y~", paste(colnames(X),
                                                collapse = "+"
      ), sep = ""))
    }
  }
  fit.gam <- try(mgcv::gam(gam.model,
                          data = X, family = family,
                          weights = obsWeights
  ))
  if(class(fit.gam)[1]=="try-error"){
    gam.model <- as.formula(paste("Y~1"))
    fit.gam <- try(mgcv::gam(gam.model,
                            data = X, family = family,
                            weights = obsWeights
    ))
    if(verbose==T){cat("GAM failed with variables provided. Intercept-only GAM fitted.")}
  }
  # 
  pred <- mgcv::predict.gam(fit.gam, newdata = newX, type = "response")
  fit <- list(object = fit.gam)
  out <- list(pred = pred, fit = fit)
  class(out$fit) <- c("SL.mgcv")
  #
  end_time <- Sys.time()
  if(verbose==T){cat("SL.mgcv finished. Time:", round(difftime(end_time, start_time, units="mins"), digits=4), "mins \n\n")}
  #
  return(out)
}

#
predict.SL.mgcv <- function (object, newdata, ...) 
{
  require("mgcv")
  pred <- mgcv::predict.gam(object = object$object, newdata = newdata, 
                             type = "response")

  return(pred)
}

#
make.SL.mgcv <- function(by=NA, cts.num = 10,verbose=T){
  
  tuneGrid <- expand.grid(by=by, cts.num=cts.num)
  
  for (q in seq(nrow(tuneGrid))) {
    eval(parse(text = paste0("SL.mgcv_", paste(tuneGrid[q, ],collapse="_"),
                             "<- function(..., by='", tuneGrid[q, 1], "' , verbose = ", verbose,
                             ", cts.num = ", tuneGrid[q, 2],  ")
                           {SL.mgcv_base(..., by = by, verbose=verbose, cts.num = cts.num)}"
    )), envir = .GlobalEnv)
    cat(paste0("You can now make use of the following learning algorithm: ", "SL.mgcv_", paste(tuneGrid[q, ],collapse="_"), "\n"))
  }  
  
}



##########################
# 5) SL.step.interaction #
##########################

SL.step.interaction_base <- 
function (Y, X, newX, family, direction = "both", trace = 0, 
          k = 2, verbose=T, ...) 
{
  if(verbose==T){cat("SL.step.interaction started, direction = ", direction, ". ", sep="")}
  start_time <- Sys.time()
  #
  fit.glm <- glm(Y ~ ., data = X, family = family)
  fit.step <- step(fit.glm, scope = Y ~ .^2, direction = direction, 
                   trace = trace, k = k)
  pred <- predict(fit.step, newdata = newX, type = "response")
  fit <- list(object = fit.step)
  out <- list(pred = pred, fit = fit)
  class(out$fit) <- c("SL.step")
  #
  end_time <- Sys.time()
  if(verbose==T){cat("SL.step.interaction finished. Time:", round(difftime(end_time, start_time, units="mins"), digits=4), "mins \n\n")}
  #
  return(out)
}

#
make.SL.step.interaction <- function(direction="both", verbose=T){
  
  tuneGrid <- expand.grid(direction=direction)
  
  for (q in seq(nrow(tuneGrid))) {
    eval(parse(text = paste0("SL.step.interaction_", paste(tuneGrid[q, ],collapse="_"),
                             "<- function(..., direction='", tuneGrid[q, 1], "' , verbose = ", verbose,  ")
                           {SL.step.interaction_base(..., direction = direction, verbose=verbose)}"
    )), envir = .GlobalEnv)
    cat(paste0("You can now make use of the following learning algorithm: ", "SL.step.interaction_", paste(tuneGrid[q, ],collapse="_"), "\n"))
  }  
  
}

################
# 6) SL.dbarts #
################

SL.dbarts_base <- 
function (Y, X, newX, family, obsWeights, id, sigest = NA, sigdf = 3, 
          sigquant = 0.9, k = 2, power = 2, base = 0.95, binaryOffset = 0, 
          ntree = 200, ndpost = 1000, nskip = 100, printevery = 100, 
          keepevery = 1, keeptrainfits = TRUE, usequants = FALSE, numcut = 100, 
          printcutoffs = 0, nthread = 1, keepcall = TRUE, verb=F, verbose = TRUE, 
          ...) 
{
  #
  if(verbose==T){cat("SL.dbarts started with ", ntree, " trees and k=", k, ". ", sep="")}
  start_time <- Sys.time()
  SuperLearner:::.SL.require("dbarts")
  #
  model <- try(dbarts::bart(x.train = X, y.train = Y, x.test = newX, 
                       sigest = sigest, sigdf = sigdf, sigquant = sigquant, 
                       k = k, power = power, base = base, binaryOffset = binaryOffset, 
                       weights = obsWeights, ntree = ntree, ndpost = ndpost, 
                       nskip = nskip, printevery = printevery, keepevery = keepevery, 
                       keeptrainfits = keeptrainfits, usequants = usequants, 
                       numcut = numcut, printcutoffs = printcutoffs, nthread = nthread, 
                       keepcall = keepcall, keeptrees = TRUE, verbose = verb))
  if (family$family == "gaussian") {
    pred = model$yhat.test.mean
  }
  if (family$family == "binomial") {
    pred = colMeans(stats::pnorm(model$yhat.test))
  }
  fit = list(object = model)
  class(fit) = c("SL.dbarts")
  out = list(pred = pred, fit = fit)
  #
  end_time <- Sys.time()
  if(verbose==T){cat("SL.dbarts finished. Time:", round(difftime(end_time, start_time, units="mins"), digits=4), "mins \n\n")}
  #
  return(out)
}

#
predict.SL.dbarts <- 
function (object, newdata, family, ...) 
{
  pred = colMeans(predict(object$object, newdata = newdata))
  return(pred)
}

# 
make.SL.dbarts <- function(ntree=100, k=2, verbose=T){
  
  tuneGrid <- expand.grid(ntree=ntree, k=k)
  
  for (q in seq(nrow(tuneGrid))) {
    eval(parse(text = paste0("SL.dbarts_", paste(tuneGrid[q, ],collapse="_"),
                             "<- function(..., ntree=", tuneGrid[q, 1], ", k=",tuneGrid[q, 2], " , verbose = ", verbose,  ")
                           {SL.dbarts_base(..., ntree=ntree, k=k, verbose=verbose)}"
    )), envir = .GlobalEnv)
    cat(paste0("You can now make use of the following learning algorithm: ", "SL.dbarts_", paste(tuneGrid[q, ],collapse="_"), "\n"))
  }  
  
}

################
# 7) SL.rpart #
################

SL.rpart_base <- function (Y, X, newX, family, obsWeights, cp = 0.01, minsplit = 20, 
          xval = 0L, maxdepth = 30, minbucket = round(minsplit/3), verbose=T,
          ...) 
{
  #
  if(verbose==T){cat("SL.rpart started with minsplit=", minsplit, ", maxdepth=", maxdepth, ", and ", xval, "-fold CV (0=no CV). ", sep="")}
  start_time <- Sys.time()
  SuperLearner:::.SL.require("rpart")
  # for ltmle 
  fam.init <- family$family
  Y <- as.vector(as.matrix(Y))
  if (all(Y == 0 | Y == 1)) {
    family$family <- "binomial"
  } else {
    family$family <- "gaussian"
  }
  fam.end <- family$family
  #
  if (family$family == "gaussian") {
    fit.rpart <- rpart::rpart(Y ~ ., data = data.frame(Y, 
                                                       X), control = rpart::rpart.control(cp = cp, minsplit = minsplit, 
                                                                                          xval = xval, maxdepth = maxdepth, minbucket = minbucket), 
                              method = "anova", weights = obsWeights)
    pred <- predict(fit.rpart, newdata = newX)
  }
  if (family$family == "binomial") {
    fit.rpart <- rpart::rpart(Y ~ ., data = data.frame(Y, 
                                                       X), control = rpart::rpart.control(cp = cp, minsplit = minsplit, 
                                                                                          xval = xval, maxdepth = maxdepth, minbucket = minbucket), 
                              method = "class", weights = obsWeights)
    pred <- predict(fit.rpart, newdata = newX)[, 2]
  }
  if(fam.init=="binomial" & fam.end=="gaussian"){if(any(pred<0)){pred[pred<0]<-0};if(any(pred>1)){pred[pred>1]<-1}}
  #
  fit <- list(object = fit.rpart)
  out <- list(pred = pred, fit = fit)
  class(out$fit) <- c("SL.rpart")
  #
  end_time <- Sys.time()
  if(verbose==T){cat("SL.rpart finished. Time:", round(difftime(end_time, start_time, units="mins"), digits=4), "mins \n\n")}
  #
  return(out)
}

# 
make.SL.rpart <- function(minsplit=20, maxdepth=30, xval=0, verbose=T){
  
  tuneGrid <- expand.grid(minsplit=minsplit, maxdepth=maxdepth, xval=xval)
  
  for (q in seq(nrow(tuneGrid))) {
    eval(parse(text = paste0("SL.rpart_", paste(tuneGrid[q, ],collapse="_"),
                             "<- function(..., minsplit=", tuneGrid[q, 1], ", maxdepth=",tuneGrid[q, 2], ", xval=", tuneGrid[q, 3],
                             " , verbose = ", verbose,  ")
                           {SL.rpart_base(..., minsplit=minsplit, maxdepth=maxdepth, xval=xval, verbose=verbose)}"
    )), envir = .GlobalEnv)
    cat(paste0("You can now make use of the following learning algorithm: ", "SL.rpart_", paste(tuneGrid[q, ],collapse="_"), "\n"))
  }  
  
}

#################
# 8) SL.xgboost #
#################

# Note: needs more reflection on possible options; maybe subsample etc.
SL.xgboost_base <- function (Y, X, newX, family, obsWeights, id, ntrees = 1000, 
          max_depth = 4, eta = 0.1, minobspernode = 10, params = list(), 
          nthread = 1, verb = 0, save_period = NULL, verbose=T, ...) 
{
  #
  if(verbose==T){cat("SL.xgboost (tree booster) started with max. tree depth of ", max_depth, ", ", ntrees, " trees, eta=", eta, ". ", sep="")}
  start_time <- Sys.time()
  SuperLearner:::.SL.require("xgboost")
  #
  if (!is.matrix(X)) {
    X = model.matrix(~. - 1, X)
  }
  xgmat = xgboost::xgb.DMatrix(data = X, label = Y, weight = obsWeights)
  if (family$family == "gaussian") {
    if (packageVersion("xgboost") >= "1.1.1.1") {
      objective <- "reg:squarederror"
    }
    else {
      objective <- "reg:linear"
    }
    model = xgboost::xgboost(data = xgmat, objective = objective, 
                             nrounds = ntrees, max_depth = max_depth, min_child_weight = minobspernode, 
                             eta = eta, verbose = verb, nthread = nthread, 
                             params = params, save_period = save_period)
  }
  if (family$family == "binomial") {
    model = xgboost::xgboost(data = xgmat, objective = "binary:logistic", 
                             nrounds = ntrees, max_depth = max_depth, min_child_weight = minobspernode, 
                             eta = eta, verbose = verb, nthread = nthread, 
                             params = params, save_period = save_period, eval_metric = "logloss")
  }
  if (family$family == "multinomial") {
    model = xgboost::xgboost(data = xgmat, objective = "multi:softmax", 
                             nrounds = ntrees, max_depth = max_depth, min_child_weight = minobspernode, 
                             eta = eta, verbose = verb, num_class = length(unique(Y)), 
                             nthread = nthread, params = params, save_period = save_period)
  }
  if (!is.matrix(newX)) {
    newX = model.matrix(~. - 1, newX)
  }
  pred = predict(model, newdata = newX)
  fit = list(object = model)
  class(fit) = c("SL.xgboost")
  out = list(pred = pred, fit = fit)
  #
  end_time <- Sys.time()
  if(verbose==T){cat("SL.xgboost finished. Time:", round(difftime(end_time, start_time, units="mins"), digits=4), "mins \n\n")}
  #
  return(out)
}

# 
make.SL.xgboost <- function(ntrees=1000, max_depth=4, eta=0.1, verbose=T){
  
  tuneGrid <- expand.grid(ntrees=ntrees, max_depth=max_depth, eta=eta)
  
  for (q in seq(nrow(tuneGrid))) {
    eval(parse(text = paste0("SL.xgboost_", paste(tuneGrid[q, ],collapse="_"),
                             "<- function(..., ntrees=", tuneGrid[q, 1], ", max_depth=",tuneGrid[q, 2], ", eta=", tuneGrid[q, 3],
                             " , verbose = ", verbose,  ")
                           {SL.xgboost_base(..., ntrees=ntrees, max_depth=max_depth, eta=eta, verbose=verbose)}"
    )), envir = .GlobalEnv)
    cat(paste0("You can now make use of the following learning algorithm: ", "SL.xgboost_", paste(tuneGrid[q, ],collapse="_"), "\n"))
  }  
  
}

#################
# 9) SL.glmnet #
#################

SL.glmnet_base <- function (Y, X, newX, family, obsWeights, id, alpha = 1, nfolds = 10, 
          nlambda = 100, useMin = TRUE, loss = "deviance", verbose=T, ...) 
{
  #
  if(verbose==T){cat("SL.glmnet started with alpha=", alpha, ", ", nfolds, "-fold CV, and ", nlambda, " candidate lambdas. ", sep="")}
  start_time <- Sys.time()
  SuperLearner:::.SL.require("glmnet")
  # for ltmle 
  fam.init <- family$family
  Y <- as.vector(as.matrix(Y))
  if (all(Y == 0 | Y == 1)) {
    family$family <- "binomial"
  } else {
    family$family <- "gaussian"
  }
  fam.end <- family$family
  #
  if (!is.matrix(X)) {
    X <- model.matrix(~-1 + ., X)
    newX <- model.matrix(~-1 + ., newX)
  }
  fitCV <- glmnet::cv.glmnet(x = X, y = Y, weights = obsWeights, 
                             lambda = NULL, type.measure = loss, nfolds = nfolds, 
                             family = family$family, alpha = alpha, nlambda = nlambda, 
                             ...)
  pred <- predict(fitCV, newx = newX, type = "response", 
                  s = ifelse(useMin, "lambda.min", "lambda.1se"))
  #
  if(fam.init=="binomial" & fam.end=="gaussian"){if(any(pred<0)){pred[pred<0]<-0};if(any(pred>1)){pred[pred>1]<-1};if(verbose==T){cat("Note: predictions falling outside [0,1] have been set as 0/1")}}
  #
  fit <- list(object = fitCV, useMin = useMin)
  class(fit) <- "SL.glmnet"
  out <- list(pred = pred, fit = fit)
  #
  end_time <- Sys.time()
  if(verbose==T){cat("SL.glmnet finished. Time:", round(difftime(end_time, start_time, units="mins"), digits=4), "mins \n\n")}
  #
  return(out)
}

#
make.SL.glmnet <- function(alpha=1, nlambda=100, nfolds=10, verbose=T){
  
  tuneGrid <- expand.grid(alpha=alpha, nlambda=nlambda, nfolds=nfolds)
  
  for (q in seq(nrow(tuneGrid))) {
    eval(parse(text = paste0("SL.glmnet_", paste(tuneGrid[q, ],collapse="_"),
                             "<- function(..., alpha=", tuneGrid[q, 1], ", nlambda=",tuneGrid[q, 2], ", nfolds=", tuneGrid[q, 3],
                             " , verbose = ", verbose,  ")
                           {SL.glmnet_base(..., alpha=alpha, nlambda=nlambda, nfolds=nfolds, verbose=verbose)}"
    )), envir = .GlobalEnv)
    cat(paste0("You can now make use of the following learning algorithm: ", "SL.glmnet_", paste(tuneGrid[q, ],collapse="_"), "\n"))
  }  
  
}


##############
# 10) SL.orm #
##############

SL.orm <- function (Y, X, newX, verbose=T,...){
  #
  if (all(Y == 0 | Y == 1)) {
    if(verbose==T){cat("SL.orm started.")}
    start_time <- Sys.time()
    if(verbose==T){("Binary outcome: GLM used instead of ORM.")}
    out <- SuperLearner::SL.glm(Y=Y,X=X,newX=newX,...)
  }else{
  #
  if(verbose==T){cat("SL.orm started.")}
  start_time <- Sys.time()
  SuperLearner:::.SL.require("rms")
  #
  if(length(unique(Y))<5){
    out <- SuperLearner::SL.mean(Y=Y,X=X,newX=newX,...)
    if(verbose==T){cat("Not enough different unique values in Y: mean used instead of ORM. ")}
  }else{
    XX <- as.data.frame(cbind(Y,X))
    fit.orm <- try(rms::orm(Y ~ ., data = XX), silent=TRUE)
    if(length(class(fit.orm))==2 & fit.orm$fail==FALSE){ # if length==1, then either error or technical problem
    if (is.matrix(newX)) {
    newX = as.data.frame(newX)
    }
  pred <- rms:::predict.orm(fit.orm, newdata = newX, type = "mean")
  fit <- list(object = fit.orm)
  class(fit) <- "SL.orm"
  out <- list(pred = pred, fit = fit)
  }else{
    out <- SuperLearner::SL.glm(Y=Y,X=X,newX=newX,...)
    if(verbose==T){cat("Technical problem with ORM: GLM used instead.") }
  }
  }
  }
  #
  end_time <- Sys.time()
  if(verbose==T){cat("SL.orm finished. Time:", round(difftime(end_time, start_time, units="mins"), digits=4), "mins \n\n")}
  #
  return(out)
}

predict.SL.orm <- function (object, newdata, ...) 
{
  require("rms")
  if (is.matrix(newdata)) {
    newdata = as.data.frame(newdata)
  }
  pred <- rms:::predict.orm(object = object$object, newdata = newdata, type = "mean")
  pred
}

##############
# 11) SL.hal #
##############

# Problem: keine Lösung für Faktorvariablen
SL.hal <- function (Y, X, newX, verbose=T, family=stats::gaussian(),
                    obsWeights = rep(1,length(Y)), ...){
  #
  if(verbose==T){cat("SL.hal started. ")}
  start_time <- Sys.time()
  SuperLearner:::.SL.require("hal9001")
  #
  if(!is.matrix(X)){X <- as.matrix(X)}
  if(!is.null(newX) & !is.matrix(newX)){newX <- as.matrix(newX)}
  #
  fit.hal <- try(hal9001::fit_hal(X= X,Y=Y, family=family$family,
                                   num_knots = hal9001:::num_knots_generator(
                                   max_degree = ifelse(ncol(X)>=20,2,3),
                                   smoothness_order = 1,
                                   base_num_knots_0 = ifelse(sqrt(nrow(X)) < 200, sqrt(nrow(X)), 200),
                                   base_num_knots_1 = ifelse(sqrt(nrow(X)) < 50, sqrt(nrow(X)), 50)),
                                   fit_control = list(cv_select=T,
                                                    n_folds =10,
                                                    weights = obsWeights,
                                                    foldid =NULL,
                                                    use_min = T,
                                                    lambda.min.ratio = 1e-4,
                                                    prediction_bounds ="default"),
                                 ), silent=TRUE)
  #
  if(class(fit.hal)[1]=="try-error"){
    if(verbose==T){cat("Technical failure: GLM used instead of HAL.")}
    out <- SuperLearner::SL.glm(Y=Y,X=X,newX=newX,family=family, obsWeights=rep(1,length(Y)),...)
  }else{
  if (!is.null(newX)) {
    pred <- stats::predict(fit.hal, new_data = newX)
  }
  else {
    pred <- stats::predict(fit.hal, new_data = X)
  }
  fit <- list(object = fit.hal)
  class(fit) <- "SL.hal"
  out <- list(pred = pred, fit = fit)
  }
  #
  end_time <- Sys.time()
  if(verbose==T){cat("SL.hal finished. Time:", round(difftime(end_time, start_time, units="mins"), digits=4), "mins \n\n")}
  #
  return(out)
}

predict.SL.hal <- function (object, newdata, ...) 
{
  if(!is.matrix(newdata)){newdata <- as.matrix(newdata)}
  pred <- stats::predict(object$object, new_data = newdata)
  return(pred)
}

#############
# SL.median #
#############

SL.median <- function (Y, X, newX, family, obsWeights, id, ...) 
{
  SuperLearner:::.SL.require("matrixStats")
  medianY <- matrixStats::weightedMedian(Y, w = obsWeights)
  pred <- rep.int(medianY, times = nrow(newX))
  fit <- list(object = medianY)
  out <- list(pred = pred, fit = fit)
  class(out$fit) <- c("SL.mean")
  return(out)
}
