# Simulation 3 from Schomaker, McIlleron, Denti, Diaz (2023)
# "Causal Inference for Multiple Time Point Interventions"
#
# all plots and tables will be saved in the below specified working directory
# progress of the simulation will be saved in a .txt file (sim_progress.txt)
#
# add to your working directory the following files:
# screening_algorithms.R, learning_algorithms.R and Results_final_simulation_3.tex
# Compile the .tex-file to get a pdf with all summaries of the simulation 

setwd("yourpath")
#
library(CICI)     # install.packages("CICI")
library(CICIplus) # see https://github.com/MichaelSchomaker/CICIplus
#
library(simcausal)
library(ggplot2)
library(xtable)
library(SuperLearner)
library(RColorBrewer)
#
source(paste0(getwd(),"/screening_algorithms.R")) # own screening functions for SuperLearner 
source(paste0(getwd(),"/learning_algorithms.R"))  # own learners for SuperLearner 
#

set.seed(241280)
ptm <- proc.time()

# SETUP
runs          <- 250     # number of simulation runs
N             <- 1000    # sample size
intervention  <- a.int  <- c(0,0.25,0.5,0.75,seq(1,10,0.5))
n.int         <- length(intervention)     
cpus          <- 8      # number of threads to use for parallelization
#

###########################
# Data generating process #
###########################

#
rnorm_trunc <- function(n, mean, sd, minval = 0, maxval = 10000, 
                        min.low = 0, max.low = 50, min.high = 5000, max.high = 10000)
{
  out <- rnorm(n = n, mean = mean, sd = sd)
  minval <- minval[1]; min1 <- min.low[1]; max1 <- max.low[1]
  maxval <- maxval[1]; min2 <- min.high[1]; max2 <- max.high[1]
  leq.zero <- length(out[out <= minval])
  geq.max <- length(out[out >= maxval])
  out[out <= minval] <- runif(n = leq.zero, min = min1, max = max1)
  out[out >= maxval] <- runif(n = geq.max, min = min2, max = max2)
  out
}
#

t.end <-5

#
M <- DAG.empty()
M <- M +
  node("Sex", 
       t=0,
       distr = "rbern",
       prob = .5) +
  node("Genotype", 
       t=0,
       dist= "rcat.b1",
       probs = {
         plogis(-0.103 + ifelse(Sex[0] == 1, 0.223, 0.173)); 
         plogis(-0.086 + ifelse(Sex[0] == 1, 0.198, 0.214)); 
         plogis(-0.309 + ifelse(Sex[0] == 1, 0.082, 0.107)) 
       }
  ) +
  node("Age",  
       t=0,
       dist= "rnorm_trunc",
       mean = 1.501,
       minval = 0.693,
       min.low = 0.693,
       min.high = 1,
       maxval = 2.8,
       max.low = 2.7,
       max.high = 2.8,
       sd = 0.3690) +
  node("Weight", 
       t=0,
       dist= "rnorm_trunc",
       mean = 1.5 + (.2 * Sex[0] + Age[0] * 0.774) *.94  , 
       sd = 0.3,
       minval = 2.26,
       min.low = 2.26,
       min.high = 2.67,
       max.low = 3.02,
       max.high = 3.37,
       maxval = 3.37) +
  node("NRTI",
       t=0,
       dist= "rcat.b1",
       probs = {
         plogis(-0.006 + ifelse(Age[0] > 1.4563 ,Age[0] * 0.1735 , Age[0] * 0.157)); 
         plogis(-0.006 + ifelse(Age[0] > 1.4563 ,Age[0] * 0.1735 , Age[0] * 0.157));
         plogis(-0.006 + ifelse(Age[0] > 1.4563 ,Age[0] * 0.1570 , Age[0] * 0.1818)) 
       })   +
  node("CoMo", 
       t=0,
       dist ="rbern",
       prob= 0.15
  ) +
  node("Dose", 
       t=0,
       dist= "rcat.b1",
       probs ={
         plogis(5 + sqrt(Weight[t]) * 8 - Age[t] * 10);
         plogis(4 + sqrt(Weight[t]) * 8.768 - Age[t] * 9.060);  
         plogis(3 + sqrt(Weight[t]) * 6.562 - Age[t] * 8.325) 
       }) +
  node('C12', 
       t=0,
       dist="rnorm_trunc",
       mean = -8 + Age[0] * .1  + Genotype[0] * 4.66 + Dose[0] * .1 +
         (Genotype[0] <= 2) * 2.66  + (Genotype[0] ==3) * 4.6,
       min.low = 0.2032,
       min.high = 0.88,
       max.low = 8.376,
       max.high = 21,
       minval = 0.2032,
       maxval = 21,
       sd=4.06
  ) +
  node('VL', 
       t=0,
       dist ="rbern",
       prob= 1 - plogis(0.4 + 1.9 * sqrt(C12[0]))) 


######
M <- M +
  node("MEMS",
       t = 1,
       distr = "rbern",
       prob = plogis(CoMo[t - 1] * 0.31 + 0.71)
  ) +
  node("MEMS",
       t = 2:4,
       distr = "rbern",
       prob = plogis(CoMo[t - 1] * 0.31 + MEMS[t - 1] * 0.31 + 0.41)
  ) +
  node("Weight",
       t = 1:4,
       distr = "rnorm_trunc",
       mean =  I(CoMo[t-1]==1) * -0.05 + Weight[t - 1] * 1.04, 
       sd = .4, 
       min.low = 2.26,
       min.high = 2.473,
       minval = 2.26,
       maxval = 3.37,
       max.low =  3.2,  
       max.high = 3.37
  ) +
  node("CoMo",
       t = 1:4,
       distr = "rbern",
       prob = 1 - (plogis(I(CoMo[t - 1] == 1) * .5 + Age[0] * .1 + Weight[t - 1] * .1)
       )
  ) +
  node("Dose",
       t = 1:4,
       distr = "rcat.b1",
       prob = {
         plogis(4 + (Dose[t - 1] * 0.5) + sqrt(Weight[t]) * 4 - Age[0] * 10);
         plogis(-8 + (Dose[t - 1] * 0.5) + sqrt(Weight[t]) * 8.568 - Age[0] * 9.060);
         plogis(20 + (Dose[t - 1] * 0.5) + sqrt(Weight[t]) * 6.562 - Age[0] * 18.325)
       }
  ) +
  node("C12",
       t = 1:4,
       distr = "rnorm_trunc",
       mean = Dose[t] * .1 + MEMS[t] * .1 + (Genotype[0] <= 2) * 2.66 +
         (Genotype[0] == 3) * 4.6,
       min.low = 0.2032,
       min.high = 0.88, 
       max.low = 8.37,    
       max.high = 21.84,  
       minval = 0.2032,
       maxval = 21.84,
       sd = 4.06          
  ) +
  node("VL",
       t = 1,
       distr = "rbern",
       prob = 1 - plogis(0.4 + CoMo[t - 1] * .1 + 2 * sqrt(C12[t]))
  ) +
  node("VL",
       t = 2,
       distr = "rbern",
       prob = 1 - plogis(CoMo[t - 1] * .1 + 2 * sqrt(C12[t]))
  )+
  node("VL",
       t = 3,
       distr = "rbern",
       prob = 1 - plogis(CoMo[t - 1] * .1 + 1.8 * sqrt(C12[t]))
  ) +
  node("VL",
       t = 4,
       distr = "rbern",
       prob = 1 - plogis(-.2 + CoMo[t - 1] * .1 + 2 * sqrt(C12[t]))
  )


# Some observed data
Dset <- simcausal::set.DAG(M)
Odat <- simcausal::sim(DAG = Dset, n = 5000, rndseed = 01111920, wide=T)
summary(Odat)


###################
# Generate Truth  #
###################
int.a.names  <- paste("C12.cont.",1:n.int,sep="") # intervention names
int.a.names
t.end=4

# Intervention on the DAG given a continuous interventions
for(j in 0:n.int){
  assign(paste("C12.cont.",j,sep=""),c(node("C12", t = 0:t.end, distr = "rconst", const=NA)))  # NA because indexing with [j] not possible
}

modify.int.const <- function(int,number){
  int[[5]]$const <- number
  return(int)
}

for(j in 1:length(int.a.names)){  # trick to correctly assign continuous intervention by overwriting default
  for(k in 1:length(0:t.end)){
    assign(paste("C12.cont.",j,sep=""), lapply(get(paste("C12.cont.",j,sep="")),modify.int.const,number=a.int[j]) )
  }}

for(j in 1:n.int){
  Dset <- Dset + action(int.a.names[j], nodes = get(int.a.names[j])) 
}

# simulate for the intervention
sim.cont <- simcausal::sim(DAG = Dset, actions = int.a.names, n = 1000000, rndseed = 241280) 

Y.names <- colnames(sim.cont[[j]])[sort(c(grep("VL_",colnames(sim.cont[[j]]))))]
for(j in 1:n.int){
  assign(paste("psi",c(1:n.int)[j],sep=""), apply(sim.cont[[j]][,Y.names],2,mean))
}

psi_true <- as.data.frame(cbind(matrix(unlist(mget(paste("psi",c(1:n.int),sep=""))),ncol=1),rep(0:t.end,n.int),rep(a.int, each=(t.end+1))))
colnames(psi_true)[1] <- "psi"
colnames(psi_true)[2] <- "times"
colnames(psi_true)[3] <-  "Int"
psi_true <- psi_true[order(psi_true$times),]
psi_true


# true dose-response curves
mymin <- round(min(psi_true$psi)-1,digits=0)
mymax <- round(max(psi_true$psi)+1,digits=0)
mycolors <- c("black", "orangered3","dodgerblue4", "springgreen3","gold","greenyellow",rainbow(20))
mycols <- mycolors[1:length(unique(psi_true$times))]
psi_true$psi

# a) ggplot
gg.true <- ggplot(psi_true[psi_true$Int<20,], aes(x=Int,y=psi,col=as.factor(times)))  + geom_line(size=1.3) + theme_bw() +
  scale_color_manual(values = mycols) +
  scale_x_continuous("Intervention", breaks=c(seq(min(a.int),max(a.int),length.out=5))) +
  scale_y_continuous(expression(psi)) +
  guides(fill = guide_legend(keywidth = 2, keyheight = 2, title="Time")) +
  ggtitle("True dose-response curves")  +
  theme(axis.title.x = element_text(size=13), axis.text.x = element_text(size=13),axis.title.y = element_text(size=13, angle = 90),
        axis.text.y = element_text(size=13), legend.text =  element_text(size=13), legend.title = element_text(size=13, face = "bold", hjust = 0),legend.position =   "bottom") +
  guides(col=guide_legend(title="Time"))

pdf(file=paste0(getwd(),"/true_CDRC.pdf"))
plot(gg.true)
dev.off()

#########################################
# TRUTH FOR E(Y|A_t=a_t, ..., a_0=a_0)  #
#########################################

Odat.cont <- simcausal::sim(DAG = Dset, n = 5000000, rndseed = 241280)
psi_true_preint <- psi_true; psi_true_preint$psi <- NA
span <- diff(intervention)[1]/2 # a +/- span is considered to be equivalent to a
Ys <- Odat.cont[,grep("VL_",colnames(Odat.cont))]
As <- Odat.cont[,grep("C12_",colnames(Odat.cont))]
for(t in 0:t.end){
  for(i in 1:n.int){
    selind <- apply(matrix((As[,1:(t+1)] > a.int[i]-span) & (As[,1:(t+1)] < a.int[i]+span),ncol=t+1),1,all)
    psi_true_preint[psi_true_preint$times==c(0:t.end)[t+1],][i,1] <- mean(Ys[,t+1][selind] ) 
  }}

gg.preint <- ggplot(psi_true_preint[psi_true_preint$Int<20 & psi_true_preint$times<4,], aes(x=Int,y=psi,col=as.factor(times)))  + geom_smooth(size=1.3, se=F) + theme_bw() +
  scale_color_manual(values = mycols) +
  scale_x_continuous("Intervention", breaks=c(seq(min(a.int),max(a.int),length.out=5))) +
  scale_y_continuous("E(Y_t|abar_t)") +
  guides(fill = guide_legend(keywidth = 2, keyheight = 2, title="Time")) +
  ggtitle("True associational relationship (where defined, and smoothed)")  +
  theme(axis.title.x = element_text(size=13), axis.text.x = element_text(size=13),axis.title.y = element_text(size=13, angle = 90),
        axis.text.y = element_text(size=13), legend.text =  element_text(size=13), legend.title = element_text(size=13, face = "bold", hjust = 0),legend.position =   "bottom") +
  guides(col=guide_legend(title="Time"))

pdf(file=paste0(getwd(),"/true_obs_DRC.pdf"))
plot(gg.preint)
dev.off()


#################
# simulation    #
#################
# quiet output for below
quiet <- function(x){sink(tempfile());  on.exit(sink()); invisible(force(x))}

# screening and learning algorithms
#
verb=T
make.cramer(nscreen = c(4,6),verbose=verb)
make.glmnet(alpha=c(0.5,1),verbose=verb)
make.glmnet_nVar(nVar=c(4,6,8),verbose=verb,nfolds=c(5,10))
#
verb2=T
make.SL.earth(degree = c(2,5),verbose=verb2)
make.SL.gam(df.gam=c(2,3,4),verbose=verb2)
make.SL.step.interaction(direction=c("both","backward"), verbose=verb2)
make.SL.glmnet(alpha=c(1,0.5),nfolds=c(5,10),verbose=verb2)
#
ml  <-  list(c("SL.mean", "All"),
             c("SL.glm", "All"),
             c("SL.glmnet_1_100_10", "All"),
             #
             c("SL.gam_2_10", "screen.cramersv_4"),
             c("SL.gam_4_10", "screen.cramersv_4"),
             #
             c("SL.glm", "screen.glmnet_1_10_200"),
             c("SL.earth_5", "screen.glmnet_nVar_1_6_10_150"),
             c("SL.gam_2_10", "screen.glmnet_nVar_1_6_10_150"),
             c("SL.step.interaction_backward", "screen.glmnet_nVar_1_4_10_150")
)
base.learners <- c("SL.glmnet_base","SL.gam_base","screen.glmnet_base",
                   "screen.glmnet_nVar_base","SL.earth_base","screen.cramersv_base",
                   "SL.step.interaction_base")

# values of c
cs            <- c(1,0.2,0.1,0.05,0.025,0.01,0.001) 

# store.results
sim.results1 <- matrix(NA,ncol=runs,nrow=n.int*(t.end+1))
sim.results2 <- matrix(NA,ncol=runs,nrow=n.int*(t.end+1))
sim.results3 <- matrix(NA,ncol=runs,nrow=n.int*(t.end+1))
sim.results4 <- matrix(NA,ncol=runs,nrow=n.int*(t.end+1))
sim.results1b <- matrix(NA,ncol=runs,nrow=n.int*(t.end+1))
sim.results2b <- matrix(NA,ncol=runs,nrow=n.int*(t.end+1))
sim.results3b <- matrix(NA,ncol=runs,nrow=n.int*(t.end+1))
sim.results4b <- matrix(NA,ncol=runs,nrow=n.int*(t.end+1))
diag.results_crude <- matrix(NA,ncol=runs,nrow=n.int*(t.end+1))
diag.results_cond <- matrix(NA,ncol=runs,nrow=n.int*(t.end+1))
SL.weights <- rep(list(matrix(NA,nrow=length(ml),ncol=runs)),6)
weights_d_1 <- weights_b_1 <- weights_d_01 <- weights_b_01 <- weights_d_001 <- weights_b_001 <- rep(list(matrix(0, nrow=3, ncol=n.int, dimnames=list(NULL,paste(intervention)))),t.end+1)
wm.d <- expand.grid(cs,intervention,1:(t.end+1)); wm.b <- wm.d 
wm.d$pno <- wm.b$pno <- NA; colnames(wm.d) <- colnames(wm.b)<- c("c","Intervention","Time","pno")
wm.d <- wm.b <- rep(list(wm.d), runs)


write(matrix("started with simulation..."),file=paste(getwd(),"/sim_progress.txt",sep=""))

# Simulation loop
for(r in 1:runs)try({
# draw data
simdat   <- suppressWarnings(simcausal::sim(DAG = Dset, n = N, verbose=F)[,-1])

cat(paste("This is simulation run number",r, "\n"))
write(matrix(paste("started with simulation run #",r)),file=paste(getwd(),"/sim_progress.txt",sep=""),append=T)
#
simdat2 <- simdat[,-c(grep("CoMo",colnames(simdat)),grep("Dose",colnames(simdat)))]


# Method 1: naive g-formula with model screening
check.models <- make.model.formulas(simdat2,
                                     Lnodes  = c("MEMS_1","Weight_1",
                                                 "MEMS_2","Weight_2",
                                                 "MEMS_3","Weight_3",
                                                 "MEMS_4","Weight_4"
                                     ),
                                     Ynodes  = c("VL_0","VL_1","VL_2","VL_3","VL_4"),
                                     Anodes  = c("C12_0","C12_1","C12_2","C12_3","C12_4"))

glmnet.formulas <- model.formulas.update(check.models$model.names, simdat2, with.s=T,pw=F)

estimates <- try(gformula(X=simdat2,
                       Lnodes  = c("MEMS_1","Weight_1",
                                   "MEMS_2","Weight_2",
                                   "MEMS_3","Weight_3",
                                   "MEMS_4","Weight_4"
                       ),
                       Ynodes  = c("VL_0","VL_1","VL_2","VL_3","VL_4"),
                       Anodes  = c("C12_0","C12_1","C12_2","C12_3","C12_4"),
                       Yform=glmnet.formulas$Ynames, Lform=glmnet.formulas$Lnames, 
                       calc.support = TRUE,
                       abar=intervention, ncores=cpus, verbose=F
), silent=TRUE)
diag.results_crude[,r] <- unlist(c(estimates$diagnostics$crude_support))
diag.results_cond[,r] <- unlist(c(estimates$diagnostics$conditional_support))

# Method 2: SGF with both parametric and binning weights
# a) c=1
write(matrix(paste("busy with c=1")),file=paste(getwd(),"/sim_progress.txt",sep=""),append=T)

w.b <- calc.weights(X=simdat2,
                    Lnodes  = c("Sex_0", "Genotype_0","Age_0","Weight_0","NRTI_0",
                                "MEMS_1","Weight_1",
                                "MEMS_2","Weight_2",
                                "MEMS_3","Weight_3",
                                "MEMS_4","Weight_4"
                    ),
                    Ynodes  = c("VL_0","VL_1","VL_2","VL_3","VL_4"),
                    Anodes  = c("C12_0","C12_1","C12_2","C12_3","C12_4"),
                    Cnodes=NULL,
                    abar=intervention,c=cs,
                    screen = FALSE, 
                    survival = FALSE, 
                    d.method=c("binning"),
                    z.method=c("density")
                  ) 

w.d <- calc.weights(X=simdat2,
                    Lnodes  = c("Sex_0", "Genotype_0","Age_0","Weight_0","NRTI_0",
                                "MEMS_1","Weight_1",
                                "MEMS_2","Weight_2",
                                "MEMS_3","Weight_3",
                                "MEMS_4","Weight_4"
                    ),
                    Ynodes  = c("VL_0","VL_1","VL_2","VL_3","VL_4"),
                    Anodes  = c("C12_0","C12_1","C12_2","C12_3","C12_4"),
                    Cnodes=NULL,
                    abar=intervention,c=cs,
                    screen = FALSE, 
                    survival = FALSE, 
                    d.method=c("parametric"),
                    z.method=c("density")
) 

# save weight summaries
s.wd <- quiet(summary(w.d))
s.wb <- quiet(summary(w.b))
for(i in 1:length(cs)){
  for(j in 1:length(intervention)){
    for(k in 1:(t.end+1)){
      wm.d[[r]]$pno[wm.d[[r]]$c==cs[i] & wm.d[[r]]$Intervention==intervention[j] & wm.d[[r]]$Time==k] <- s.wd[[i]][[k]][1,j]
      wm.b[[r]]$pno[wm.b[[r]]$c==cs[i] & wm.b[[r]]$Intervention==intervention[j] & wm.b[[r]]$Time==k] <- s.wb[[i]][[k]][1,j]
    }}}

wbs <- quiet(summary(w.b)); wds <- quiet(summary(w.d))
weights_b_1[[1]] <- wbs$`1`$`Time point 1`+weights_b_1[[1]]; weights_d_1[[1]] <- wds$`1`$`Time point 1`+weights_d_1[[1]]
weights_b_1[[2]] <- wbs$`1`$`Time point 2`+weights_b_1[[2]]; weights_d_1[[2]] <- wds$`1`$`Time point 2`+weights_d_1[[2]]
weights_b_1[[3]] <- wbs$`1`$`Time point 3`+weights_b_1[[3]]; weights_d_1[[3]] <- wds$`1`$`Time point 3`+weights_d_1[[3]]
weights_b_1[[4]] <- wbs$`1`$`Time point 4`+weights_b_1[[4]]; weights_d_1[[4]] <- wds$`1`$`Time point 4`+weights_d_1[[4]]
weights_b_1[[5]] <- wbs$`1`$`Time point 5`+weights_b_1[[5]]; weights_d_1[[5]] <- wds$`1`$`Time point 5`+weights_d_1[[5]]

weights_b_01[[1]] <- wbs$`0.01`$`Time point 1`+weights_b_01[[1]]; weights_d_01[[1]] <- wds$`0.01`$`Time point 1`+weights_d_01[[1]]
weights_b_01[[2]] <- wbs$`0.01`$`Time point 2`+weights_b_01[[2]]; weights_d_01[[2]] <- wds$`0.01`$`Time point 2`+weights_d_01[[2]]
weights_b_01[[3]] <- wbs$`0.01`$`Time point 3`+weights_b_01[[3]]; weights_d_01[[3]] <- wds$`0.01`$`Time point 3`+weights_d_01[[3]]
weights_b_01[[4]] <- wbs$`0.01`$`Time point 4`+weights_b_01[[4]]; weights_d_01[[4]] <- wds$`0.01`$`Time point 4`+weights_d_01[[4]]
weights_b_01[[5]] <- wbs$`0.01`$`Time point 5`+weights_b_01[[5]]; weights_d_01[[5]] <- wds$`0.01`$`Time point 5`+weights_d_01[[5]]

weights_b_001[[1]] <- wbs$`0.001`$`Time point 1`+weights_b_001[[1]]; weights_d_001[[1]] <- wds$`0.001`$`Time point 1`+weights_d_001[[1]]
weights_b_001[[2]] <- wbs$`0.001`$`Time point 2`+weights_b_001[[2]]; weights_d_001[[2]] <- wds$`0.001`$`Time point 2`+weights_d_001[[2]]
weights_b_001[[3]] <- wbs$`0.001`$`Time point 3`+weights_b_001[[3]]; weights_d_001[[3]] <- wds$`0.001`$`Time point 3`+weights_d_001[[3]]
weights_b_001[[4]] <- wbs$`0.001`$`Time point 4`+weights_b_001[[4]]; weights_d_001[[4]] <- wds$`0.001`$`Time point 4`+weights_d_001[[4]]
weights_b_001[[5]] <- wbs$`0.001`$`Time point 5`+weights_b_001[[5]]; weights_d_001[[5]] <- wds$`0.001`$`Time point 5`+weights_d_001[[5]]
##

estimates2 <- try(sgf(X=simdat2,
                  Lnodes  = c("MEMS_1","Weight_1",
                              "MEMS_2","Weight_2",
                              "MEMS_3","Weight_3",
                              "MEMS_4","Weight_4"
                  ),
                  Ynodes  = c("VL_0","VL_1","VL_2","VL_3","VL_4"),
                  Anodes  = c("C12_0","C12_1","C12_2","C12_3","C12_4"),
                  abar =  intervention, SL.library = ml, SL.export=base.learners,
                  Yweights = w.b$`1`, 
                  ncores=cpus, verbose=FALSE, seed=NULL, prog=NULL
), silent=TRUE)

estimates2b <- try(sgf(X=simdat2,
                  Lnodes  = c("MEMS_1","Weight_1",
                              "MEMS_2","Weight_2",
                              "MEMS_3","Weight_3",
                              "MEMS_4","Weight_4"
                  ),
                  Ynodes  = c("VL_0","VL_1","VL_2","VL_3","VL_4"),
                  Anodes  = c("C12_0","C12_1","C12_2","C12_3","C12_4"),
                  abar =  intervention, SL.library = ml, SL.export=base.learners,
                  Yweights = w.d$`1`, 
                  ncores=cpus, verbose=FALSE, seed=NULL, prog=NULL
), silent=TRUE)

# b) c=0.01
write(matrix(paste("busy with c=0.01")),file=paste(getwd(),"/sim_progress.txt",sep=""),append=T)

estimates3 <- try(sgf(X=simdat2,
                  Lnodes  = c("MEMS_1","Weight_1",
                              "MEMS_2","Weight_2",
                              "MEMS_3","Weight_3",
                              "MEMS_4","Weight_4"
                  ),
                  Ynodes  = c("VL_0","VL_1","VL_2","VL_3","VL_4"),
                  Anodes  = c("C12_0","C12_1","C12_2","C12_3","C12_4"),
                  abar =  intervention, SL.library = ml, SL.export=base.learners,
                  Yweights = w.b$`0.01`, 
                  ncores=cpus, verbose=FALSE, seed=NULL, prog=NULL
), silent=TRUE)

estimates3b <- try(sgf(X=simdat2,
                  Lnodes  = c("MEMS_1","Weight_1",
                              "MEMS_2","Weight_2",
                              "MEMS_3","Weight_3",
                              "MEMS_4","Weight_4"
                  ),
                  Ynodes  = c("VL_0","VL_1","VL_2","VL_3","VL_4"),
                  Anodes  = c("C12_0","C12_1","C12_2","C12_3","C12_4"),
                  abar =  intervention, SL.library = ml, SL.export=base.learners,
                  Yweights = w.d$`0.01`, 
                  ncores=cpus, verbose=FALSE, seed=NULL, prog=NULL
), silent=TRUE)

# c) c=0.001
write(matrix(paste("busy with c=0.001")),file=paste(getwd(),"/sim_progress.txt",sep=""),append=T)

estimates4 <- try(sgf(X=simdat2,
                  Lnodes  = c("MEMS_1","Weight_1",
                              "MEMS_2","Weight_2",
                              "MEMS_3","Weight_3",
                              "MEMS_4","Weight_4"
                  ),
                  Ynodes  = c("VL_0","VL_1","VL_2","VL_3","VL_4"),
                  Anodes  = c("C12_0","C12_1","C12_2","C12_3","C12_4"),
                  abar =  intervention, SL.library = ml, SL.export=base.learners,
                  Yweights = w.b$`0.001`, 
                  ncores=cpus, verbose=FALSE, seed=NULL, prog=NULL
), silent=TRUE)

estimates4b <- try(sgf(X=simdat2,
                  Lnodes  = c("MEMS_1","Weight_1",
                              "MEMS_2","Weight_2",
                              "MEMS_3","Weight_3",
                              "MEMS_4","Weight_4"
                  ),
                  Ynodes  = c("VL_0","VL_1","VL_2","VL_3","VL_4"),
                  Anodes  = c("C12_0","C12_1","C12_2","C12_3","C12_4"),
                  abar =  intervention, SL.library = ml, SL.export=base.learners,
                  Yweights = w.d$`0.001`, 
                  ncores=cpus, verbose=FALSE, seed=NULL, prog=NULL
), silent=TRUE)

# SL.weights
rownames(SL.weights[[1]]) <- rownames(SL.weights[[2]]) <- rownames(SL.weights[[3]]) <- rownames(SL.weights[[4]])<- rownames(SL.weights[[5]]) <- rownames(SL.weights[[6]])  <- apply(expand.grid(c(paste0("av.")),rownames(estimates2b$SL.weights)),1,paste,collapse="_")
SL.weights[[1]][,r] <- c(apply(estimates2$SL.weights,1,mean))
SL.weights[[2]][,r] <- c(apply(estimates2b$SL.weights,1,mean))
SL.weights[[3]][,r] <- c(apply(estimates3$SL.weights,1,mean))
SL.weights[[4]][,r] <- c(apply(estimates3b$SL.weights,1,mean))
SL.weights[[5]][,r] <- c(apply(estimates4$SL.weights,1,mean))
SL.weights[[6]][,r] <- c(apply(estimates4b$SL.weights,1,mean))

# remove nonsense results, if any
estimates2$results$psi[estimates2$results$psi<0 | estimates2$results$psi>1] <- NA
estimates2b$results$psi[estimates2b$results$psi<0 | estimates2b$results$psi>1] <- NA
estimates3$results$psi[estimates3$results$psi<0 | estimates3$results$psi>1] <- NA
estimates3b$results$psi[estimates3b$results$psi<0 | estimates3b$results$psi>1] <- NA
estimates4$results$psi[estimates4$results$psi<0 | estimates4$results$psi>1] <- NA
estimates4b$results$psi[estimates4b$results$psi<0 | estimates4b$results$psi>1] <- NA

# check errors & store estimates
if(class(estimates)!="try-error"){sim.results1[,r] <- sim.results1b[,r] <- c(estimates$results$psi)}else{
  cat("Note: error in estimating estimates1 -> no estimate saved \n") 
  write(matrix(paste("Note: error in estimating estimates1 -> no estimate saved ")),file=paste(getwd(),"/sim_progress.txt",sep=""),append=T)}
if(class(estimates2)!="try-error"){sim.results2[,r] <- c(estimates2$results$psi)}else{
  cat("Note: error in estimating estimates2 -> no estimate saved \n") 
  write(matrix(paste("Note: error in estimating estimates2 -> no estimate saved ")),file=paste(getwd(),"/sim_progress.txt",sep=""),append=T)}
if(class(estimates2b)!="try-error"){sim.results2b[,r] <- c(estimates2b$results$psi)}else{
  cat("Note: error in estimating estimates2b -> no estimate saved \n")
  write(matrix(paste("Note: error in estimating estimates2b -> no estimate saved ")),file=paste(getwd(),"/sim_progress.txt",sep=""),append=T)}
if(class(estimates3)!="try-error"){sim.results3[,r] <- c(estimates3$results$psi)}else{
  cat("Note: error in estimating estimates3 -> no estimate saved \n")
  write(matrix(paste("Note: error in estimating estimates3 -> no estimate saved ")),file=paste(getwd(),"/sim_progress.txt",sep=""),append=T)}
if(class(estimates3b)!="try-error"){sim.results3b[,r] <- c(estimates3b$results$psi)}else{
  cat("Note: error in estimating estimates3b -> no estimate saved \n")
  write(matrix(paste("Note: error in estimating estimates3b -> no estimate saved ")),file=paste(getwd(),"/sim_progress.txt",sep=""),append=T)}
if(class(estimates4)!="try-error"){sim.results4[,r] <- c(estimates4$results$psi)}else{
  cat("Note: error in estimating estimates4 -> no estimate saved \n")
  write(matrix(paste("Note: error in estimating estimates4 -> no estimate saved ")),file=paste(getwd(),"/sim_progress.txt",sep=""),append=T)}
if(class(estimates4b)!="try-error"){sim.results4b[,r] <- c(estimates4b$results$psi)}else{
  cat("Note: error in estimating estimates 4b -> no estimate saved \n")
  write(matrix(paste("Note: error in estimating estimates4b -> no estimate saved ")),file=paste(getwd(),"/sim_progress.txt",sep=""),append=T)}

#
sim.results <- list(sim.results1,sim.results2,sim.results3,sim.results4,
                    sim.results1b,sim.results2b,sim.results3b,sim.results4b,
                    diag.results_crude,diag.results_cond, SL.weights, wm.d, wm.b)

save(sim.results,file=paste(getwd(),"/tempresults.Rdata",sep=""))
})



####################
# Evaluate Results #
####################

# Preliminaries
ptm2 <-  proc.time()
simulationsdauer <- ptm2-ptm
simulationsdauer <- (simulationsdauer/60)/60
simulationsdauer <- round(simulationsdauer[3], digits=2)
cat(paste("The simulation time was", simulationsdauer, "hours \n"))
finaltime <-  paste("The simulation time was", simulationsdauer, "hours")

any.problem_1<- round(mean(apply(apply(sim.results1,2,is.na),2,mean)), digits=4)*100
any.problem_2<- round(mean(apply(apply(sim.results2,2,is.na),2,mean)), digits=4)*100
any.problem_3<- round(mean(apply(apply(sim.results3,2,is.na),2,mean)), digits=4)*100
any.problem_4<- round(mean(apply(apply(sim.results4,2,is.na),2,mean)), digits=4)*100
any.problem_2b<- round(mean(apply(apply(sim.results2,2,is.na),2,mean)), digits=4)*100
any.problem_3b<- round(mean(apply(apply(sim.results3,2,is.na),2,mean)), digits=4)*100
any.problem_4b<- round(mean(apply(apply(sim.results4,2,is.na),2,mean)), digits=4)*100


# Table 1: Simulation Info
Info <- matrix(rbind("This is simulation no. 3",
                     paste("Simulation time:", simulationsdauer, "hours"),
                     paste("Number of simulation runs:",runs),
                     paste("Sample size:", N),
                     paste("Number of interventions",n.int),
                     paste("Number of methods:",4),
                     paste("% estimates with problems - per approach:",any.problem_1, ",",any.problem_2, ",",any.problem_3, ",",any.problem_4, ",",any.problem_2b, ",",any.problem_3b, ",",any.problem_4b)
),dimnames=NULL)
colnames(Info) <- "Setup"
rownames(Info) <- NULL
mytable1 <- xtable(Info, caption='Simulation details')
print(mytable1,file=paste(getwd(),"/Results_sim3.tex",sep=""),table.placement="H",include.rownames=FALSE)

############################
# Part 1: standard g-comp. #
############################

# Calculate Bias
# Bias wrt counterfactual quantity
estimated_psi1 <- apply(sim.results1,1,mean,na.rm=T)
MC_err_psi1  <- (apply(sim.results1,1,sd,na.rm=T))/(sqrt(runs))
BIAS1 <- psi_true$psi - estimated_psi1

BIAS1 <- as.data.frame(cbind(psi_true$times,psi_true$Int,psi_true$psi,estimated_psi1,BIAS1))
colnames(BIAS1) <- c("Timepoint","Intervention", "psi","est.","BIAS")
BIAS1$MC_err <-  MC_err_psi1

mytable2 <- xtable(BIAS1, caption='Bias, by intervention and time point')
suppressWarnings(print(mytable2,file=paste(getwd(),"/Results_sim3_2.tex",sep=""),
                       caption.placement = "top",include.rownames=FALSE,tabular.environment="longtable"))

# visualize bias
for(i in 0:4){
  pdf(file=paste(getwd(),"/fig_psi_causal_",i,".pdf",sep=""))
  plot(BIAS1$Intervention[BIAS1$Timepoint==i],BIAS1$psi[BIAS1$Timepoint==i],type="l",lwd=2,ylim=c(round(min(BIAS1$psi),digits=1)-0.1,round(max(BIAS1$psi),digits=1)+0.1),xlab="Intervention",ylab="")
  lines(BIAS1$Intervention[BIAS1$Timepoint==i],BIAS1$est[BIAS1$Timepoint==i],type="l",lwd=2,col="blue")
  lines(BIAS1$Intervention[BIAS1$Timepoint==i],BIAS1$BIAS[BIAS1$Timepoint==i],type="l",lwd=2,col="orange",lty=2)
  abline(a=0,b=0,col="gray",lwd=1)
  legend("top",col=c("black","blue","orange"),lty=c(1,1,2),legend=c("true","estimated","BIAS"),bty="n",lwd=c(2,2,2))
  dev.off()
}

# Plot dose response curves
psi_est <- BIAS1[,c("Timepoint","Intervention")]
psi_est$psi <- estimated_psi1
psi_est$Method <- "estimated"
psi2 <- as.data.frame(psi_true)
colnames(psi2) <- c("psi","Timepoint","Intervention")
psi2$Method <- "true"
psi2 <- psi2[,c("Timepoint","Intervention","psi","Method")]
psi_summary <- rbind(psi_est,psi2)
mycols <-  c("black", "orangered3")

for(j in 0:t.end){
  rel_bias_GLM <- mean(abs(BIAS1$BIAS[BIAS1$Timepoint==j]))
  assign(paste("gg",j,sep=""), ggplot(psi_summary[psi_summary$Timepoint==j,], aes(x=Intervention,y=psi,col=Method))  + geom_point() +
           theme_bw() +
           scale_x_continuous("Intervention", breaks=c(seq(min(a.int),max(a.int),length.out=5))) +
           scale_y_continuous(expression(psi)) +
           guides(fill = guide_legend(keywidth = 2, keyheight = 2, title="Time")) +
           labs(title=paste("Dose-response curves for different methods at time", j),
                subtitle=paste("Mean absolue bias =",round(rel_bias_GLM,digits=2)))  +
           theme(axis.title.x = element_text(size=13), axis.text.x = element_text(size=13),axis.title.y = element_text(size=13, angle = 90),
                 axis.text.y = element_text(size=13), legend.text =  element_text(size=13), legend.title = element_text(size=13, face = "bold", hjust = 0),legend.position =   "bottom") +
           scale_colour_manual(name = 'Methods', values = mycols) + guides(col=guide_legend(ncol=2))
  )
  pdf(file=paste(getwd(),"/fig_psi_causal_alt",j,".pdf",sep=""))
  plot(get(paste("gg",j,sep="")))
  dev.off()
}


################
# Part 2: SGF  #
################

# Preliminary: ML algorithms
mlt <- as.data.frame(matrix(NA,nrow=length(ml),ncol=6))
for(i in 1:6){mlt[,i]<-apply(SL.weights[[i]],1,mean,na.rm=T)}
rownames(mlt) <- rownames(SL.weights[[1]])
colnames(mlt)<-c("c=1,b","c=1,d","c=0.01,b","c=0.01,d","c=0.001,b","c=0.001,d")
mytable_3 <- xtable(mlt, caption='Learning and screening algorithms used in super learning')
print(mytable_3,file=paste(getwd(),"/Results_sim3_3.tex",sep=""),
      caption.placement = "top",include.rownames=TRUE, scalebox=0.8)

# Preliminary 2: outcome weights summary
divide_runs   <- function(mat, r){mat/r}
weights_b_1   <- lapply(weights_b_1,divide_runs,   r=runs)
weights_b_01  <- lapply(weights_b_01,divide_runs,  r=runs)
weights_b_001 <- lapply(weights_b_001,divide_runs, r=runs)
weights_d_1   <- lapply(weights_d_1,divide_runs,   r=runs)
weights_d_01  <- lapply(weights_d_01,divide_runs,  r=runs)
weights_d_001 <- lapply(weights_d_001,divide_runs, r=runs)
mn <- c("b","d"); cn <- c("1","01","001") 

for(cind in 1:3){
 for(method in 1:2){
   for(t in 1:(t.end+1)){
     obj <- get(paste0("weights_",mn[method],"_",cn[cind]))
        print(xtable(obj[[t]],
                     caption=paste("Weights: method =",mn[method],"and c = ",cn[cind], " and t =", t)),
              file=paste(getwd(),"/Results_weights_",mn[method],cn[cind],"_",t,".tex",sep=""),
              caption.placement = "top",include.rownames=TRUE, scalebox=0.6, table.placement="H"
              )
}}}

# a) with c=1
# Calculate Bias
# Bias wrt counterfactual quantity

### density estimation with binning
estimated_psi2 <- apply(sim.results2,1,mean,na.rm=T)
MC_err_psi2  <- (apply(sim.results2,1,sd,na.rm=T))/(sqrt(runs))
BIAS2 <- psi_true_preint$psi - estimated_psi2

BIAS2 <- as.data.frame(cbind(psi_true_preint$times,psi_true_preint$Int,psi_true_preint$psi,estimated_psi2,BIAS2))
colnames(BIAS2) <- c("Timepoint","Intervention", "psi","est.","BIAS")
BIAS2$MC_err <-  MC_err_psi2

mytable4<- xtable(BIAS2, caption='Bias, by intervention and time point')
suppressWarnings(print(mytable4,file=paste(getwd(),"/Results_sim3_4.tex",sep=""),
                       caption.placement = "top",include.rownames=FALSE,tabular.environment="longtable"))

# Plot estimates and true curves
psi_est <- BIAS2[,c("Timepoint","Intervention")]
psi_est$psi <- estimated_psi2
psi_est$Method <- "estimated"
psi2 <- as.data.frame(psi_true_preint)
colnames(psi2) <- c("psi","Timepoint","Intervention")
psi2$Method <- "true"
psi2 <- psi2[,c("Timepoint","Intervention","psi","Method")]
psi_summary <- rbind(psi_est,psi2)
mycols <-  c("black", "orangered3")

for(j in 0:2){
  rel_bias_GLM <- mean(abs(BIAS2$BIAS[BIAS2$Timepoint==j]),na.rm=T)
  assign(paste("gg",j,sep=""), ggplot(psi_summary[psi_summary$Timepoint==j,], aes(x=Intervention,y=psi,col=Method))  + geom_point() +
           theme_bw() +
           scale_x_continuous("Intervention", breaks=c(seq(min(a.int),max(a.int),length.out=5))) +
           scale_y_continuous(expression(psi), breaks=c(seq(0,1,0.1))) +
           guides(fill = guide_legend(keywidth = 2, keyheight = 2, title="Time")) +
           labs(title=paste("Dose-response curves for different methods at time", j),
                subtitle=paste("Mean absolue bias =",round(rel_bias_GLM,digits=2)))  +
           theme(axis.title.x = element_text(size=13), axis.text.x = element_text(size=13),axis.title.y = element_text(size=13, angle = 90),
                 axis.text.y = element_text(size=13), legend.text =  element_text(size=13), legend.title = element_text(size=13, face = "bold", hjust = 0),legend.position =   "bottom") +
           scale_colour_manual(name = 'Methods', values = mycols) + guides(col=guide_legend(ncol=2))
  )
  pdf(file=paste(getwd(),"/fig_psi_preint_alt",j,".pdf",sep=""))
  plot(get(paste("gg",j,sep="")))
  dev.off()
}

### parametric density estimation
estimated_psi2b <- apply(sim.results2b,1,mean,na.rm=T)
MC_err_psi2b  <- (apply(sim.results2b,1,sd,na.rm=T))/(sqrt(runs))
BIAS2b <- psi_true_preint$psi - estimated_psi2b

BIAS2b <- as.data.frame(cbind(psi_true_preint$times,psi_true_preint$Int,psi_true_preint$psi,estimated_psi2b,BIAS2b))
colnames(BIAS2b) <- c("Timepoint","Intervention", "psi","est.","BIAS")
BIAS2b$MC_err <-  MC_err_psi2b

mytable4b<- xtable(BIAS2b, caption='Bias, by intervention and time point')
suppressWarnings(print(mytable4b,file=paste(getwd(),"/Results_sim3_4b.tex",sep=""),
                       caption.placement = "top",include.rownames=FALSE,tabular.environment="longtable"))

psi_estb <- BIAS2b[,c("Timepoint","Intervention")]
psi_estb$psi <- estimated_psi2b
psi_estb$Method <- "estimated"
psib_summary <- rbind(psi_estb,psi2)

for(j in 0:2){
  rel_bias_GLM <- mean(abs(BIAS2b$BIAS[BIAS2b$Timepoint==j]),na.rm=T)
  assign(paste("gg",j,sep=""), ggplot(psib_summary[psib_summary$Timepoint==j,], aes(x=Intervention,y=psi,col=Method))  + geom_point() +
           theme_bw() +
           scale_x_continuous("Intervention", breaks=c(seq(min(a.int),max(a.int),length.out=5))) +
           scale_y_continuous(expression(psi), breaks=c(seq(0,1,0.1))) +
           guides(fill = guide_legend(keywidth = 2, keyheight = 2, title="Time")) +
           labs(title=paste("Dose-response curves for different methods at time", j),
                subtitle=paste("Mean absolue bias =",round(rel_bias_GLM,digits=2)))  +
           theme(axis.title.x = element_text(size=13), axis.text.x = element_text(size=13),axis.title.y = element_text(size=13, angle = 90),
                 axis.text.y = element_text(size=13), legend.text =  element_text(size=13), legend.title = element_text(size=13, face = "bold", hjust = 0),legend.position =   "bottom") +
           scale_colour_manual(name = 'Methods', values = mycols) + guides(col=guide_legend(ncol=2))
  )
  pdf(file=paste(getwd(),"/fig_psi_preint_alt",j,"b.pdf",sep=""))
  plot(get(paste("gg",j,sep="")))
  dev.off()
}


### b) summary for all c's

# binning information, c=0.01
estimated_psi3 <- apply(sim.results3,1,mean,na.rm=T)
MC_err_psi3  <- (apply(sim.results3,1,sd,na.rm=T))/(sqrt(runs))
BIAS3 <- psi_true$psi - estimated_psi3

BIAS3 <- as.data.frame(cbind(psi_true$times,psi_true$Int,psi_true$psi,estimated_psi3,BIAS3))
colnames(BIAS3) <- c("Timepoint","Intervention", "psi","est.","BIAS")
BIAS3$MC_err <-  MC_err_psi3

# binning information, c=0.01
estimated_psi4 <- apply(sim.results4,1,mean,na.rm=T)
MC_err_psi4  <- (apply(sim.results4,1,sd,na.rm=T))/(sqrt(runs))
BIAS4 <- psi_true$psi - estimated_psi4

BIAS4 <- as.data.frame(cbind(psi_true$times,psi_true$Int,psi_true$psi,estimated_psi4,BIAS4))
colnames(BIAS4) <- c("Timepoint","Intervention", "psi","est.","BIAS")
BIAS4$MC_err <-  MC_err_psi4

# parametric information, c=0.01
estimated_psi3b <- apply(sim.results3b,1,mean,na.rm=T)
MC_err_psi3b  <- (apply(sim.results3b,1,sd,na.rm=T))/(sqrt(runs))
BIAS3b <- psi_true$psi - estimated_psi3b

BIAS3b <- as.data.frame(cbind(psi_true$times,psi_true$Int,psi_true$psi,estimated_psi3b,BIAS3b))
colnames(BIAS3b) <- c("Timepoint","Intervention", "psi","est.","BIAS")
BIAS3b$MC_err <-  MC_err_psi3b

# parametric information, c=0.001
estimated_psi4b <- apply(sim.results4b,1,mean,na.rm=T)
MC_err_psi4b  <- (apply(sim.results4b,1,sd,na.rm=T))/(sqrt(runs))
BIAS4b <- psi_true$psi - estimated_psi4b

BIAS4b <- as.data.frame(cbind(psi_true$times,psi_true$Int,psi_true$psi,estimated_psi4b,BIAS4b))
colnames(BIAS4b) <- c("Timepoint","Intervention", "psi","est.","BIAS")
BIAS4b$MC_err <-  MC_err_psi4b

# actual summary
all_res <- rbind(BIAS1,BIAS2,BIAS3,BIAS4)
all_res$method <- c(rep("naive",nrow(BIAS1)),rep("weighted (c=1)",nrow(BIAS2)),rep("weighted (c=0.01)",nrow(BIAS3)),rep("weighted (c=0.001)",nrow(BIAS4)))
all_res2 <- rbind(BIAS1,BIAS2b,BIAS3b,BIAS4b)
all_res2$method <- c(rep("naive",nrow(BIAS1)),rep("weighted (c=1)",nrow(BIAS2)),rep("weighted (c=0.01)",nrow(BIAS3)),rep("weighted (c=0.001)",nrow(BIAS4)))


pdf(file=paste(getwd(),"/fig_psi_summary.pdf",sep=""), width=10)
ggplot(all_res, aes(x=Intervention, y=est., col=method)) + geom_line() + facet_wrap(~.~Timepoint) +   theme_bw() +
  scale_x_continuous("Intervention", breaks=c(seq(min(a.int),max(a.int),length.out=5))) +
  scale_y_continuous(expression(psi)) +
  guides(fill = guide_legend(keywidth = 2, keyheight = 2, title="METHODS")) +
  coord_cartesian(ylim= c(0,0.5) ) +
  labs(title=paste("Dose-response curves for different methods at different times"))  +
  theme(axis.title.x = element_text(size=13), axis.text.x = element_text(size=13),axis.title.y = element_text(size=13, angle = 90),
        axis.text.y = element_text(size=13), legend.text =  element_text(size=13), legend.title = element_text(size=13, face = "bold", hjust = 0),legend.position =   "bottom") +
  scale_colour_manual(name = 'Methods', values = c(mycols,"blue","gold")) + guides(col=guide_legend(ncol=1))
dev.off()

pdf(file=paste(getwd(),"/fig_psi_summary_b.pdf",sep=""), width=10)
ggplot(all_res2, aes(x=Intervention, y=est., col=method)) + geom_line() + facet_wrap(~.~Timepoint) +   theme_bw() +
  scale_x_continuous("Intervention", breaks=c(seq(min(a.int),max(a.int),length.out=5))) +
  scale_y_continuous(expression(psi)) +
  guides(fill = guide_legend(keywidth = 2, keyheight = 2, title="METHODS")) +
  coord_cartesian(ylim= c(0,0.5) ) + labs(title=paste("Dose-response curves for different methods at different times"))  +
  theme(axis.title.x = element_text(size=13), axis.text.x = element_text(size=13),axis.title.y = element_text(size=13, angle = 90),
        axis.text.y = element_text(size=13), legend.text =  element_text(size=13), legend.title = element_text(size=13, face = "bold", hjust = 0),legend.position =   "bottom") +
  scale_colour_manual(name = 'Methods', values = c(mycols,"blue","gold")) + guides(col=guide_legend(ncol=1))
dev.off()


###################
# Part 3: support #
###################

crude_support <- apply(diag.results_crude,1,mean, na.rm=T)
cond_support <- apply(diag.results_cond,1,mean, na.rm=T)

crude_support_summary <- cbind(expand.grid(rownames(estimates$diagnostics$crude_support),1:5),crude_support)
cond_support_summary <- cbind(expand.grid(rownames(estimates$diagnostics$conditional_support),1:5),cond_support)
colnames(crude_support_summary)[1:2]  <- colnames(cond_support_summary)[1:2] <- c("Intervention","Time")
crude_support_summary$Intervention <- as.numeric(paste(crude_support_summary$Intervention))
cond_support_summary$Intervention <- as.numeric(paste(cond_support_summary$Intervention))

pdf(file=paste(getwd(),"/fig_crude_support.pdf",sep=""), width=10)
ggplot(crude_support_summary, aes(x=Intervention, y=crude_support)) + geom_tile(aes(height=0.005,fill=as.factor(Time))) + facet_wrap(Time~.) +   theme_bw() +
  scale_x_continuous("Intervention", breaks=c(seq(min(a.int),max(a.int),length.out=5))) +
  scale_y_continuous("crude support") +
  guides(fill = guide_legend(keywidth = 2, keyheight = 2, title="time point")) +
  labs(title=paste("Crude support at different timepoints"))  +
  theme(axis.title.x = element_text(size=13), axis.text.x = element_text(size=13),axis.title.y = element_text(size=13, angle = 90),
        axis.text.y = element_text(size=13), legend.text =  element_text(size=10), legend.title = element_text(size=10, face = "bold", hjust = 0),legend.position =   "bottom") +
  guides(col=guide_legend(ncol=1)) +
  theme(legend.position="none")
dev.off()


pdf(file=paste(getwd(),"/fig_cond_support.pdf",sep=""), width=10)
ggplot(cond_support_summary, aes(x=Intervention, y=crude_support)) + geom_tile(aes(height=0.005,fill=as.factor(Time))) + facet_wrap(Time~.) +   theme_bw() +
  scale_x_continuous("Intervention", breaks=c(seq(min(a.int),max(a.int),length.out=5))) +
  scale_y_continuous("conditional support") +
  guides(fill = guide_legend(keywidth = 2, keyheight = 2, title="time point")) +
  labs(title=paste("Conditional support at different timepoints"))  +
  theme(axis.title.x = element_text(size=13), axis.text.x = element_text(size=13),axis.title.y = element_text(size=13, angle = 90),
        axis.text.y = element_text(size=13), legend.text =  element_text(size=10), legend.title = element_text(size=10, face = "bold", hjust = 0),legend.position =   "bottom") +
  guides(col=guide_legend(ncol=1)) +
  theme(legend.position="none")
dev.off()

## Support illustration through weight summary 
extract.pno <- function(mat){mat$pno}
wm.dc <- data.frame(wm.d[[1]][,1:3], pno=apply(do.call("cbind",lapply(wm.d, extract.pno)),1,mean, na.rm=T))
wm.dc$Intervention <- as.factor(wm.dc$Intervention)

wm2 <- data.frame(
  wm.dc[wm.dc$Time=="1",1:2],      
  pno=apply(do.call("cbind",split(wm.dc$pno, wm.dc$Time)),1,mean)
)

coul <- brewer.pal(4, "PiYG") 
coul <- colorRampPalette(coul)(23)

pdf(file=paste(getwd(),"/fig_support_weights1.pdf",sep=""), width=10)
ggplot(wm2, aes(x=c, y=pno, colour=Intervention))  + 
  geom_point(size=3) + geom_line(linewidth=1.1,linetype=2) + 
  theme_bw() +
  scale_x_continuous(trans='log10') + scale_y_continuous("% of weights unequal 1")+
  theme(axis.title.x = element_text(size=16), axis.text.x = element_text(size=16),axis.title.y = element_text(size=16, angle = 90),
        axis.text.y = element_text(size=16), plot.title = element_text(size=18), legend.text =  element_text(size=18), legend.title = element_text(size=18, face = "bold", hjust = 0),legend.position =   "bottom",
        strip.text.x = element_text(size = 14)) +
  scale_colour_manual('Concentration values', values = coul)
dev.off()


wm3<-wm2; wm3$c <- as.factor(wm3$c); wm3$Intervention <- as.numeric(paste(wm3$Intervention))

pdf(file=paste(getwd(),"/fig_support_weights2.pdf",sep=""), width=10)
ggplot(wm3, aes(x=Intervention, y=pno, colour=c, group=c))  + 
  geom_point(size=3) + geom_line(linewidth=1.1,linetype=2) + 
  theme_bw() +
  scale_y_continuous("% of weights unequal 1")+
  theme(axis.title.x = element_text(size=16), axis.text.x = element_text(size=16),axis.title.y = element_text(size=16, angle = 90),
        axis.text.y = element_text(size=16), plot.title = element_text(size=18), legend.text =  element_text(size=18), legend.title = element_text(size=18, face = "bold", hjust = 0),legend.position =   "bottom",
        strip.text.x = element_text(size = 14)) +
  scale_colour_brewer('Concentration values', palette="PiYG")  
dev.off()

#############################
# Part 4: Figures for paper #
#############################
estimated_psi1 <- apply(sim.results1,1,mean,na.rm=T)
BIAS1 <- psi_true$psi - estimated_psi1
BIAS1 <- as.data.frame(cbind(psi_true$times,psi_true$Int,psi_true$psi,estimated_psi1,BIAS1))
colnames(BIAS1) <- c("Timepoint","Intervention", "psi","est.","BIAS")

psi_est <- BIAS1[,c("Timepoint","Intervention")]
psi_est$psi <- estimated_psi1
psi_est$Method <- "estimated"
psi2 <- as.data.frame(psi_true)
colnames(psi2) <- c("psi","Timepoint","Intervention")
psi2$Method <- "true"
psi2 <- psi2[,c("Timepoint","Intervention","psi","Method")]
psi3 <- BIAS1
psi3$psi <- psi3$BIAS
psi3 <- psi3[,c("Timepoint","Intervention","psi")]
psi3$Method <- "bias"
psi_summary <- rbind(psi_est,psi2,psi3)



j=1 # for second time point
assign(paste("gg",j,sep=""),
       ggplot(psi_summary[psi_summary$Timepoint==j,], aes(x=Intervention,y=psi,col=Method))  + 
         geom_point(alpha=0.5, size=3) +
         geom_line(linetype=2, size=1.1) +
         theme_bw() +
         scale_x_continuous("Intervention", breaks=c(seq(0,10,2.5))) +
         scale_y_continuous(expression(psi)) +
         guides(fill = guide_legend(keywidth = 2, keyheight = 2, title="Time")) +
         labs(title=paste("Dose-response curve at time", j+1))  +
         theme(axis.title.x = element_text(size=16), axis.text.x = element_text(size=16),axis.title.y = element_text(size=16, angle = 90),
               axis.text.y = element_text(size=16), plot.title = element_text(size=18), legend.text =  element_text(size=18), legend.title = element_text(size=18, face = "bold", hjust = 0),legend.position =   "bottom") +
         scale_colour_manual(name = 'Methods', values = c("red","blue","black")) + guides(col=guide_legend(ncol=3))
)
pdf(file=paste(getwd(),"/fig5c.pdf",sep=""), width=9)
plot(get(paste("gg",j,sep="")))
dev.off()


j=4 # for fifth time point
assign(paste("gg",j,sep=""),
       ggplot(psi_summary[psi_summary$Timepoint==j,], aes(x=Intervention,y=psi,col=Method))  + 
         geom_point(alpha=0.5, size=3) +
         geom_line(linetype=2, size=1.1) +
         theme_bw() +
         scale_x_continuous("Intervention", breaks=c(seq(0,10,2.5))) +
         scale_y_continuous(expression(psi)) +
         guides(fill = guide_legend(keywidth = 2, keyheight = 2, title="Time")) +
         labs(title=paste("Dose-response curve at time", j+1))  +
         theme(axis.title.x = element_text(size=16), axis.text.x = element_text(size=16),axis.title.y = element_text(size=16, angle = 90),
               axis.text.y = element_text(size=16), plot.title = element_text(size=18), legend.text =  element_text(size=18), legend.title = element_text(size=18, face = "bold", hjust = 0),legend.position =   "bottom") +
         scale_colour_manual(name = 'Methods', values = c("red","blue","black")) + guides(col=guide_legend(ncol=3))
)
pdf(file=paste(getwd(),"/fig2d.pdf",sep=""), width=9)
plot(get(paste("gg",j,sep="")))
dev.off()


# 
estimated_psi2 <- apply(sim.results2,1,mean,na.rm=T)
BIAS2 <- psi_true_preint$psi - estimated_psi2
BIAS2 <- as.data.frame(cbind(psi_true_preint$times,psi_true_preint$Int,psi_true_preint$psi,estimated_psi2,BIAS2))
colnames(BIAS2) <- c("Timepoint","Intervention", "psi","est.","BIAS")

estimated_psi2b <- apply(sim.results2b,1,mean,na.rm=T)
BIAS2b <- psi_true_preint$psi - estimated_psi2b
BIAS2b <- as.data.frame(cbind(psi_true_preint$times,psi_true_preint$Int,psi_true_preint$psi,estimated_psi2b,BIAS2b))
colnames(BIAS2b) <- c("Timepoint","Intervention", "psi","est.","BIAS")

p1 <- BIAS2[,c("Timepoint","Intervention","est.")]
p2 <- BIAS2b[,c("Timepoint","Intervention","est.")]
p3 <- BIAS2[,c("Timepoint","Intervention","psi")]
colnames(p1)[3] <- colnames(p2)[3] <- colnames(p3)[3] <- "psi"
p1$Method <- "density estimation: binning"
p2$Method <- "density estimation: parametric"
p3$Method <- "true"
psib_summary <- rbind(p1,p2,p3)

j=0 # t=1
assign(paste("gg",j,sep=""), 
       ggplot(psib_summary[psib_summary$Timepoint==j ,],
              aes(x=Intervention,y=psi,col=Method)) +
         geom_point(alpha=0.5, size=3) +
         geom_line(linetype=2, size=1.1) +
         coord_cartesian(ylim=c(0,0.25)) +
         theme_bw() +
         scale_x_continuous("Intervention") +
         scale_y_continuous(expression("E(" ~ Y[1] ~"|"  ~ A[1] ~ "=" ~ a[1] ~  ")")) + 
         guides(fill = guide_legend(keywidth = 2, keyheight = 2, title="Time")) +
         labs(title=paste("Dose-response curve at time", j+1))  +
         theme(axis.title.x = element_text(size=16), axis.text.x = element_text(size=16),axis.title.y = element_text(size=16, angle = 90),
               axis.text.y = element_text(size=16), plot.title = element_text(size=18), legend.text =  element_text(size=18), legend.title = element_text(size=18, face = "bold", hjust = 0),legend.position =   "bottom") +
         scale_colour_manual(name = '', values = c("red","blue","black")) + guides(col=guide_legend(ncol=2))
)

pdf(file=paste(getwd(),"/fig2e.pdf",sep=""),width=9)
plot(get(paste("gg",j,sep="")))
dev.off()

j=1 # t=2
assign(paste("gg",j,sep=""), 
       ggplot(psib_summary[psib_summary$Timepoint==j,],
              aes(x=Intervention,y=psi,col=Method)) +
         geom_point(alpha=0.5, size=3) +
         geom_line(linetype=2, size=1.1) +
         coord_cartesian(ylim=c(0,0.25)) +
         theme_bw() +
         scale_x_continuous("Intervention") +
         scale_y_continuous(expression("E(" ~ Y[2] ~"|" ~ A[2] ~ "=" ~ a[2] ~ "," ~ A[1] ~ "=" ~ a[1] ~  ")")) +
         guides(fill = guide_legend(keywidth = 2, keyheight = 2, title="Time")) +
         labs(title=paste("Dose-response curve at time", j+1))  +
         theme(axis.title.x = element_text(size=16), axis.text.x = element_text(size=16),axis.title.y = element_text(size=16, angle = 90),
               axis.text.y = element_text(size=16), plot.title = element_text(size=18), legend.text =  element_text(size=18), legend.title = element_text(size=18, face = "bold", hjust = 0),legend.position =   "bottom") +
         scale_colour_manual(name = '', values = c("red","blue","black")) + guides(col=guide_legend(ncol=3))
)

pdf(file=paste(getwd(),"/fig5d.pdf",sep=""),width=9)
plot(get(paste("gg",j,sep="")))
dev.off()

#
estimated_psi3b <- apply(sim.results3b,1,mean,na.rm=T)
BIAS3b <- psi_true$psi - estimated_psi3b
BIAS3b <- as.data.frame(cbind(psi_true$times,psi_true$Int,psi_true$psi,estimated_psi3b,BIAS3b))
colnames(BIAS3b) <- c("Timepoint","Intervention", "psi","est.","BIAS")

estimated_psi4b <- apply(sim.results4b,1,mean,na.rm=T)
BIAS4b <- psi_true$psi - estimated_psi4b
BIAS4b <- as.data.frame(cbind(psi_true$times,psi_true$Int,psi_true$psi,estimated_psi4b,BIAS4b))
colnames(BIAS4b) <- c("Timepoint","Intervention", "psi","est.","BIAS")

all_res2 <- rbind(BIAS1,BIAS2b,BIAS3b,BIAS4b)
all_res2$method <- c(rep("naive",nrow(BIAS1)),rep("weighted (c=1)",nrow(BIAS2b)),rep("weighted (c=0.01)",nrow(BIAS3b)),rep("weighted (c=0.001)",nrow(BIAS4b)))


j=4
pdf(file=paste(getwd(),"/fig2f.pdf",sep=""),width=9)
ggplot(all_res2[all_res2$Timepoint==j,], aes(x=Intervention, y=est., col=method)) + 
  geom_point(alpha=0.5, size=3) +
  geom_line(linetype=2,size=1.1) +   theme_bw() +
  scale_x_continuous("Intervention", breaks=c(seq(min(a.int),max(a.int),length.out=5))) +
  scale_y_continuous(expression(psi)) +
  guides(fill = guide_legend(keywidth = 2, keyheight = 2, title="METHODS")) +
  coord_cartesian(ylim= c(0,0.3) ) + labs(title=paste("Dose-response curve at time",j+1))  +
  theme(axis.title.x = element_text(size=16), axis.text.x = element_text(size=16),axis.title.y = element_text(size=16, angle = 90),
        axis.text.y = element_text(size=16), plot.title = element_text(size=18), legend.text =  element_text(size=18), legend.title = element_text(size=18, face = "bold", hjust = 0),legend.position =   "bottom") +
  scale_colour_manual(name = 'G-computation:', values = c("black","red","blue","gold")) + guides(col=guide_legend(ncol=2))
dev.off()

#
j=1
pdf(file=paste(getwd(),"/fig5e.pdf",sep=""),width=9)
ggplot(all_res2[all_res2$Timepoint==j,], aes(x=Intervention, y=est., col=method)) + 
  geom_point(alpha=0.5, size=3) +
  geom_line(linetype=2,size=1.1) +   theme_bw() +
  scale_x_continuous("Intervention", breaks=c(seq(min(a.int),max(a.int),length.out=5))) +
  scale_y_continuous(expression(psi)) +
  guides(fill = guide_legend(keywidth = 2, keyheight = 2, title="METHODS")) +
  coord_cartesian(ylim= c(0,0.3) ) + labs(title=paste("Dose-response curve at time",j+1))  +
  theme(axis.title.x = element_text(size=16), axis.text.x = element_text(size=16),axis.title.y = element_text(size=16, angle = 90),
        axis.text.y = element_text(size=16), plot.title = element_text(size=18), legend.text =  element_text(size=18), legend.title = element_text(size=18, face = "bold", hjust = 0),legend.position =   "bottom") +
  scale_colour_manual(name = 'G-comp.:', values = c("black","red","blue","gold")) + guides(col=guide_legend(ncol=2))
dev.off()

#
cond_support <- apply(diag.results_cond,1,mean, na.rm=T)
cond_support_summary <- cbind(expand.grid(paste(intervention),1:5),cond_support)
colnames(cond_support_summary)[1:2] <- c("Intervention","Time")
cond_support_summary$Intervention <- as.numeric(paste(cond_support_summary$Intervention))

pdf(file=paste(getwd(),"/fig6c.pdf",sep=""),width=10)
ggplot(cond_support_summary[cond_support_summary$Time<3 & cond_support_summary$Intervention<10,], 
       aes(x=Intervention, y=cond_support)) + 
  geom_tile(aes(height=0.003,width=0.5,fill=as.factor(Time))) + facet_wrap(Time~.) +   theme_bw() +
  scale_x_continuous("Intervention", breaks=c(seq(0,10))) +
  scale_y_continuous("conditional support") +
  coord_cartesian(xlim=c(0,10), ylim=c(0,0.1)) +
  guides(fill = guide_legend(keywidth = 2, keyheight = 2, title="time point")) +
  labs(title=paste("Conditional support at different timepoints"))  +
  theme(axis.title.x = element_text(size=16), axis.text.x = element_text(size=16),axis.title.y = element_text(size=16, angle = 90),
        axis.text.y = element_text(size=16), strip.text.x = element_text(size = 16), plot.title = element_text(size=18), legend.text =  element_text(size=18), legend.title = element_text(size=18, face = "bold", hjust = 0),legend.position =   "bottom") +
  guides(col=guide_legend(ncol=1)) +
  theme(legend.position="none")
dev.off()


