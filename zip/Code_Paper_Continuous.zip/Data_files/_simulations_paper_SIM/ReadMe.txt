# Simulations from Schomaker, McIlleron, Denti, Diaz (2024) 
# "Causal Inference for Continuous Multiple Time Point Interventions"
#
# Files: simulation1_paper.R, simulation2_paper.R, simulation3_paper.R 
# for all 3 simulations: simply place 
# i) simulation file together with 
# ii) screening_algorithms.R, 
# iii) learning_algorithms.R and
# iv) Results_final_simulation_X.tex in the same directory. 
# Change working directory on top of i) and make sure packages of all 3 R-files are installed. 
# Then simply run simulation and all results will be saved automatically in the working directory.  
# Compile the .tex-file (i.e. # iv)) to get a pdf with the summaries of the simulation (after it finished). 
# Note: progress of the simulation will be saved in a .txt file (sim_progress.txt)
