# Example for the estimation algorithm from Table 1 of
# Schomaker, McIlleron, Denti, Diaz (2024)
# "Causal Inference for Multiple Time Point Interventions"

library(CICI)
library(CICIplus)
data(EFV)
EFV.2 <- EFV[,1:11] # restrict data to 2 time points

# automated with CICIplus
w <- calc.weights(X=EFV.2, 
                  Lnodes  = c("sex", "metabolic", "log_age",
                              "NRTI" ,"weight.0","adherence.1","weight.1"),
                  Ynodes  = c("VL.0","VL.1"),
                  Anodes  = c("efv.0","efv.1"),
                  d.method="parametric", abar=c(0,0.5,1),
                  c=c(0.01)
)
summary(w)

est <- sgf(X=EFV.2,
            Lnodes  = c("adherence.1","weight.1"),
            Ynodes  = c("VL.0","VL.1"),
            Anodes  = c("efv.0","efv.1"),
            abar=c(0,0.5,1),
            Yweights = w$`0.01`
)
est
plot(est)

# manual implementation

# Step 0a: interventions are [(0,0),(0.5,0.5),(1,1)]
# Step 0b: define \tilde{Y}_1 = Y_1 = VL.1
Y.tilde.1 <- EFV.2$VL.1
### iteration: t=1
# Step 1a: estimate numerator density g(efv.1 | past)
#          (assuming normality for illustration)
fitted.n.1 <- lm(efv.1 ~ . ,data=subset(EFV.2, select=-VL.1)) 
# Step 1b: estimate denominator density g(efv.1 | past up to efv.0)
fitted.d.1 <- lm(efv.1 ~ sex+metabolic+log_age+NRTI+weight.0+efv.0,data=EFV.2)
# Step 2: set a_1=a_0=0
EFV.2.A <- EFV.2; EFV.2.A[,c("efv.0","efv.1")] <- 0 
# Step 3a: evaluate densities at a=0
eval.n.1 <- dnorm(0,mean=predict(fitted.n.1, newdata=EFV.2.A),sd=summary(fitted.n.1)$sigma)
eval.d.1 <- dnorm(0,mean=predict(fitted.d.1, newdata=EFV.2.A),sd=summary(fitted.d.1)$sigma)
# Step 3b: estimate weights with c=0.01
wf  <- function(num,den,c){as.numeric(num > c) +  as.numeric(num <= c)*(num/den)}
w.1 <- wf(eval.n.1,eval.d.1,c=0.01)
# Step 4: estimate iterated weighted outcome regression 
# (binomial as all wY in 0/1 in this specific case, otherwise gaussian)
mY.1 <- glm(I(Y.tilde.1*w.1) ~ ., data=subset(EFV.2, select=-VL.1), family="binomial") 
# Step 5: predict iterated weighted outcome under intervention
Y.tilde.0 <- predict(mY.1, newdata=EFV.2.A, type="response")
### iteration: t==0
# Step 1a: estimate numerator density g(efv.0 | past)
fitted.n.0 <- lm(efv.0 ~ sex+metabolic+log_age+NRTI+weight.0 ,data=EFV.2) 
# Step 1b: estimate denominator density g(efv.0)
fitted.d.0 <- lm(efv.0 ~ 1 ,data=EFV.2)
# Step 2: set a_0=0 (see above)
# Step 3a: evaluate densities at a=0
eval.n.0 <- dnorm(0,mean=predict(fitted.n.0, newdata=EFV.2.A),sd=summary(fitted.n.0)$sigma)
eval.d.0 <- dnorm(0,mean=predict(fitted.d.0, newdata=EFV.2.A),sd=summary(fitted.d.0)$sigma)
# Step 3b: estimate weights with c=0.01
w.0 <- wf(eval.n.0,eval.d.0,c=0.01)
# Step 4: estimate iterated (unweighted) outcome regression
mY.0 <- glm(Y.tilde.0 ~ sex+metabolic+log_age+NRTI+weight.0+efv.0, data=EFV.2) 
# Step 5: final estimate under intervention
estimate <- weighted.mean(predict(mY.0, newdata=EFV.2.A),w=w.0)
estimate
est$results$psi[4] # identical to package
# Step 6: Repeat steps 1-5 for a=(0.5,0.5) and a=(1,1)
# Step 7: Bootstrapping

