# Simulation 1 from Schomaker, McIlleron, Denti, Diaz (2023)
# "Causal Inference for Multiple Time Point Interventions"
#
# all plots and tables will be saved in the below specified working directory
# progress of the simulation will be saved in a .txt file (sim_progress.txt)
#
# add to your working directory the following files:
# screening_algorithms.R, learning_algorithms.R and Results_final_simulation_1.tex
# Compile the .tex-file to get a pdf with all summaries of the simulation 


setwd("yourpath")
#
library(CICI)     # install.packages("CICI")
library(CICIplus) # see https://github.com/MichaelSchomaker/CICIplus
#
library(simcausal)
library(ggplot2)
library(xtable)
library(SuperLearner)
#
source(paste0(getwd(),"/screening_algorithms.R")) # own screening functions for SuperLearner 
source(paste0(getwd(),"/learning_algorithms.R"))  # own learners for SuperLearner 
#
set.seed(241280)
ptm <- proc.time()

# SETUP
runs          <- 1000    # number of simulation runs
N             <- 1000    # sample size
intervention  <- a.int  <- seq(2,11,1)
n.int         <- length(intervention)     
cpus          <- 8     # number of threads to use for parallelization
#

###########################
# Data generating process #
###########################


# SETUP
t.end <- 2      # number of time points after baseline

# initialize the DAG
D <- DAG.empty()

# everything at baseline (t = 0)
D.base <- D +
  node("L1",
       t = 0,
       distr = "rbern",
       prob=0.3) +
  node("L2",
       t = 0,
       distr = "rnorm",
       mean = 2*L1[0]-1,
       sd = 1) +
  node("A",
       t = 0,
       distr = "rnorm",
       mean = 7 + L1[0] + 0.7*L2[0],
       sd=1 ) +
  node("Y",
       t = 0,
       distr = "rnorm",
       mean = -1 + 0.5*A[0] + 0.5*L2[0],
       sd = 1)

#time-dependent variables at later time-points
D <- D.base +
  node("L1",
       t = 1:t.end,
       distr = "rbern",
       prob = plogis(-4 + L1[t-1] + 0.15*L2[t-1] + 0.15*A[t-1] )) +
  node("L2",
       t = 1:t.end,
       distr = "rnorm",
       mean = 0.5*L1[t]+0.25*L2[t-1]+0.5*A[t-1],
       sd = 1) +
  node("A",
       t = 1:t.end,
       distr = "rnorm",
       mean = A[t-1] + L1[t] - .1*L2[t], 
       sd=0.5) +
  node("Y",
       t = 1:t.end,
       distr = "rnorm",
       mean = -2 + 0.25*A[t] + L2[t] - 0.2*L1[t],
       sd = 0.5)

Dset <- set.DAG(D)

  
# Some observed data
Dset <- simcausal::set.DAG(D)
Odat <- simcausal::sim(DAG = Dset, n = 5000, rndseed = 01111920, wide=T)
summary(Odat)

###################
# Generate Truth  #
###################

int.a.names  <- paste("A.cont.",1:n.int,sep="") # intervention names
int.a.names


# Intervention on the DAG given a continuous interventions
for(j in 0:n.int){
  assign(paste("A.cont.",j,sep=""),c(node("A", t = 0:t.end, distr = "rconst", const=NA)))  # NA because indexing with [j] not possible
}

modify.int.const <- function(int,number){
  int[[5]]$const <- number
  return(int)
}

for(j in 1:length(int.a.names)){  # trick to correctly assign continuous intervention by overwriting default
  for(k in 1:length(0:t.end)){
    assign(paste("A.cont.",j,sep=""), lapply(get(paste("A.cont.",j,sep="")),modify.int.const,number=a.int[j]) )
  }}

for(j in 1:n.int){
  Dset <- Dset + action(int.a.names[j], nodes = get(int.a.names[j])) 
}

# simulate for the intervention
sim.cont <- simcausal::sim(DAG = Dset, actions = int.a.names, n = 1000000, rndseed = 241280) 

Y.names <- colnames(sim.cont[[j]])[sort(c(grep("Y_",colnames(sim.cont[[j]]))))]
for(j in 1:n.int){
  assign(paste("psi",c(1:n.int)[j],sep=""), apply(sim.cont[[j]][,Y.names],2,mean))
}

psi_true <- as.data.frame(cbind(matrix(unlist(mget(paste("psi",c(1:n.int),sep=""))),ncol=1),rep(0:t.end,n.int),rep(a.int, each=(t.end+1))))
colnames(psi_true)[1] <- "psi"
colnames(psi_true)[2] <- "times"
colnames(psi_true)[3] <-  "Int"
psi_true <- psi_true[order(psi_true$times),]
psi_true


# true dose-response curves
mymin <- round(min(psi_true$psi)-1,digits=0)
mymax <- round(max(psi_true$psi)+1,digits=0)
mycolors <- c("black", "orangered3","dodgerblue4", "springgreen3","gold","greenyellow",rainbow(20))
mycols <- mycolors[1:length(unique(psi_true$times))]
psi_true$psi

# a) ggplot
gg.true <- ggplot(psi_true, aes(x=Int,y=psi,col=as.factor(times)))  + geom_line(linewidth=1.3) + theme_bw() +
  scale_color_manual(values = mycols) +
  scale_x_continuous("Intervention", breaks=c(seq(0,15,1))) +
  scale_y_continuous(expression(psi)) +
  guides(fill = guide_legend(keywidth = 2, keyheight = 2, title="Time")) +
  ggtitle("True dose-response curves")  +
  theme(axis.title.x = element_text(size=13), axis.text.x = element_text(size=13),axis.title.y = element_text(size=13, angle = 90),
        axis.text.y = element_text(size=13), legend.text =  element_text(size=13), legend.title = element_text(size=13, face = "bold", hjust = 0),legend.position =   "bottom") +
  guides(col=guide_legend(title="Time"))

pdf(file=paste0(getwd(),"/true_CDRC.pdf"))
plot(gg.true)
dev.off()

#########################################
# TRUTH FOR E(Y|A_t=a_t, ..., a_0=a_0)  #
#########################################

Odat.cont <- simcausal::sim(DAG = Dset, n = 5000000, rndseed = 241280) # lower n is faster, but makes true conditional expectations more imprecise
psi_true_preint <- psi_true; psi_true_preint$psi <- NA
span <- diff(intervention)[1]/2 # a +/- span is considered to be approximately equivalent to a
Ys <- Odat.cont[,grep("Y_",colnames(Odat.cont))]
As <- Odat.cont[,grep("A_",colnames(Odat.cont))]
for(t in 0:t.end){
  for(i in 1:n.int){
    selind <- apply(matrix((As[,1:(t+1)] > a.int[i]-span) & (As[,1:(t+1)] < a.int[i]+span),ncol=t+1),1,all)
    psi_true_preint[psi_true_preint$times==c(0:t.end)[t+1],][i,1] <- mean(Ys[,t+1][selind] ) 
  }}

gg.preint <- ggplot(psi_true_preint[psi_true_preint$Int<20,], aes(x=Int,y=psi,col=as.factor(times)))  + geom_smooth(size=1.3, se=F) + theme_bw() +
  scale_color_manual(values = mycols) +
  scale_x_continuous("Intervention", breaks=c(seq(0,15,1))) +
  scale_y_continuous("E(Y_t|abar_t)") +
  guides(fill = guide_legend(keywidth = 2, keyheight = 2, title="Time")) +
  ggtitle("True associational relationship (where defined, and smoothed)")  +
  theme(axis.title.x = element_text(size=13), axis.text.x = element_text(size=13),axis.title.y = element_text(size=13, angle = 90),
        axis.text.y = element_text(size=13), legend.text =  element_text(size=13), legend.title = element_text(size=13, face = "bold", hjust = 0),legend.position =   "bottom") +
  guides(col=guide_legend(title="Time"))

pdf(file=paste0(getwd(),"/true_obs_DRC.pdf"))
plot(gg.preint)
dev.off()


#################
# simulation    #
#################
# quiet output for below
quiet <- function(x){sink(tempfile());  on.exit(sink()); invisible(force(x))}

# screening and learning algorithms
#
verb=F
make.cramer(nscreen = c(4,6),verbose=verb)
make.glmnet(alpha=c(0.5,1),verbose=verb)
make.glmnet_nVar(nVar=c(4,6,8),verbose=verb,nfolds=c(5,10))
#
verb2=F
make.SL.earth(degree = c(2,5),verbose=verb2)
make.SL.gam(df.gam=c(2,3,4),verbose=verb2)
make.SL.step.interaction(direction=c("both","backward"), verbose=verb2)
make.SL.glmnet(alpha=c(1,0.5),nfolds=c(5,10),verbose=verb2)
#
ml  <-  list(c("SL.mean", "All"),
             c("SL.glm", "All"),
             #
             c("SL.gam_2_10", "screen.cramersv_4"),
             c("SL.gam_4_10", "screen.cramersv_4"),   
             #
             c("SL.glm", "screen.glmnet_1_10_200"),
             c("SL.earth_5", "screen.glmnet_nVar_1_6_10_150"),
             c("SL.gam_2_10", "screen.glmnet_nVar_1_6_10_150"),
             c("SL.step.interaction_backward", "screen.glmnet_nVar_1_4_10_150")
)
base.learners <- c("SL.glmnet_base","SL.gam_base","screen.glmnet_base",
                   "screen.glmnet_nVar_base","SL.earth_base","screen.cramersv_base",
                   "SL.step.interaction_base")

# values of c
cs            <- c(1,0.2,0.1,0.05,0.025,0.01,0.001) 

# matrices  and lists to store results
sim.results1 <- matrix(NA,ncol=runs,nrow=n.int*(t.end+1))
sim.results2 <- matrix(NA,ncol=runs,nrow=n.int*(t.end+1))
sim.results3 <- matrix(NA,ncol=runs,nrow=n.int*(t.end+1))
sim.results4 <- matrix(NA,ncol=runs,nrow=n.int*(t.end+1))
sim.results2b <- matrix(NA,ncol=runs,nrow=n.int*(t.end+1))
sim.results3b <- matrix(NA,ncol=runs,nrow=n.int*(t.end+1))
sim.results4b <- matrix(NA,ncol=runs,nrow=n.int*(t.end+1))
diag.results_crude <- matrix(NA,ncol=runs,nrow=n.int*(t.end+1))
diag.results_cond <- matrix(NA,ncol=runs,nrow=n.int*(t.end+1))
wm.d <- expand.grid(cs,intervention,1:(t.end+1)); wm.b <- wm.d 
wm.d$pno <- wm.b$pno <- NA; colnames(wm.d) <- colnames(wm.b)<- c("c","Intervention","Time","pno")
wm.d <- wm.b <- rep(list(wm.d), runs)

write(matrix("started with simulation..."),file=paste(getwd(),"/sim_progress.txt",sep=""))
# Simulation loop
for(r in 1:runs)try({
  # draw data
  simdat   <- suppressWarnings(simcausal::sim(DAG = Dset, n = N, verbose=F)[,-1])

  cat(paste("This is simulation run number",r, "\n"))
  write(matrix(paste("started with simulation run #",r)),file=paste(getwd(),"/sim_progress.txt",sep=""),append=T)
  
  # Method 1: naive g-formula with model screening
  check.models <- make.model.formulas(simdat,
                                      Lnodes  = c("L1_1","L2_1","L1_2","L2_2"),
                                      Ynodes  = c("Y_0","Y_1","Y_2"),
                                      Anodes  = c("A_0","A_1","A_2"))
  
  glmnet.formulas <- model.formulas.update(check.models$model.names, simdat, with.s=T,pw=F)
  
  estimates <- gformula(X=simdat,
                        Lnodes  = c("L1_1","L2_1","L1_2","L2_2"),
                        Ynodes  = c("Y_0","Y_1","Y_2"),
                        Anodes  = c("A_0","A_1","A_2"),
                        Yform=glmnet.formulas$Ynames, Lform=glmnet.formulas$Lnames, 
                        calc.support = TRUE,
                        abar=intervention, ncores=cpus, verbose=F
  )
  diag.results_crude[,r] <- unlist(c(estimates$diagnostics$crude_support))
  diag.results_cond[,r] <- unlist(c(estimates$diagnostics$conditional_support))
  
  # Method 2: SGF with weights
  w.b <- calc.weights(X=simdat,
                      Lnodes  = c("L1_0","L2_0","L1_1","L2_1","L1_2","L2_2"),
                      Ynodes  = c("Y_0","Y_1","Y_2"),
                      Anodes  = c("A_0","A_1","A_2"),
                      Cnodes=NULL,
                      abar=intervention,c=cs,
                      screen = FALSE, 
                      survival = FALSE, 
                      d.method=c("binning"),
                      z.method=c("density")
  ) 
  
  w.d <- calc.weights(X=simdat,
                      Lnodes  = c("L1_0","L2_0","L1_1","L2_1","L1_2","L2_2"),
                      Ynodes  = c("Y_0","Y_1","Y_2"),
                      Anodes  = c("A_0","A_1","A_2"),
                      Cnodes=NULL,
                      abar=intervention,c=cs,
                      screen = FALSE, 
                      survival = FALSE, 
                      d.method=c("parametric"),
                      z.method=c("density")
  )
  
  # save weight summary
  s.wd <- quiet(summary(w.d))
  s.wb <- quiet(summary(w.b))
  for(i in 1:length(cs)){
    for(j in 1:length(intervention)){
      for(k in 1:(t.end+1)){
        wm.d[[r]]$pno[wm.d[[r]]$c==cs[i] & wm.d[[r]]$Intervention==intervention[j] & wm.d[[r]]$Time==k] <- s.wd[[i]][[k]][1,j]
        wm.b[[r]]$pno[wm.b[[r]]$c==cs[i] & wm.b[[r]]$Intervention==intervention[j] & wm.b[[r]]$Time==k] <- s.wb[[i]][[k]][1,j]
          }}}
  
  # a) c=1
  write(matrix(paste("busy with c=1")),file=paste(getwd(),"/sim_progress.txt",sep=""),append=T)
  #
  estimates2 <- try(sgf(X=simdat,
                    Lnodes  = c("L1_1","L2_1","L1_2","L2_2"),
                    Ynodes  = c("Y_0","Y_1","Y_2"),
                    Anodes  = c("A_0","A_1","A_2"),
                    abar =  intervention, SL.library = ml, SL.export=base.learners,
                    Yweights = w.b$`1`, 
                    ncores=cpus, verbose=FALSE, prog=NULL
  ),silent=TRUE)
  
  estimates2b <- try(sgf(X=simdat,
                     Lnodes  = c("L1_1","L2_1","L1_2","L2_2"),
                     Ynodes  = c("Y_0","Y_1","Y_2"),
                     Anodes  = c("A_0","A_1","A_2"),
                    abar =  intervention, SL.library = ml, SL.export=base.learners,
                    Yweights = w.d$`1`, 
                    ncores=cpus, verbose=FALSE, prog=NULL
  ), silent=TRUE)
  
  # b) c=0.01
  write(matrix(paste("busy with c=0.01")),file=paste(getwd(),"/sim_progress.txt",sep=""),append=T)
  
  estimates3 <- try(sgf(X=simdat,
                    Lnodes  = c("L1_1","L2_1","L1_2","L2_2"),
                    Ynodes  = c("Y_0","Y_1","Y_2"),
                    Anodes  = c("A_0","A_1","A_2"),
                    abar =  intervention, SL.library = ml, SL.export=base.learners,
                    Yweights = w.b$`0.01`, 
                    ncores=cpus, verbose=FALSE, prog=NULL
  ), silent=TRUE)
 
  
  estimates3b <- try(sgf(X=simdat,
                     Lnodes  = c("L1_1","L2_1","L1_2","L2_2"),
                     Ynodes  = c("Y_0","Y_1","Y_2"),
                     Anodes  = c("A_0","A_1","A_2"),
                    abar =  intervention, SL.library = ml, SL.export=base.learners,
                    Yweights = w.d$`0.01`, 
                    ncores=cpus, verbose=FALSE, prog=NULL
  ), silent=TRUE)
  
  # c) c=0.001
  write(matrix(paste("busy with c=0.001")),file=paste(getwd(),"/sim_progress.txt",sep=""),append=T)
  
  estimates4 <- try(sgf(X=simdat,
                    Lnodes  = c("L1_1","L2_1","L1_2","L2_2"),
                    Ynodes  = c("Y_0","Y_1","Y_2"),
                    Anodes  = c("A_0","A_1","A_2"),
                    abar =  intervention, SL.library = ml, SL.export=base.learners,
                    Yweights = w.b$`0.001`, 
                    ncores=cpus, verbose=FALSE, prog=NULL
  ), silent=TRUE)
  
  estimates4b <- try(sgf(X=simdat,
                     Lnodes  = c("L1_1","L2_1","L1_2","L2_2"),
                     Ynodes  = c("Y_0","Y_1","Y_2"),
                     Anodes  = c("A_0","A_1","A_2"),
                    abar =  intervention, SL.library = ml, SL.export=base.learners,
                    Yweights = w.d$`0.001`, 
                    ncores=cpus, verbose=FALSE, prog=NULL
  ), silent=TRUE)
  
  # check errors & store estimates
  if(class(estimates)!="try-error"){sim.results1[,r] <- c(estimates$results$psi)}else{
    cat("Note: error in estimating estimates1 -> no estimate saved \n") 
    write(matrix(paste("Note: error in estimating estimates1 -> no estimate saved ")),file=paste(getwd(),"/sim_progress.txt",sep=""),append=T)}
  if(class(estimates2)!="try-error"){sim.results2[,r] <- c(estimates2$results$psi)}else{
     cat("Note: error in estimating estimates2 -> no estimate saved \n") 
     write(matrix(paste("Note: error in estimating estimates2 -> no estimate saved ")),file=paste(getwd(),"/sim_progress.txt",sep=""),append=T)}
  if(class(estimates2b)!="try-error"){sim.results2b[,r] <- c(estimates2b$results$psi)}else{
    cat("Note: error in estimating estimates2b -> no estimate saved \n")
    write(matrix(paste("Note: error in estimating estimates2b -> no estimate saved ")),file=paste(getwd(),"/sim_progress.txt",sep=""),append=T)}
  if(class(estimates3)!="try-error"){sim.results3[,r] <- c(estimates3$results$psi)}else{
    cat("Note: error in estimating estimates3 -> no estimate saved \n")
    write(matrix(paste("Note: error in estimating estimates3 -> no estimate saved ")),file=paste(getwd(),"/sim_progress.txt",sep=""),append=T)}
  if(class(estimates3b)!="try-error"){sim.results3b[,r] <- c(estimates3b$results$psi)}else{
    cat("Note: error in estimating estimates3b -> no estimate saved \n")
    write(matrix(paste("Note: error in estimating estimates3b -> no estimate saved ")),file=paste(getwd(),"/sim_progress.txt",sep=""),append=T)}
  if(class(estimates4)!="try-error"){sim.results4[,r] <- c(estimates4$results$psi)}else{
    cat("Note: error in estimating estimates4 -> no estimate saved \n")
    write(matrix(paste("Note: error in estimating estimates4 -> no estimate saved ")),file=paste(getwd(),"/sim_progress.txt",sep=""),append=T)}
  if(class(estimates4b)!="try-error"){sim.results4b[,r] <- c(estimates4b$results$psi)}else{
    cat("Note: error in estimating estimates 4b -> no estimate saved \n")
    write(matrix(paste("Note: error in estimating estimates4b -> no estimate saved ")),file=paste(getwd(),"/sim_progress.txt",sep=""),append=T)}
  
  #  save
  sim.results <- list(sim.results1,sim.results2,sim.results3,sim.results4,
                      sim.results2b,sim.results3b,sim.results4b,
                      diag.results_crude,diag.results_cond, wm.d, wm.b)
  save(sim.results,file=paste(getwd(),"/tempresults.Rdata",sep=""))
})

################################################################################

#####################
# Summarize Results #
#####################

# Preliminaries
ptm2 <-  proc.time()
simulationsdauer <- ptm2-ptm
simulationsdauer <- (simulationsdauer/60)/60
simulationsdauer <- round(simulationsdauer[3], digits=2)
cat(paste("The simulation time was", simulationsdauer, "hours \n"))
finaltime <-  paste("The simulation time was", simulationsdauer, "hours")

any.problem_1<- sum(apply(apply(sim.results1,2,is.na),2,any))
any.problem_2<- sum(apply(apply(sim.results2,2,is.na),2,any))
any.problem_2b<- sum(apply(apply(sim.results2b,2,is.na),2,any))
any.problem_3<- sum(apply(apply(sim.results3,2,is.na),2,any))
any.problem_3b<- sum(apply(apply(sim.results3b,2,is.na),2,any))
any.problem_4<- sum(apply(apply(sim.results4,2,is.na),2,any))
any.problem_4b<- sum(apply(apply(sim.results4b,2,is.na),2,any))


# Table 1: Simulation Info
Info <- matrix(rbind("This is simulation no. 1",paste("Number of simulation runs:",runs),
                     paste("Simulation time:", simulationsdauer, "hours"),
                     paste("Sample size:", N),paste("Number of interventions:",n.int), paste("Number of methods:",4), 
                     paste("Problems (>=1 estimates are NA) simulation runs per approach:",any.problem_1, ",",any.problem_2, ",",any.problem_2b, ",",any.problem_3, ",",any.problem_3b, ",",any.problem_4, ",",any.problem_4b)),dimnames=NULL)
colnames(Info) <- "Setup"
rownames(Info) <- NULL
mytable1 <- xtable(Info, caption='Simulation details')
print(mytable1,file=paste(getwd(),"/Results_sim1.tex",sep=""),table.placement="H",include.rownames=FALSE)

###############################
# Part 1: naive g-computation #
###############################

# Calculate Bias
# Bias wrt counterfactual quantity
estimated_psi1 <- apply(sim.results1,1,mean,na.rm=T)
MC_err_psi1  <- (apply(sim.results1,1,sd,na.rm=T))/(sqrt(runs))
BIAS1 <- psi_true$psi - estimated_psi1

BIAS1 <- as.data.frame(cbind(psi_true$times,psi_true$Int,psi_true$psi,estimated_psi1,BIAS1))
colnames(BIAS1) <- c("Timepoint","Intervention", "psi","est.","BIAS")
BIAS1$MC_err <-  MC_err_psi1

mytable2 <- xtable(BIAS1, caption='Bias, by intervention and time point')
suppressWarnings(print(mytable2,file=paste(getwd(),"/Results_sim1_2.tex",sep=""),
                       caption.placement = "top",include.rownames=FALSE,tabular.environment="longtable"))

# visualize bias
for(i in 0:t.end){
  pdf(file=paste(getwd(),"/fig_psi_causal_",i,".pdf",sep=""))
  plot(BIAS1$Intervention[BIAS1$Timepoint==i],BIAS1$psi[BIAS1$Timepoint==i],type="l",lwd=2,ylim=c(round(min(BIAS1$psi),digits=1)-0.1,round(max(BIAS1$psi),digits=1)+0.1),xlab="Intervention",ylab="")
  lines(BIAS1$Intervention[BIAS1$Timepoint==i],BIAS1$est[BIAS1$Timepoint==i],type="l",lwd=2,col="blue")
  lines(BIAS1$Intervention[BIAS1$Timepoint==i],BIAS1$BIAS[BIAS1$Timepoint==i],type="l",lwd=2,col="orange",lty=2)
  abline(a=0,b=0,col="gray",lwd=1)
  legend("top",col=c("black","blue","orange"),lty=c(1,1,2),legend=c("true","estimated","BIAS"),bty="n",lwd=c(2,2,2))
  dev.off()
}

# Plot dose response curves
psi_est <- BIAS1[,c("Timepoint","Intervention")]
psi_est$psi <- estimated_psi1
psi_est$Method <- "estimated"
psi2 <- as.data.frame(psi_true)
colnames(psi2) <- c("psi","Timepoint","Intervention")
psi2$Method <- "true"
psi2 <- psi2[,c("Timepoint","Intervention","psi","Method")]
psi_summary <- rbind(psi_est,psi2)
mycols <-  c("black", "orangered3")

for(j in 0:t.end){
  rel_bias_GLM <- mean(abs(BIAS1$BIAS[BIAS1$Timepoint==j]))
  assign(paste("gg",j,sep=""), ggplot(psi_summary[psi_summary$Timepoint==j,], aes(x=Intervention,y=psi,col=Method))  + geom_point() +
           theme_bw() +
           scale_x_continuous("Intervention", breaks=c(seq(min(a.int),max(a.int),length.out=5))) +
           scale_y_continuous(expression(psi)) +
           guides(fill = guide_legend(keywidth = 2, keyheight = 2, title="Time")) +
           labs(title=paste("Dose-response curves for different methods at time", j),
                subtitle=paste("Mean absolue bias =",round(rel_bias_GLM,digits=2)))  +
           theme(axis.title.x = element_text(size=13), axis.text.x = element_text(size=13),axis.title.y = element_text(size=13, angle = 90),
                 axis.text.y = element_text(size=13), legend.text =  element_text(size=13), legend.title = element_text(size=13, face = "bold", hjust = 0),legend.position =   "bottom") +
           scale_colour_manual(name = 'Methods', values = mycols) + guides(col=guide_legend(ncol=2))
  )
  pdf(file=paste(getwd(),"/fig_psi_causal_alt",j,".pdf",sep=""))
  plot(get(paste("gg",j,sep="")))
  dev.off()
}


################
# Part 2: SGF  #
################

# Preliminary: ML algorithms
mlt <- as.data.frame(matrix(NA,nrow=length(ml),ncol=2))
for(i in 1:length(ml)){mlt[i,]<-ml[[i]]}
colnames(mlt)<-c("algorithm","screening")
mytable_3 <- xtable(mlt, caption='Learning and screening algorithms used in super learning')
print(mytable_3,file=paste(getwd(),"/Results_sim1_3.tex",sep=""),
      caption.placement = "top",include.rownames=FALSE)

# Pre-processing: remove rare invalid results (e.g., binning problems and thus huge weights)
sim.results2[(sim.results2 > 100 | sim.results2 < -20) & is.na(sim.results2)==FALSE] <- NA
sim.results2b[(sim.results2b > 100 | sim.results2b < -20) & is.na(sim.results2b)==FALSE] <- NA
sim.results3[(sim.results3 > 100 | sim.results3 < -20) & is.na(sim.results3)==FALSE] <- NA
sim.results3b[(sim.results3b > 100 | sim.results3b < -20) & is.na(sim.results3b)==FALSE] <- NA
sim.results4[(sim.results4 > 100 | sim.results4 < -20) & is.na(sim.results4)==FALSE] <- NA
sim.results4b[(sim.results4b > 100 | sim.results4b < -20) & is.na(sim.results4b)==FALSE] <- NA

# a) with c=1
# Calculate Bias
estimated_psi2 <- apply(sim.results2,1,mean,na.rm=T)
MC_err_psi2  <- (apply(sim.results2,1,sd,na.rm=T))/(sqrt(runs))
BIAS2 <- psi_true_preint$psi - estimated_psi2

BIAS2 <- as.data.frame(cbind(psi_true_preint$times,psi_true_preint$Int,psi_true_preint$psi,estimated_psi2,BIAS2))
colnames(BIAS2) <- c("Timepoint","Intervention", "psi","est.","BIAS")
BIAS2$MC_err <-  MC_err_psi2

mytable4<- xtable(BIAS2, caption='Bias, by intervention and time point')
suppressWarnings(print(mytable4,file=paste(getwd(),"/Results_sim1_4.tex",sep=""),
                       caption.placement = "top",include.rownames=FALSE,tabular.environment="longtable"))


# visualize bias
for(i in 0:t.end){
  pdf(file=paste(getwd(),"/fig_psi_preint_",i,".pdf",sep=""))
  plot(BIAS2$Intervention[BIAS2$Timepoint==i],BIAS2$psi[BIAS2$Timepoint==i],type="l",lwd=2,ylim=c(round(min(BIAS2$psi, na.rm=T),digits=1)-0.1,round(max(BIAS2$psi, na.rm=T),digits=1)+0.1),xlab="Intervention",ylab="")
  lines(BIAS2$Intervention[BIAS2$Timepoint==i],BIAS2$est[BIAS2$Timepoint==i],type="l",lwd=2,col="blue")
  lines(BIAS2$Intervention[BIAS2$Timepoint==i],BIAS2$BIAS[BIAS2$Timepoint==i],type="l",lwd=2,col="orange",lty=2)
  abline(a=0,b=0,col="gray",lwd=1)
  legend("top",col=c("black","blue","orange"),lty=c(1,1,2),legend=c("true","estimated","BIAS"),bty="n",lwd=c(2,2,2))
  dev.off()
}

# Plot dose response curves
psi_est <- BIAS2[,c("Timepoint","Intervention")]
psi_est$psi <- estimated_psi2
psi_est$Method <- "estimated"
psi2 <- as.data.frame(psi_true_preint)
colnames(psi2) <- c("psi","Timepoint","Intervention")
psi2$Method <- "true"
psi2 <- psi2[,c("Timepoint","Intervention","psi","Method")]
psi_summary <- rbind(psi_est,psi2)
mycols <-  c("black", "orangered3")

for(j in 0:t.end){
  rel_bias_GLM <- mean(abs(BIAS2$BIAS[BIAS2$Timepoint==j]),na.rm=T)
  assign(paste("gg",j,sep=""), ggplot(psi_summary[psi_summary$Timepoint==j,], aes(x=Intervention,y=psi,col=Method))  + geom_point() +
           theme_bw() +
           coord_cartesian(ylim= c(round(min(psi_summary$psi[psi_summary$Method=="true"],na.rm=T))-1,round(max(psi_summary$psi[psi_summary$Method=="true"],na.rm=T))+1) ) +
           scale_x_continuous("Intervention", breaks=c(seq(min(a.int),max(a.int),length.out=5))) +
           scale_y_continuous(expression(psi), breaks=c(seq(round(min(psi_summary$psi[psi_summary$Method=="true"],na.rm=T))-1,round(max(psi_summary$psi[psi_summary$Method=="true"],na.rm=T))+1,length.out=10))) +
           guides(fill = guide_legend(keywidth = 2, keyheight = 2, title="Time")) +
           labs(title=paste("Dose-response curves for different methods at time", j),
                subtitle=paste("Mean absolue bias =",round(rel_bias_GLM,digits=2)))  +
           theme(axis.title.x = element_text(size=13), axis.text.x = element_text(size=13),axis.title.y = element_text(size=13, angle = 90),
                 axis.text.y = element_text(size=13), legend.text =  element_text(size=13), legend.title = element_text(size=13, face = "bold", hjust = 0),legend.position =   "bottom") +
           scale_colour_manual(name = 'Methods', values = mycols) + guides(col=guide_legend(ncol=2))
  )
  pdf(file=paste(getwd(),"/fig_psi_preint_alt",j,".pdf",sep=""))
  plot(get(paste("gg",j,sep="")))
  dev.off()
}

### density estimation without binning
estimated_psi2b <- apply(sim.results2b,1,mean,na.rm=T)
MC_err_psi2b  <- (apply(sim.results2b,1,sd,na.rm=T))/(sqrt(runs))
BIAS2b <- psi_true_preint$psi - estimated_psi2b

BIAS2b <- as.data.frame(cbind(psi_true_preint$times,psi_true_preint$Int,psi_true_preint$psi,estimated_psi2b,BIAS2b))
colnames(BIAS2b) <- c("Timepoint","Intervention", "psi","est.","BIAS")
BIAS2b$MC_err <-  MC_err_psi2b

mytable4b<- xtable(BIAS2b, caption='Bias, by intervention and time point')
suppressWarnings(print(mytable4b,file=paste(getwd(),"/Results_sim1_4b.tex",sep=""),
                       caption.placement = "top",include.rownames=FALSE,tabular.environment="longtable"))

psi_estb <- BIAS2b[,c("Timepoint","Intervention")]
psi_estb$psi <- estimated_psi2b
psi_estb$Method <- "estimated"
psib_summary <- rbind(psi_estb,psi2)

for(j in 0:t.end){
  rel_bias_GLM <- mean(abs(BIAS2b$BIAS[BIAS2b$Timepoint==j]),na.rm=T)
  assign(paste("gg",j,sep=""), ggplot(psib_summary[psib_summary$Timepoint==j,], aes(x=Intervention,y=psi,col=Method))  + geom_point() +
           theme_bw() +
           coord_cartesian(ylim= c(round(min(psib_summary$psi[psib_summary$Method=="true"],na.rm=T))-1,round(max(psib_summary$psi[psib_summary$Method=="true"],na.rm=T))+1) ) +
           scale_x_continuous("Intervention", breaks=c(seq(min(a.int),max(a.int),length.out=5))) +
           scale_y_continuous(expression(psi), breaks=c(seq(round(min(psib_summary$psi[psib_summary$Method=="true"],na.rm=T))-1,round(max(psib_summary$psi[psib_summary$Method=="true"],na.rm=T))+1,length.out=10))) +
           guides(fill = guide_legend(keywidth = 2, keyheight = 2, title="Time")) +
           labs(title=paste("Dose-response curves for different methods at time", j),
                subtitle=paste("Mean absolue bias =",round(rel_bias_GLM,digits=2)))  +
           theme(axis.title.x = element_text(size=13), axis.text.x = element_text(size=13),axis.title.y = element_text(size=13, angle = 90),
                 axis.text.y = element_text(size=13), legend.text =  element_text(size=13), legend.title = element_text(size=13, face = "bold", hjust = 0),legend.position =   "bottom") +
           scale_colour_manual(name = 'Methods', values = mycols) + guides(col=guide_legend(ncol=2))
  )
  pdf(file=paste(getwd(),"/fig_psi_preint_alt",j,"b.pdf",sep=""))
  plot(get(paste("gg",j,sep="")))
  dev.off()
}


# with c=0.01
# binning
estimated_psi3 <- apply(sim.results3,1,mean,na.rm=T)
MC_err_psi3  <- (apply(sim.results3,1,sd,na.rm=T))/(sqrt(runs))
BIAS3 <- psi_true$psi - estimated_psi3

BIAS3 <- as.data.frame(cbind(psi_true$times,psi_true$Int,psi_true$psi,estimated_psi3,BIAS3))
colnames(BIAS3) <- c("Timepoint","Intervention", "psi","est.","BIAS")
BIAS3$MC_err <-  MC_err_psi3

bp <- rbind(BIAS3,BIAS1)
bp$method <- c(rep("weighted",nrow(BIAS3)),rep("naive",nrow(BIAS1)))

pdf(file=paste(getwd(),"/fig_psi_weighted.pdf",sep=""), width=9)
ggplot(bp, aes(x=Intervention, y=BIAS, col=method)) + geom_line() + facet_wrap(~.~Timepoint) +   theme_bw() +
  scale_x_continuous("Intervention", breaks=c(seq(min(a.int),max(a.int),length.out=5))) +
  scale_y_continuous("BIAS")+
  coord_cartesian(ylim= c(round(min(bp$BIAS[bp$method=="naive"],na.rm=T))-1,round(max(bp$BIAS[bp$method=="naive"],na.rm=T))+1) ) +
  guides(fill = guide_legend(keywidth = 2, keyheight = 2, title="METHODS")) +
  labs(title=paste("Dose-response curves for different methods at different times"),
       subtitle=paste("Mean absolue bias =",round(mean(abs(BIAS1$BIAS)),digits=2), "(naive) and", round(mean(abs(BIAS3$BIAS)),digits=2), "(weighted)") )  +
  theme(axis.title.x = element_text(size=13), axis.text.x = element_text(size=13),axis.title.y = element_text(size=13, angle = 90),
        axis.text.y = element_text(size=13), legend.text =  element_text(size=13), legend.title = element_text(size=13, face = "bold", hjust = 0),legend.position =   "bottom") +
  scale_colour_manual(name = 'Methods', values = mycols) + guides(col=guide_legend(ncol=2))
dev.off()

# parametric
estimated_psi3b <- apply(sim.results3b,1,mean,na.rm=T)
MC_err_psi3b  <- (apply(sim.results3b,1,sd,na.rm=T))/(sqrt(runs))
BIAS3b <- psi_true$psi - estimated_psi3b

BIAS3b <- as.data.frame(cbind(psi_true$times,psi_true$Int,psi_true$psi,estimated_psi3b,BIAS3b))
colnames(BIAS3b) <- c("Timepoint","Intervention", "psi","est.","BIAS")
BIAS3b$MC_err <-  MC_err_psi3b

bp <- rbind(BIAS3b,BIAS1)
bp$method <- c(rep("weighted",nrow(BIAS3b)),rep("naive",nrow(BIAS1)))

pdf(file=paste(getwd(),"/fig_psi_weighted_b.pdf",sep=""), width=9)
ggplot(bp, aes(x=Intervention, y=BIAS, col=method)) + geom_line() + facet_wrap(~.~Timepoint) +   theme_bw() +
  scale_x_continuous("Intervention", breaks=c(seq(min(a.int),max(a.int),length.out=5))) +
  scale_y_continuous("BIAS") +
  coord_cartesian(ylim= c(round(min(bp$BIAS[bp$method=="naive"],na.rm=T))-1,round(max(bp$BIAS[bp$method=="naive"],na.rm=T))+1) ) +
  guides(fill = guide_legend(keywidth = 2, keyheight = 2, title="METHODS")) +
  labs(title=paste("Dose-response curves for different methods at different times"),
       subtitle=paste("Mean absolue bias =",round(mean(abs(BIAS1$BIAS),na.rm=T),digits=2), "(naive) and", round(mean(abs(BIAS3$BIAS),na.rm=T),digits=2), "(weighted)") )  +
  theme(axis.title.x = element_text(size=13), axis.text.x = element_text(size=13),axis.title.y = element_text(size=13, angle = 90),
        axis.text.y = element_text(size=13), legend.text =  element_text(size=13), legend.title = element_text(size=13, face = "bold", hjust = 0),legend.position =   "bottom") +
  scale_colour_manual(name = 'Methods', values = mycols) + guides(col=guide_legend(ncol=2))
dev.off()

# with c=0.001
# with binning
estimated_psi4 <- apply(sim.results4,1,mean,na.rm=T)
MC_err_psi4  <- (apply(sim.results4,1,sd,na.rm=T))/(sqrt(runs))
BIAS4 <- psi_true$psi - estimated_psi4

BIAS4 <- as.data.frame(cbind(psi_true$times,psi_true$Int,psi_true$psi,estimated_psi4,BIAS4))
colnames(BIAS4) <- c("Timepoint","Intervention", "psi","est.","BIAS")
BIAS4$MC_err <-  MC_err_psi4

bp <- rbind(BIAS4,BIAS1)
bp$method <- c(rep("weighted",nrow(BIAS4)),rep("naive",nrow(BIAS1)))

pdf(file=paste(getwd(),"/fig_psi_weighted_2.pdf",sep=""), width=9)
ggplot(bp, aes(x=Intervention, y=BIAS, col=method)) + geom_line() + facet_wrap(~.~Timepoint) +   theme_bw() +
  scale_x_continuous("Intervention", breaks=c(seq(min(a.int),max(a.int),length.out=5))) +
  scale_y_continuous("BIAS") +
  coord_cartesian(ylim= c(round(min(bp$BIAS[bp$method=="naive"],na.rm=T))-1,round(max(bp$BIAS[bp$method=="naive"],na.rm=T))+1) ) +
  guides(fill = guide_legend(keywidth = 2, keyheight = 2, title="METHODS")) +
  labs(title=paste("Dose-response curves for different methods at different times"),
       subtitle=paste("Mean absolue bias =",round(mean(abs(BIAS1$BIAS)),digits=2), "(naive) and", round(mean(abs(BIAS3$BIAS)),digits=2), "(weighted)") )  +
  theme(axis.title.x = element_text(size=13), axis.text.x = element_text(size=13),axis.title.y = element_text(size=13, angle = 90),
        axis.text.y = element_text(size=13), legend.text =  element_text(size=13), legend.title = element_text(size=13, face = "bold", hjust = 0),legend.position =   "bottom") +
  scale_colour_manual(name = 'Methods', values = mycols) + guides(col=guide_legend(ncol=2))
dev.off()


# parametric
estimated_psi4b <- apply(sim.results4b,1,mean,na.rm=T)
MC_err_psi4b  <- (apply(sim.results4b,1,sd,na.rm=T))/(sqrt(runs))
BIAS4b <- psi_true$psi - estimated_psi4b

BIAS4b <- as.data.frame(cbind(psi_true$times,psi_true$Int,psi_true$psi,estimated_psi4b,BIAS4b))
colnames(BIAS4b) <- c("Timepoint","Intervention", "psi","est.","BIAS")
BIAS4b$MC_err <-  MC_err_psi4b

bp <- rbind(BIAS4b,BIAS1)
bp$method <- c(rep("weighted",nrow(BIAS3b)),rep("naive",nrow(BIAS1)))

pdf(file=paste(getwd(),"/fig_psi_weighted_2b.pdf",sep=""), width=9)
ggplot(bp, aes(x=Intervention, y=BIAS, col=method)) + geom_line() + facet_wrap(~.~Timepoint) +   theme_bw() +
  scale_x_continuous("Intervention", breaks=c(seq(min(a.int),max(a.int),length.out=5))) +
  scale_y_continuous("BIAS") +
  coord_cartesian(ylim= c(round(min(bp$BIAS[bp$method=="naive"],na.rm=T))-1,round(max(bp$BIAS[bp$method=="naive"],na.rm=T))+1) ) +
  guides(fill = guide_legend(keywidth = 2, keyheight = 2, title="METHODS")) +
  labs(title=paste("Dose-response curves for different methods at different times"),
       subtitle=paste("Mean absolue bias =",round(mean(abs(BIAS1$BIAS),na.rm=T),digits=2), "(naive) and", round(mean(abs(BIAS3$BIAS),na.rm=T),digits=2), "(weighted)") )  +
  theme(axis.title.x = element_text(size=13), axis.text.x = element_text(size=13),axis.title.y = element_text(size=13, angle = 90),
        axis.text.y = element_text(size=13), legend.text =  element_text(size=13), legend.title = element_text(size=13, face = "bold", hjust = 0),legend.position =   "bottom") +
  scale_colour_manual(name = 'Methods', values = mycols) + guides(col=guide_legend(ncol=2))
dev.off()

# summary
all_res <- rbind(BIAS1,BIAS2,BIAS3,BIAS4)
all_res$method <- c(rep("naive",nrow(BIAS1)),rep("weighted (c=1)",nrow(BIAS2)),rep("weighted (c=0.01)",nrow(BIAS3)),rep("weighted (c=0.001)",nrow(BIAS4)))
all_res2 <- rbind(BIAS1,BIAS2b,BIAS3b,BIAS4b)
all_res2$method <- c(rep("naive",nrow(BIAS1)),rep("weighted (c=1)",nrow(BIAS2)),rep("weighted (c=0.01)",nrow(BIAS3)),rep("weighted (c=0.001)",nrow(BIAS4)))


pdf(file=paste(getwd(),"/fig_psi_summary.pdf",sep=""), width=10)
ggplot(all_res, aes(x=Intervention, y=est., col=method)) + geom_line() + facet_wrap(~.~Timepoint) +   theme_bw() +
  scale_x_continuous("Intervention", breaks=c(seq(min(a.int),max(a.int),length.out=5))) +
  scale_y_continuous(expression(psi)) +
  guides(fill = guide_legend(keywidth = 2, keyheight = 2, title="METHODS")) +
  coord_cartesian(ylim= c(round(min(all_res$psi[all_res$method=="naive"],na.rm=T))-1,round(max(all_res$psi[all_res$method=="naive"],na.rm=T))+1) ) +
  labs(title=paste("Dose-response curves for different methods at different times"))  +
  theme(axis.title.x = element_text(size=13), axis.text.x = element_text(size=13),axis.title.y = element_text(size=13, angle = 90),
        axis.text.y = element_text(size=13), legend.text =  element_text(size=13), legend.title = element_text(size=13, face = "bold", hjust = 0),legend.position =   "bottom") +
  scale_colour_manual(name = 'Methods', values = c(mycols,"blue","gold")) + guides(col=guide_legend(ncol=1))
dev.off()

pdf(file=paste(getwd(),"/fig_psi_summary_b.pdf",sep=""), width=10)
ggplot(all_res2, aes(x=Intervention, y=est., col=method)) + geom_line() + facet_wrap(~.~Timepoint) +   theme_bw() +
  scale_x_continuous("Intervention", breaks=c(seq(min(a.int),max(a.int),length.out=5))) +
  scale_y_continuous(expression(psi)) +
  guides(fill = guide_legend(keywidth = 2, keyheight = 2, title="METHODS")) +
  coord_cartesian(ylim= c(round(min(all_res$psi[all_res$method=="naive"],na.rm=T))-1,round(max(all_res$psi[all_res$method=="naive"],na.rm=T))+1) ) +
  labs(title=paste("Dose-response curves for different methods at different times"))  +
  theme(axis.title.x = element_text(size=13), axis.text.x = element_text(size=13),axis.title.y = element_text(size=13, angle = 90),
        axis.text.y = element_text(size=13), legend.text =  element_text(size=13), legend.title = element_text(size=13, face = "bold", hjust = 0),legend.position =   "bottom") +
  scale_colour_manual(name = 'Methods', values = c(mycols,"blue","gold")) + guides(col=guide_legend(ncol=1))
dev.off()


###################
# Part 3: support #
###################

crude_support <- apply(diag.results_crude,1,mean)
cond_support <- apply(diag.results_cond,1,mean)

crude_support_summary <- cbind(expand.grid(rownames(estimates$diagnostics$crude_support),1:3),crude_support)
cond_support_summary <- cbind(expand.grid(rownames(estimates$diagnostics$conditional_support),1:3),cond_support)
colnames(crude_support_summary)[1:2]  <- colnames(cond_support_summary)[1:2] <- c("Intervention","Time")
crude_support_summary$Intervention <- as.numeric(paste(crude_support_summary$Intervention))
cond_support_summary$Intervention <- as.numeric(paste(cond_support_summary$Intervention))

pdf(file=paste(getwd(),"/fig_crude_support.pdf",sep=""), width=10)
ggplot(crude_support_summary, aes(x=Intervention, y=crude_support)) + geom_tile(aes(height=0.005,fill=as.factor(Time))) + facet_wrap(Time~.) +   theme_bw() +
  scale_x_continuous("Intervention", breaks=c(seq(min(a.int),max(a.int),length.out=5))) +
  scale_y_continuous("crude support") +
  guides(fill = guide_legend(keywidth = 2, keyheight = 2, title="time point")) +
  labs(title=paste("Crude support at different timepoints"))  +
  theme(axis.title.x = element_text(size=13), axis.text.x = element_text(size=13),axis.title.y = element_text(size=13, angle = 90),
        axis.text.y = element_text(size=13), legend.text =  element_text(size=10), legend.title = element_text(size=10, face = "bold", hjust = 0),legend.position =   "bottom") +
  guides(col=guide_legend(ncol=1)) +
  theme(legend.position="none")
dev.off()


pdf(file=paste(getwd(),"/fig_cond_support.pdf",sep=""), width=10)
ggplot(cond_support_summary, aes(x=Intervention, y=crude_support)) + geom_tile(aes(height=0.005,fill=as.factor(Time))) + facet_wrap(Time~.) +   theme_bw() +
  scale_x_continuous("Intervention", breaks=c(seq(min(a.int),max(a.int),length.out=5))) +
  scale_y_continuous("conditional support") +
  guides(fill = guide_legend(keywidth = 2, keyheight = 2, title="time point")) +
  labs(title=paste("Conditional support at different timepoints"))  +
  theme(axis.title.x = element_text(size=13), axis.text.x = element_text(size=13),axis.title.y = element_text(size=13, angle = 90),
        axis.text.y = element_text(size=13), legend.text =  element_text(size=10), legend.title = element_text(size=10, face = "bold", hjust = 0),legend.position =   "bottom") +
  guides(col=guide_legend(ncol=1)) +
  theme(legend.position="none")
dev.off()

#### Support illustration through weight summary 
extract.pno <- function(mat){mat$pno}
wm.dc <- data.frame(wm.d[[1]][,1:3], pno=apply(do.call("cbind",lapply(wm.d, extract.pno)),1,mean))
wm.dc$Intervention <- as.factor(wm.dc$Intervention)

wm2 <- data.frame(
  wm.dc[wm.dc$Time=="1",1:2],      
  pno=apply(do.call("cbind",split(wm.dc$pno, wm.dc$Time)),1,mean)
)

pdf(file=paste(getwd(),"/fig_support_weights1.pdf",sep=""), width=10)
  ggplot(wm2, aes(x=c, y=pno, colour=Intervention))  + 
  geom_point(size=3) + geom_line(linewidth=1.1,linetype=2) + 
  theme_bw() +
  scale_x_continuous(trans='log10') + scale_y_continuous("% of weights unequal 1")+
  theme(axis.title.x = element_text(size=16), axis.text.x = element_text(size=16),axis.title.y = element_text(size=16, angle = 90),
        axis.text.y = element_text(size=16), plot.title = element_text(size=18), legend.text =  element_text(size=18), legend.title = element_text(size=18, face = "bold", hjust = 0),legend.position =   "bottom",
        strip.text.x = element_text(size = 14)) +
  scale_colour_brewer('Concentration values', palette="PiYG") 
dev.off()


wm3<-wm2; wm3$c <- as.factor(wm3$c); wm3$Intervention <- as.numeric(paste(wm3$Intervention))

pdf(file=paste(getwd(),"/fig_support_weights2.pdf",sep=""), width=10)
  ggplot(wm3, aes(x=Intervention, y=pno, colour=c, group=c))  + 
  geom_point(size=3) + geom_line(linewidth=1.1,linetype=2) + 
  theme_bw() +
  scale_y_continuous("% of weights unequal 1")+
  theme(axis.title.x = element_text(size=16), axis.text.x = element_text(size=16),axis.title.y = element_text(size=16, angle = 90),
        axis.text.y = element_text(size=16), plot.title = element_text(size=18), legend.text =  element_text(size=18), legend.title = element_text(size=18, face = "bold", hjust = 0),legend.position =   "bottom",
        strip.text.x = element_text(size = 14)) +
  scale_colour_brewer('Concentration values', palette="PiYG") 
dev.off()


########################
## Figures from Paper ##
########################

estimated_psi1 <- apply(sim.results1,1,mean,na.rm=T)
BIAS1 <- psi_true$psi - estimated_psi1
BIAS1 <- as.data.frame(cbind(psi_true$times,psi_true$Int,psi_true$psi,estimated_psi1,BIAS1))
colnames(BIAS1) <- c("Timepoint","Intervention", "psi","est.","BIAS")

# visualize bias
psi_est <- BIAS1[,c("Timepoint","Intervention")]
psi_est$psi <- estimated_psi1
psi_est$Method <- "estimated"
psi2 <- as.data.frame(psi_true)
colnames(psi2) <- c("psi","Timepoint","Intervention")
psi2$Method <- "true"
psi2 <- psi2[,c("Timepoint","Intervention","psi","Method")]
psi3 <- BIAS1
psi3$psi <- psi3$BIAS
psi3 <- psi3[,c("Timepoint","Intervention","psi")]
psi3$Method <- "bias"
psi_summary <- rbind(psi_est,psi2,psi3)
j=1 # for second time point

assign(paste("gg",j,sep=""), 
       ggplot(psi_summary[psi_summary$Timepoint==j & psi_summary$Intervention<=11 & psi_summary$Intervention>=2,], 
              aes(x=Intervention,y=psi,col=Method))  + geom_point(alpha=0.5, size=3) +
         geom_line(linetype=2, size=1.1, alpha=0.5) +
         coord_cartesian(ylim=c(-2,8),xlim=c(2,11)) +
         theme_bw() +
         scale_x_continuous("Intervention", breaks=c(1:11)) +
         scale_y_continuous(expression(psi), breaks=c(-2,0,2,4,6,8)) +
         guides(fill = guide_legend(keywidth = 2, keyheight = 2, title="Time")) +
         labs(title=paste("Dose-response curve at time", j+1))  +
         theme(axis.title.x = element_text(size=16), axis.text.x = element_text(size=16),axis.title.y = element_text(size=16, angle = 90),
               axis.text.y = element_text(size=16), plot.title = element_text(size=18), legend.text =  element_text(size=18), legend.title = element_text(size=18, face = "bold", hjust = 0),legend.position =   "bottom") +
         scale_colour_manual(name = '', values = c("red","blue","black")) + guides(col=guide_legend(ncol=3))
)

pdf(file=paste(getwd(),"/_fig2a_paper.pdf",sep=""),width=9)
plot(get(paste("gg",j,sep="")))
dev.off()

# 
estimated_psi2 <- apply(sim.results2,1,mean,na.rm=T)
BIAS2 <- psi_true_preint$psi - estimated_psi2
BIAS2 <- as.data.frame(cbind(psi_true_preint$times,psi_true_preint$Int,psi_true_preint$psi,estimated_psi2,BIAS2))
colnames(BIAS2) <- c("Timepoint","Intervention", "psi","est.","BIAS")

estimated_psi2b <- apply(sim.results2b,1,mean,na.rm=T)
BIAS2b <- psi_true_preint$psi - estimated_psi2b
BIAS2b <- as.data.frame(cbind(psi_true_preint$times,psi_true_preint$Int,psi_true_preint$psi,estimated_psi2b,BIAS2b))
colnames(BIAS2b) <- c("Timepoint","Intervention", "psi","est.","BIAS")

p1 <- BIAS2[,c("Timepoint","Intervention","est.")]
p2 <- BIAS2b[,c("Timepoint","Intervention","est.")]
p3 <- BIAS2[,c("Timepoint","Intervention","psi")]
colnames(p1)[3] <- colnames(p2)[3] <- colnames(p3)[3] <- "psi"
p1$Method <- "density estimation: binning"
p2$Method <- "density estimation: parametric"
p3$Method <- "true"
psib_summary <- rbind(p1,p2,p3)

j=0 # t=1

assign(paste("gg",j,sep=""), 
       ggplot(psib_summary[psib_summary$Timepoint==j & psi_summary$Intervention<=11 & psi_summary$Intervention>=2,],
              aes(x=Intervention,y=psi,col=Method)) + geom_point(alpha=0.5, size=3) +
         geom_line(linetype=2, size=1.1, alpha=0.5) +
         coord_cartesian(ylim=c(-2,8),xlim=c(2,11)) +
         theme_bw() +
         scale_x_continuous("Intervention", breaks=c(1:11)) +
         scale_y_continuous(expression("E(" ~ Y[1] ~"|"  ~ A[1] ~ "=" ~ a[1] ~  ")"), breaks=c(-2,0,2,4,6,8)) +guides(fill = guide_legend(keywidth = 2, keyheight = 2, title="Time")) +
         labs(title=paste("Dose-response curve at time", j+1))  +
         theme(axis.title.x = element_text(size=16), axis.text.x = element_text(size=16),axis.title.y = element_text(size=16, angle = 90),
               axis.text.y = element_text(size=16), plot.title = element_text(size=18), legend.text =  element_text(size=18), legend.title = element_text(size=18, face = "bold", hjust = 0),legend.position =   "bottom") +
         scale_colour_manual(name = '', values = c("red","blue","black")) + guides(col=guide_legend(ncol=3))
)

pdf(file=paste(getwd(),"/_fig2b_paper.pdf",sep=""),width=9)
plot(get(paste("gg",j,sep="")))
dev.off()


j=1 # t=2

assign(paste("gg",j,sep=""), 
       ggplot(psib_summary[psib_summary$Timepoint==j & psi_summary$Intervention<=11 & psi_summary$Intervention>=2,],
              aes(x=Intervention,y=psi,col=Method)) + geom_point(alpha=0.5, size=3) +
         geom_line(linetype=2, size=1.1, alpha=0.5) +
         coord_cartesian(ylim=c(-2,11),xlim=c(2,11)) +
         theme_bw() +
         scale_x_continuous("Intervention", breaks=c(1:11)) +
         scale_y_continuous(expression("E(" ~ Y[2] ~"|" ~ A[2] ~ "=" ~ a[2] ~ "," ~ A[1] ~ "=" ~ a[1] ~  ")"), breaks=c(-2,0,2,4,6,8,10)) +guides(fill = guide_legend(keywidth = 2, keyheight = 2, title="Time")) +
         labs(title=paste("Dose-response curve at time", j+1))  +
         theme(axis.title.x = element_text(size=16), axis.text.x = element_text(size=16),axis.title.y = element_text(size=16, angle = 90),
               axis.text.y = element_text(size=16), plot.title = element_text(size=18), legend.text =  element_text(size=18), legend.title = element_text(size=18, face = "bold", hjust = 0),legend.position =   "bottom") +
         scale_colour_manual(name = '', values = c("red","blue","black")) + guides(col=guide_legend(ncol=3))
)

pdf(file=paste(getwd(),"/_fig5a_paper.pdf",sep=""),width=9)
plot(get(paste("gg",j,sep="")))
dev.off()

# support

cond_support <- apply(diag.results_cond,1,mean)
cond_support_summary <- cbind(expand.grid(paste(intervention),1:3),cond_support)
colnames(cond_support_summary)[1:2] <- c("Intervention","Time")
cond_support_summary$Intervention <- as.numeric(paste(cond_support_summary$Intervention))


pdf(file=paste(getwd(),"/_fig6a_paper.pdf",sep=""),width=10)
ggplot(cond_support_summary[cond_support_summary$Time<3,], aes(x=Intervention, y=cond_support)) + geom_tile(aes(height=0.005,fill=as.factor(Time))) + facet_wrap(Time~.) +   theme_bw() +
  scale_x_continuous("Intervention", breaks=c(2:11)) +
  scale_y_continuous("conditional support") +
  coord_cartesian(xlim=c(2,11)) +
  guides(fill = guide_legend(keywidth = 2, keyheight = 2, title="time point")) +
  labs(title=paste("Conditional support at different timepoints"))  +
  theme(axis.title.x = element_text(size=16), axis.text.x = element_text(size=16),axis.title.y = element_text(size=16, angle = 90),
        axis.text.y = element_text(size=16), strip.text.x = element_text(size = 16), plot.title = element_text(size=18), legend.text =  element_text(size=18), legend.title = element_text(size=18, face = "bold", hjust = 0),legend.position =   "bottom") +
  guides(col=guide_legend(ncol=1)) +
  theme(legend.position="none")
dev.off()

