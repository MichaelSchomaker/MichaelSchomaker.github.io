# Simulation 2 from Schomaker, McIlleron, Denti, Diaz (2023)
# "Causal Inference for Multiple Time Point Interventions"
#
# all plots and tables will be saved in the below specified working directory
# progress of the simulation will be saved in a .txt file (sim_progress.txt)
#
# add to your working directory the following files:
# screening_algorithms.R, learning_algorithms.R and Results_final_simulation_2.tex
# Compile the .tex-file to get a pdf with all summaries of the simulation 


setwd("yourpath")
#
library(CICI)     # install.packages("CICI")
library(CICIplus) # see https://github.com/MichaelSchomaker/CICIplus
#
library(simcausal)
library(ggplot2)
library(xtable)
library(data.table) # for na.fill() function
library(foreach)
#
source(paste0(getwd(),"/screening_algorithms.R")) # own screening functions for SuperLearner 
source(paste0(getwd(),"/learning_algorithms.R"))  # own learners for SuperLearner 
#
set.seed(241280)
ptm <- proc.time()

# SETUP
runs          <- 1000      # number of simulation runs
N             <- c(500,1000,10000,50000)    # sample sizes for estimation
intervention  <- a.int  <- seq(-7,12.5,0.5)
n.int         <- length(intervention)     
cpus          <- 8      # number of threads to use for parallelization
SAMPLE_SIZE_TRUTH <- 100000
t.end <- 4     # number of time points after baseline
#

###########################
# Data generating process #
###########################

# initialize the DAG
D <- DAG.empty()

# everything at baseline (t = 0)
D.base <- D +
  node("L1",
       t = 0,
       distr = "rbern",
       prob=0.3) +
  node("L2",
       t = 0,
       distr = "rnorm",
       mean = 2*L1[0]-1,
       sd = 1) +
  node("A",
       t = 0,
       distr = "rnorm",
       mean = 7 + L1[0] + 0.7*L2[0],
       sd=1 ) +
  node("Y",
       t = 0,
       distr = "rbern",
       prob = plogis(-4 + 0.5*L2[t] + 0.2*A[t]),
       EFU = T)

#time-dependent variables at later time-points
D <- D.base +
  node("L1",
       t = 1:t.end,
       distr = "rbern",
       prob = plogis(-4 + L1[t-1] + 0.15*L2[t-1] + 0.15*A[t-1] + Y[t-1])) +
  node("L2",
       t = 1:t.end,
       distr = "rnorm",
       mean = 0.5*L1[t]+0.25*L2[t-1]+0.5*A[t-1]+0.2*Y[t-1],
       sd = 1) +
  node("A",
       t = 1:t.end,
       distr = "rnorm",
       mean = -2 + .75*L1[t] + .35*L2[t] + 0.25*Y[t-1] + 0.5*A[t-1],
       sd=0.5) +
  node("C",                                   
       t = 1:t.end,
       distr = "rbern",
       prob = plogis(-2 + 0.5*L1[t] - 0.2*A[t]),
       EFU = T) + 
  node("Y",
       t = 1:t.end,
       distr = "rbern",
       prob = plogis(-4 + 0.5*L2[t] + 0.2*A[t]),
       EFU = T)

Dset <- set.DAG(D)


# Some observed data
Odat <- simcausal::sim(DAG = Dset, n = N[2])
# now make setup such that once Y jumps to 1, it stays at 1 (survival)
 cens.ind <- apply(Odat[colnames(Odat)[sort(c(grep("C_",colnames(Odat))))]]==1,1,any)
 cens.ind[is.na(cens.ind)] <- FALSE
 Odat[cens.ind==FALSE,colnames(Odat)[sort(c(grep("Y_",colnames(Odat))))]] <- t(apply(Odat[cens.ind==FALSE,colnames(Odat)[sort(c(grep("Y_",colnames(Odat))))]],1,nafill,type="locf"))
 summary(Odat)

###################
# Generate Truth  #
###################
write(matrix("Calculating truth..."),file=paste(getwd(),"/sim_progress.txt",sep=""))

int.a.names  <- paste("A.cont.",1:n.int,sep="") # intervention names

# Intervention on the DAG given a continuous interventions
for(j in 1:n.int){
  assign(paste("A.cont.",j,sep=""),c(node("A", t = 0:t.end, distr = "rconst", const=NA)))   # NA because indexing with [j] not possible
}

modify.int.const <- function(int,number){
  int[[5]]$const <- number
  return(int)
}

for(j in 1:length(int.a.names)){  # trick to correctly assign continuous intervention by overwriting default
  assign(paste("A.cont.",j,sep=""),  c(lapply(get(paste("A.cont.",j,sep="")),modify.int.const,number=a.int[j]),node("C", t = 1:t.end, distr = "rconst", const=0))  )
}

for(j in 1:n.int){
  Dset <- Dset + action(int.a.names[j], nodes = get(int.a.names[j]))
}

# simulate for the intervention
sim.cont <- simcausal::sim(DAG = Dset, actions = int.a.names, n = SAMPLE_SIZE_TRUTH, rndseed = 241280)

verbose<-TRUE
if(cpus>1){
  if(cpus > parallel::detectCores()){
    cpus <- parallel::detectCores();if(verbose==TRUE){cat(paste("Note: You only have",cpus,"threads which can be utilized. \n"))}
  }
  cl <- parallel::makeCluster(cpus); doParallel::registerDoParallel(cl)
}else{foreach::registerDoSEQ()}


adjust_surv <- foreach(j = 1:n.int, .packages=c("CICI"),.errorhandling="pass") %dopar% {
  #once Y=1, keep Y=1 (survival setup)
  CICI:::adjust.sim.surv(sim.cont[[j]],Yn=colnames(Odat)[sort(c(grep("Y_",colnames(Odat))))])
}

if(cpus>1){parallel::stopCluster(cl)}

for(j in 1:n.int){sim.cont[[j]] <-adjust_surv[[j]]}

Y.names <- colnames(sim.cont[[j]])[sort(c(grep("Y_",colnames(sim.cont[[j]]))))]
for(j in 1:n.int){
  assign(paste("psi",c(1:n.int)[j],sep=""),apply(sim.cont[[j]][,Y.names],2,mean))
}

psi_true <- as.data.frame(cbind(matrix(unlist(mget(paste("psi",c(1:n.int),sep=""))),ncol=1),rep(0:t.end,n.int),rep(a.int, each=(t.end+1))))
colnames(psi_true)[1] <- "psi"
colnames(psi_true)[2] <- "times"
colnames(psi_true)[3] <-  "Int"
psi_true <- psi_true[order(psi_true$times),]
psi_true


# true dose-response curves
mymin <- round(min(psi_true$psi)-1,digits=0)
mymax <- round(max(psi_true$psi)+1,digits=0)
mycolors <- c("black", "orangered3","dodgerblue4", "springgreen3","gold","greenyellow",rainbow(20))
mycols <- mycolors[1:length(unique(psi_true$times))]
psi_true$psi

# a) ggplot
gg.true <- ggplot(psi_true, aes(x=Int,y=psi,col=as.factor(times)))  + geom_line(linewidth=1.3) + theme_bw() +
  scale_color_manual(values = mycols) +
  scale_x_continuous("Intervention", breaks=c(seq(-7,13,1))) +
  scale_y_continuous(expression(psi)) +
  guides(fill = guide_legend(keywidth = 2, keyheight = 2, title="Time")) +
  ggtitle("True dose-response curves")  +
  theme(axis.title.x = element_text(size=13), axis.text.x = element_text(size=13),axis.title.y = element_text(size=13, angle = 90),
        axis.text.y = element_text(size=13), legend.text =  element_text(size=13), legend.title = element_text(size=13, face = "bold", hjust = 0),legend.position =   "bottom") +
  guides(col=guide_legend(title="Time"))

pdf(file=paste0(getwd(),"/true_CDRC.pdf"))
plot(gg.true)
dev.off()


# store.results
sim.results1 <- matrix(NA,ncol=runs,nrow=n.int*(t.end+1))
sim.results2 <- matrix(NA,ncol=runs,nrow=n.int*(t.end+1))
sim.results3 <- matrix(NA,ncol=runs,nrow=n.int*(t.end+1))
sim.results4 <- matrix(NA,ncol=runs,nrow=n.int*(t.end+1))
sim.results5 <- matrix(NA,ncol=runs,nrow=n.int*(t.end+1))
diag.results_crude <- matrix(NA,ncol=runs,nrow=n.int*(t.end+1))
diag.results_cond <- matrix(NA,ncol=runs,nrow=n.int*(t.end+1))

#
write(matrix("started with simulation..."),file=paste(getwd(),"/sim_progress.txt",sep=""), append=T)
# Simulation loop
for(r in 1:runs)try({
  #
  cat(paste("This is simulation run number",r, "\n"))
  write(matrix(paste("started with simulation run #",r)),file=paste(getwd(),"/sim_progress.txt",sep=""),append=T)
  
  # draw data
  simdat   <- simcausal::sim(DAG = Dset, n = N[length(N)], verbose=F)[,-1]

  # correct models
  correct.models <- list(
    Lnames = c("L1_0 ~ 1",
               "L2_0 ~ L1_0",
               "L1_1 ~ L1_0 + L2_0 + A_0 + Y_0",
               "L2_1 ~ L2_0 + A_0 + Y_0 + L1_1",
               "L1_2 ~ L1_1 + L2_1 + A_1 + Y_1",
               "L2_2 ~ L2_1 + A_1 + Y_1 + L1_2",
               "L1_3 ~ L1_2 + L2_2 + A_2 + Y_2",
               "L2_3 ~ L2_2 + A_2 + Y_2 + L1_3",
               "L1_4 ~ L1_3 + L2_3 + A_3 + Y_3",
               "L2_4 ~ L2_3 + A_3 + Y_3 + L1_4"),
    Ynames = c("Y_0 ~ L2_0 + A_0",
               "Y_1 ~ L2_1 + A_1",
               "Y_2 ~ L2_2 + A_2",
               "Y_3 ~ L2_3 + A_3",
               "Y_4 ~ L2_4 + A_4"),
    Anames = c("A_0 ~ L1_0 + L2_0",
               "A_1 ~ A_0 + Y_0 + L1_1 + L2_1",
               "A_2 ~ A_1 + Y_1 + L1_2 + L2_2",
               "A_3 ~ A_2 + Y_2 + L1_3 + L2_3",
               "A_4 ~ A_3 + Y_3 + L1_4 + L2_4"),
    Cnames=  c("C_1 ~ L1_1 + A_1",
               "C_2 ~ L1_2 + A_2",
               "C_3 ~ L1_3 + A_3",
               "C_4 ~ L1_4 + A_4")
  )
  
  # 
  estimates <- try(gformula(X=simdat[1:N[1],],
                                Lnodes  = colnames(simdat)[sort(c(grep("L1_",colnames(simdat)),grep("L2_",colnames(simdat))))],
                                Ynodes  = colnames(simdat)[sort(c(grep("Y_",colnames(simdat))))],
                                Anodes  = colnames(simdat)[sort(c(grep("A_",colnames(simdat))))],
                                Cnodes  = colnames(simdat)[sort(c(grep("C_",colnames(simdat))))],
                                abar=intervention, cbar="uncensored", survivalY=TRUE,
                                Yform=correct.models$Ynames, Lform=correct.models$Lnames[-c(1:2)], Aform=correct.models$Anames, Cform=correct.models$Cnames,
                                calc.support=FALSE, verbose=FALSE,
                                ncores=cpus
  ), silent=T)
  
  estimates2 <- try(gformula(X=simdat[1:N[2],],
                        Lnodes  = colnames(simdat)[sort(c(grep("L1_",colnames(simdat)),grep("L2_",colnames(simdat))))],
                        Ynodes  = colnames(simdat)[sort(c(grep("Y_",colnames(simdat))))],
                        Anodes  = colnames(simdat)[sort(c(grep("A_",colnames(simdat))))],
                        Cnodes  = colnames(simdat)[sort(c(grep("C_",colnames(simdat))))],
                        abar=intervention, cbar="uncensored", survivalY=TRUE,
                        Yform=correct.models$Ynames, Lform=correct.models$Lnames[-c(1:2)], Aform=correct.models$Anames, Cform=correct.models$Cnames,
                        calc.support=FALSE, verbose=FALSE,
                        ncores=cpus
  ), silent=T)
  
  estimates3 <- try(gformula(X=simdat[1:N[3],],
                        Lnodes  = colnames(simdat)[sort(c(grep("L1_",colnames(simdat)),grep("L2_",colnames(simdat))))],
                        Ynodes  = colnames(simdat)[sort(c(grep("Y_",colnames(simdat))))],
                        Anodes  = colnames(simdat)[sort(c(grep("A_",colnames(simdat))))],
                        Cnodes  = colnames(simdat)[sort(c(grep("C_",colnames(simdat))))],
                        abar=intervention, cbar="uncensored", survivalY=TRUE,
                        Yform=correct.models$Ynames, Lform=correct.models$Lnames[-c(1:2)], Aform=correct.models$Anames, Cform=correct.models$Cnames,
                        calc.support=FALSE, verbose=FALSE,
                        ncores=cpus
  ), silent=TRUE)
  
  estimates4 <- try(gformula(X=simdat[1:N[4],],
                        Lnodes  = colnames(simdat)[sort(c(grep("L1_",colnames(simdat)),grep("L2_",colnames(simdat))))],
                        Ynodes  = colnames(simdat)[sort(c(grep("Y_",colnames(simdat))))],
                        Anodes  = colnames(simdat)[sort(c(grep("A_",colnames(simdat))))],
                        Cnodes  = colnames(simdat)[sort(c(grep("C_",colnames(simdat))))],
                        abar=intervention, cbar="uncensored", survivalY=TRUE,
                        Yform=correct.models$Ynames, Lform=correct.models$Lnames[-c(1:2)], Aform=correct.models$Anames, Cform=correct.models$Cnames,
                        calc.support=TRUE, verbose=FALSE,
                        ncores=cpus
  ), silent=TRUE)
  
  #
  estimates5 <- try(sgf(X=simdat[1:N[3],],
                         Lnodes  = colnames(simdat)[sort(c(grep("L1_",colnames(simdat)),grep("L2_",colnames(simdat))))],
                         Ynodes  = colnames(simdat)[sort(c(grep("Y_",colnames(simdat))))],
                         Anodes  = colnames(simdat)[sort(c(grep("A_",colnames(simdat))))],
                         Cnodes  = colnames(simdat)[sort(c(grep("C_",colnames(simdat))))],
                         abar=intervention, survivalY=TRUE,
                         calc.support=FALSE, verbose=FALSE,
                         ncores=cpus
  ), silent=T)
  
  # check errors (if any) & store estimates
  if(class(estimates)!="try-error"){sim.results1[,r] <- c(estimates$results$psi)}else{
    cat("Note: error in estimating estimates1 -> no estimate saved \n") 
    write(matrix(paste("Note: error in estimating estimates1 -> no estimate saved ")),file=paste(getwd(),"/sim_progress.txt",sep=""),append=T)}
  if(class(estimates2)!="try-error"){sim.results2[,r] <- c(estimates2$results$psi)}else{
    cat("Note: error in estimating estimates2 -> no estimate saved \n") 
    write(matrix(paste("Note: error in estimating estimates2 -> no estimate saved ")),file=paste(getwd(),"/sim_progress.txt",sep=""),append=T)}
  if(class(estimates3)!="try-error"){sim.results3[,r] <- c(estimates3$results$psi)}else{
    cat("Note: error in estimating estimates3 -> no estimate saved \n")
    write(matrix(paste("Note: error in estimating estimates3 -> no estimate saved ")),file=paste(getwd(),"/sim_progress.txt",sep=""),append=T)}
  if(class(estimates4)!="try-error"){sim.results4[,r] <- c(estimates4$results$psi)}else{
    cat("Note: error in estimating estimates4 -> no estimate saved \n")
    write(matrix(paste("Note: error in estimating estimates4 -> no estimate saved ")),file=paste(getwd(),"/sim_progress.txt",sep=""),append=T)}
  if(class(estimates5)!="try-error"){sim.results5[,r] <- c(estimates5$results$psi)}else{
    cat("Note: error in estimating estimates5 -> no estimate saved \n")
    write(matrix(paste("Note: error in estimating estimates5 -> no estimate saved ")),file=paste(getwd(),"/sim_progress.txt",sep=""),append=T)}

  diag.results_crude[,r] <- try(unlist(c(estimates4$diagnostics$crude_support)))
  diag.results_cond[,r] <- try(unlist(c(estimates4$diagnostics$conditional_support)))
  
  sim.results <- list(sim.results1,sim.results2,sim.results3,sim.results4,diag.results_crude,diag.results_cond,sim.results5)
  save(sim.results,file=paste(getwd(),"/tempresults.Rdata",sep=""))
})


####################
# Evaluate Results #
####################

# Preliminaries
ptm2 <-  proc.time()
simulationsdauer <- ptm2-ptm
simulationsdauer <- (simulationsdauer/60)
simulationsdauer <- round(simulationsdauer[1], digits=2)
cat(paste("The simulation time was", simulationsdauer, "minutes \n"))
finaltime <-  paste("The simulation time was", simulationsdauer, "minutes")

any.problem_1<- sum(apply(apply(sim.results1,2,is.na),2,any))
any.problem_2<- sum(apply(apply(sim.results2,2,is.na),2,any))
any.problem_3<- sum(apply(apply(sim.results3,2,is.na),2,any))
any.problem_4<- sum(apply(apply(sim.results4,2,is.na),2,any))
any.problem_5<- sum(apply(apply(sim.results5,2,is.na),2,any))


# Table 1: Simulation Info
Info <- matrix(rbind("This is simulation no. 2",
                     paste("Number of simulation runs:",runs),
                     paste("Sample sizes:", paste(N, collapse=", ")),
                     paste("Number of interventions",n.int),
                     paste("Number of methods:",2), 
                     paste("Problems (>=1 estimates are NA) in simulation runs per approach:",any.problem_1, ",",any.problem_2, ",",any.problem_3, ",",any.problem_4, ",",any.problem_5)
                     ),dimnames=NULL)
colnames(Info) <- "Setup"
rownames(Info) <- NULL
mytable1 <- xtable(Info, caption='Simulation details')
print(mytable1,file=paste(getwd(),"/Results_sim2.tex",sep=""),table.placement="H",include.rownames=FALSE)

# Calculate Bias
# Intervention type 1
estimated_psi1 <- apply(sim.results1,1,mean)
MC_err_psi1  <- (apply(sim.results1,1,sd))/(sqrt(runs))
BIAS1 <- psi_true$psi - estimated_psi1

estimated_psi2 <- apply(sim.results2,1,mean)
MC_err_psi2  <- (apply(sim.results2,1,sd))/(sqrt(runs))
BIAS2 <- psi_true$psi - estimated_psi2

estimated_psi3 <- apply(sim.results3,1,mean)
MC_err_psi3  <- (apply(sim.results3,1,sd))/(sqrt(runs))
BIAS3 <- psi_true$psi - estimated_psi3

estimated_psi4 <- apply(sim.results4,1,mean)
MC_err_psi4  <- (apply(sim.results4,1,sd))/(sqrt(runs))
BIAS4 <- psi_true$psi - estimated_psi4

BIAS1 <- as.data.frame(cbind(BIAS1,psi_true$times,psi_true$Int,rep(N[1],length(BIAS1))))
BIAS2 <- as.data.frame(cbind(BIAS2,psi_true$times,psi_true$Int,rep(N[2],length(BIAS2))))
BIAS3 <- as.data.frame(cbind(BIAS3,psi_true$times,psi_true$Int,rep(N[3],length(BIAS3))))
BIAS4 <- as.data.frame(cbind(BIAS4,psi_true$times,psi_true$Int,rep(N[4],length(BIAS4))))
colnames(BIAS1) <- colnames(BIAS2) <- colnames(BIAS3) <- colnames(BIAS4) <- c("Bias","Timepoint","Intervention","N")
BIAS <- rbind(BIAS1,BIAS2,BIAS3,BIAS4)
BIAS$N <- as.character(BIAS $N)
BIAS$N <- paste("N =",BIAS $N)

# Summarize results
results <- BIAS
results$psi_est <- c(estimated_psi1,estimated_psi2,estimated_psi3,estimated_psi4)
truth <- as.data.frame(cbind(NA,psi_true$times,psi_true$Int,rep(NA,length(BIAS1)),psi_true$psi) )
colnames(truth) <- colnames(results)
results <- rbind(results,truth)
results$N <- as.character(results$N)
results$N <- paste(results$N)
results$N[results$N=="NA"] <- "truth"

# Plot dose response curves
for(j in 0:t.end){
  assign(paste("gg",j,sep=""), ggplot(results[results$Timepoint==j,], aes(x=Intervention,y=psi_est,col=N))  + geom_point() +
           #geom_smooth(method = "loess", se=F, size=0.5) +
           theme_bw() +
           scale_x_continuous("Intervention", breaks=c(seq(-7,13))) +
           scale_y_continuous(expression(psi)) +
           guides(fill = guide_legend(keywidth = 2, keyheight = 2, title="Time")) +
           labs(title=paste("Dose-response curves for different sample sizes at time", j))  +
           theme(axis.title.x = element_text(size=13), axis.text.x = element_text(size=13),axis.title.y = element_text(size=13, angle = 90),
                 axis.text.y = element_text(size=13), legend.text =  element_text(size=13), legend.title = element_text(size=13, face = "bold", hjust = 0),legend.position =   "bottom") +
           scale_colour_manual(name = 'Sample Sizes', values = mycols) + guides(col=guide_legend(ncol=2))
         
  )
  pdf(file=paste(getwd(),"/figure_time_",j,".pdf",sep=""),width=9)
  plot(get(paste("gg",j,sep="")))
  dev.off()
}

# Plot Bias
for(j in 0:t.end){
  assign(paste("gg",j,sep=""), ggplot(BIAS[BIAS$Timepoint==j,], aes(x=Intervention,y=Bias,col=N))  + geom_point() +
           geom_smooth( se=F, linewidth=0.5) +
           theme_bw() +
           scale_x_continuous("Intervention", breaks=c(seq(-7,13))) +
           scale_y_continuous("Absolute Bias") +
           geom_hline(yintercept = 0, size=0.4,col="grey") +
           guides(fill = guide_legend(keywidth = 2, keyheight = 2, title="Time")) +
           labs(title=paste("Dose-response curves for different sample sizes at time", j))  +
           theme(axis.title.x = element_text(size=13), axis.text.x = element_text(size=13),axis.title.y = element_text(size=13, angle = 90),
                axis.text.y = element_text(size=13), legend.text =  element_text(size=13), legend.title = element_text(size=13, face = "bold", hjust = 0),legend.position =   "bottom") +
           scale_colour_manual(name = 'Sample Sizes', values = mycols[c(1,2,4,5)]) + guides(col=guide_legend(ncol=2))
  )
  pdf(file=paste(getwd(),"/bias_time_",j,".pdf",sep=""), width=9)
  plot(get(paste("gg",j,sep="")))
  dev.off()
}

###########
# support #
###########


crude_support <- apply(diag.results_crude,1,mean)
cond_support <- apply(diag.results_cond,1,mean)

crude_support_summary <- cbind(expand.grid(rownames(estimates4$diagnostics$crude_support),1:5),crude_support)
cond_support_summary <- cbind(expand.grid(rownames(estimates4$diagnostics$conditional_support),1:5),cond_support)
colnames(crude_support_summary)[1:2]  <- colnames(cond_support_summary)[1:2] <- c("Intervention","Time")
crude_support_summary$Intervention <- as.numeric(paste(crude_support_summary$Intervention))
cond_support_summary$Intervention <- as.numeric(paste(cond_support_summary$Intervention))

pdf(file=paste(getwd(),"/fig_crude_support.pdf",sep=""), width=10)
ggplot(crude_support_summary, aes(x=Intervention, y=crude_support)) + geom_tile(aes(height=0.005,fill=as.factor(Time))) + facet_wrap(Time~.) +   theme_bw() +
  scale_x_continuous("Intervention", breaks=c(seq(min(a.int),max(a.int),length.out=4))) +
  scale_y_continuous("crude support") +
  guides(fill = guide_legend(keywidth = 2, keyheight = 2, title="time point")) +
  labs(title=paste("Crude support at different timepoints"))  +
  theme(axis.title.x = element_text(size=13), axis.text.x = element_text(size=13),axis.title.y = element_text(size=13, angle = 90),
        axis.text.y = element_text(size=13), legend.text =  element_text(size=10), legend.title = element_text(size=10, face = "bold", hjust = 0),legend.position =   "bottom") +
  guides(col=guide_legend(ncol=1)) +
  theme(legend.position="none")
dev.off()


pdf(file=paste(getwd(),"/fig_cond_support.pdf",sep=""), width=10)
ggplot(cond_support_summary, aes(x=Intervention, y=crude_support)) + geom_tile(aes(height=0.005,fill=as.factor(Time))) + facet_wrap(Time~.) +   theme_bw() +
  scale_x_continuous("Intervention", breaks=c(seq(min(a.int),max(a.int),length.out=4))) +
  scale_y_continuous("conditional support") +
  guides(fill = guide_legend(keywidth = 2, keyheight = 2, title="time point")) +
  labs(title=paste("Conditional support at different timepoints"))  +
  theme(axis.title.x = element_text(size=13), axis.text.x = element_text(size=13),axis.title.y = element_text(size=13, angle = 90),
        axis.text.y = element_text(size=13), legend.text =  element_text(size=10), legend.title = element_text(size=10, face = "bold", hjust = 0),legend.position =   "bottom") +
  guides(col=guide_legend(ncol=1)) +
  theme(legend.position="none")
dev.off()

####################################
### comparison seq. g-formula     ##
####################################

estimated_psi5 <- apply(sim.results5,1,mean,na.rm=T)
MC_err_psi5  <- (apply(sim.results5,1,sd,na.rm=T))/(sqrt(runs))
BIAS5 <- psi_true$psi - estimated_psi5
BIAS5 <- as.data.frame(cbind(BIAS5,psi_true$times,psi_true$Int,rep("seq. g-comp.",length(BIAS5))))
colnames(BIAS5) <- c("Bias","Timepoint","Intervention","N")
results2 <- results[results$N %in% c("N = 10000","truth"),]
results2$N[results2$N=="N = 10000"]<-"param. g-comp."
BIAS5$psi_est <- c(estimated_psi5)
BIAS5[,c(1,2,3,5)] <- apply(BIAS5[,c(1,2,3,5)],2,as.numeric)
results2 <- rbind(results2,BIAS5)
colnames(results2)[4] <- "Method"
# Plot dose response curves
for(j in 0:t.end){
  assign(paste("gg",j,sep=""), ggplot(results2[results2$Timepoint==j,], aes(x=Intervention,y=psi_est,col=Method))  + geom_point() +
           theme_bw() +
           scale_x_continuous("Intervention", breaks=c(seq(-7,13))) +
           scale_y_continuous(expression(psi)) +
           guides(fill = guide_legend(keywidth = 2, keyheight = 2, title="Time")) +
           labs(title=paste("Dose-response curves for different methods at time", j))  +
           theme(axis.title.x = element_text(size=13), axis.text.x = element_text(size=13),axis.title.y = element_text(size=13, angle = 90),
                 axis.text.y = element_text(size=13), legend.text =  element_text(size=13), legend.title = element_text(size=13, face = "bold", hjust = 0),legend.position =   "bottom") +
           scale_colour_manual(name = 'Methods', values = mycols) + guides(col=guide_legend(ncol=2))
         
  )
  pdf(file=paste(getwd(),"/figure_comparison_time_",j,".pdf",sep=""),width=9)
  plot(get(paste("gg",j,sep="")))
  dev.off()
}

for(j in 0:t.end){
  assign(paste("gg",j,sep=""), ggplot(results2[results2$Timepoint==j,], aes(x=Intervention,y=Bias,col=Method))  + geom_point() +
           geom_smooth( se=F, size=0.5) +
           theme_bw() +
           scale_x_continuous("Intervention", breaks=c(seq(-7,13))) +
           scale_y_continuous("Absolute Bias") +
           geom_hline(yintercept = 0, size=0.4,col="grey") +
           guides(fill = guide_legend(keywidth = 2, keyheight = 2, title="Time")) +
           labs(title=paste("Dose-response curves for different methods at time", j))  +
           theme(axis.title.x = element_text(size=13), axis.text.x = element_text(size=13),axis.title.y = element_text(size=13, angle = 90),
                 axis.text.y = element_text(size=13), legend.text =  element_text(size=13), legend.title = element_text(size=13, face = "bold", hjust = 0),legend.position =   "bottom") +
           scale_colour_manual(name = 'Sample Sizes', values = mycols[c(1,2,4,5)]) + guides(col=guide_legend(ncol=2))
  )
  pdf(file=paste(getwd(),"/bias_comparison_time_",j,".pdf",sep=""), width=9)
  plot(get(paste("gg",j,sep="")))
  dev.off()
}

########################
## Figures from Paper ##
########################


#
j=4
assign(paste("gg",j,sep=""), 
       ggplot(results[results$Timepoint==j & results$N!="N = 500",], aes(x=Intervention,y=psi_est,col=N))  + 
         geom_point(size=3) +
         theme_bw() +
         geom_line(linetype=2, size=1.1) +
         scale_x_continuous("Intervention", breaks=c(seq(-7,13))) +
         scale_y_continuous(expression(psi)) +
         guides(fill = guide_legend(keywidth = 2, keyheight = 2, title="Time")) +
         labs(title=paste("Estimated dose-response curves for different sample sizes at time", j+1))  +
         theme(axis.title.x = element_text(size=16), axis.text.x = element_text(size=16),axis.title.y = element_text(size=16, angle = 90),
               axis.text.y = element_text(size=16), plot.title = element_text(size=18), legend.text =  element_text(size=18), legend.title = element_text(size=18, face = "bold", hjust = 0),legend.position =   "bottom") +
         scale_colour_manual(name = 'Sample Sizes', values = mycolors[c(1,4,5,2)]) + 
         guides(col=guide_legend(ncol=4))
       
)
pdf(file=paste(getwd(),"/fig2c.pdf",sep=""),width=9)
plot(get(paste("gg",j,sep="")))
dev.off()

#
j=1
assign(paste("gg",j,sep=""), 
       ggplot(results[results$Timepoint==j & results$N!="N = 500",], aes(x=Intervention,y=psi_est,col=N))  + 
         geom_point(size=3, alpha=0.5) +
         theme_bw() +
         geom_line(linetype=2, size=1.1, alpha=0.5) +
         scale_x_continuous("Intervention", breaks=c(seq(-7,13))) +
         scale_y_continuous(expression(psi)) +
         guides(fill = guide_legend(keywidth = 2, keyheight = 2, title="Time")) +
         labs(title=paste("Estimated dose-response curves for different sample sizes at time", j+1))  +
         theme(axis.title.x = element_text(size=16), axis.text.x = element_text(size=16),axis.title.y = element_text(size=16, angle = 90),
               axis.text.y = element_text(size=16), plot.title = element_text(size=18), legend.text =  element_text(size=18), legend.title = element_text(size=18, face = "bold", hjust = 0),legend.position =   "bottom") +
         scale_colour_manual(name = 'Sample Sizes', values = mycolors[c(1,4,5,2)]) + 
         guides(col=guide_legend(ncol=4))
       
)
pdf(file=paste(getwd(),"/fig5b.pdf",sep=""),width=9)
plot(get(paste("gg",j,sep="")))
dev.off()

diag.results_cond <- sim.results[[6]]

cond_support <- apply(diag.results_cond,1,mean)
cond_support_summary <- cbind(expand.grid(paste(intervention),1:5),cond_support)
colnames(cond_support_summary)[1:2] <- c("Intervention","Time")
cond_support_summary$Intervention <- as.numeric(paste(cond_support_summary$Intervention))


pdf(file=paste(getwd(),"/fig6b.pdf",sep=""),width=10)
ggplot(cond_support_summary[cond_support_summary$Time<3,], aes(x=Intervention, y=cond_support)) + geom_tile(aes(height=0.005,fill=as.factor(Time))) + facet_wrap(Time~.) +   theme_bw() +
  scale_x_continuous("Intervention", breaks=c(seq(-7,13,2))) +
  scale_y_continuous("conditional support") +
  coord_cartesian(xlim=c(-7,13)) +
  guides(fill = guide_legend(keywidth = 2, keyheight = 2, title="time point")) +
  labs(title=paste("Conditional support at different timepoints"))  +
  theme(axis.title.x = element_text(size=16), axis.text.x = element_text(size=16),axis.title.y = element_text(size=16, angle = 90),
        axis.text.y = element_text(size=16), strip.text.x = element_text(size = 16),  plot.title = element_text(size=18), legend.text =  element_text(size=18), legend.title = element_text(size=18, face = "bold", hjust = 0),legend.position =   "bottom") +
  guides(col=guide_legend(ncol=1)) +
  theme(legend.position="none")
dev.off()

