
_________________________________________________
R-Package "SAE": Shrinkage Averaging Estimation
_________________________________________________


INSTALLATION
* Note: this package is NOT on CRAN, it only summarizes useful functions relating to the reference below.
* install package, e.g. via install.packages("C:/yourpath/SAE_0.3.tar.gz")
* Make sure you match all the relevant dependencies, i.e. install R>= version 3.2.2 and packages
  lasso2, boot, quadprog, corpcor
* Load SAE with "library(SAE)", type "?sae" and run the examples at the bottom of the help page


REFERENCES
Schomaker, M. (2012), Shrinkage Averaging Estimation, Statistical Papers, 53:1015-1034
Schomaker M, Heumann C. (2020) When and when not to use optimal model averaging. Statistical Papers, in press
